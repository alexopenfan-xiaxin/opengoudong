.class public final Lcom/goudong/jd/update/UpdateChecker;
.super Ljava/lang/Object;
.source "UpdateChecker.kt"


# annotations
.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000&\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0002\u0018\u00002\u00020\u0001B\u0015\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u00a2\u0006\u0002\u0010\u0006J\u0010\u0010\t\u001a\u0004\u0018\u00010\nH\u0086@\u00a2\u0006\u0002\u0010\u000bR\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0008X\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u000c"
    }
    d2 = {
        "Lcom/goudong/jd/update/UpdateChecker;",
        "",
        "apiClient",
        "Lcom/goudong/jd/data/network/ApiClient;",
        "context",
        "Landroid/content/Context;",
        "(Lcom/goudong/jd/data/network/ApiClient;Landroid/content/Context;)V",
        "gson",
        "Lcom/google/gson/Gson;",
        "check",
        "Lcom/goudong/jd/update/UpdateInfo;",
        "(Lkotlin/coroutines/Continuation;)Ljava/lang/Object;",
        "app_debug"
    }
    k = 0x1
    mv = {
        0x1,
        0x9,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field private final apiClient:Lcom/goudong/jd/data/network/ApiClient;

.field private final context:Landroid/content/Context;

.field private final gson:Lcom/google/gson/Gson;


# direct methods
.method public constructor <init>(Lcom/goudong/jd/data/network/ApiClient;Landroid/content/Context;)V
    .locals 1
    .param p1, "apiClient"    # Lcom/goudong/jd/data/network/ApiClient;
    .param p2, "context"    # Landroid/content/Context;

    const-string v0, "apiClient"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "context"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 10
    iput-object p1, p0, Lcom/goudong/jd/update/UpdateChecker;->apiClient:Lcom/goudong/jd/data/network/ApiClient;

    .line 11
    iput-object p2, p0, Lcom/goudong/jd/update/UpdateChecker;->context:Landroid/content/Context;

    .line 13
    new-instance v0, Lcom/google/gson/Gson;

    invoke-direct {v0}, Lcom/google/gson/Gson;-><init>()V

    iput-object v0, p0, Lcom/goudong/jd/update/UpdateChecker;->gson:Lcom/google/gson/Gson;

    .line 9
    return-void
.end method


# virtual methods
.method public final check(Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
    .locals 18
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/coroutines/Continuation<",
            "-",
            "Lcom/goudong/jd/update/UpdateInfo;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    move-object/from16 v0, p1

    instance-of v1, v0, Lcom/goudong/jd/update/UpdateChecker$check$1;

    if-eqz v1, :cond_0

    move-object v1, v0

    check-cast v1, Lcom/goudong/jd/update/UpdateChecker$check$1;

    iget v2, v1, Lcom/goudong/jd/update/UpdateChecker$check$1;->label:I

    const/high16 v3, -0x80000000

    and-int/2addr v2, v3

    if-eqz v2, :cond_0

    iget v0, v1, Lcom/goudong/jd/update/UpdateChecker$check$1;->label:I

    sub-int/2addr v0, v3

    iput v0, v1, Lcom/goudong/jd/update/UpdateChecker$check$1;->label:I

    move-object v0, v1

    move-object/from16 v2, p0

    goto :goto_0

    :cond_0
    new-instance v1, Lcom/goudong/jd/update/UpdateChecker$check$1;

    move-object/from16 v2, p0

    invoke-direct {v1, v2, v0}, Lcom/goudong/jd/update/UpdateChecker$check$1;-><init>(Lcom/goudong/jd/update/UpdateChecker;Lkotlin/coroutines/Continuation;)V

    move-object v0, v1

    .local v1, "$continuation":Lkotlin/coroutines/Continuation;
    :goto_0
    iget-object v14, v1, Lcom/goudong/jd/update/UpdateChecker$check$1;->result:Ljava/lang/Object;

    .local v14, "$result":Ljava/lang/Object;
    invoke-static {}, Lkotlin/coroutines/intrinsics/IntrinsicsKt;->getCOROUTINE_SUSPENDED()Ljava/lang/Object;

    move-result-object v0

    .line 15
    iget v3, v1, Lcom/goudong/jd/update/UpdateChecker$check$1;->label:I

    const/4 v15, 0x0

    packed-switch v3, :pswitch_data_0

    .end local v1    # "$continuation":Lkotlin/coroutines/Continuation;
    .end local v14    # "$result":Ljava/lang/Object;
    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v1, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0

    .restart local v1    # "$continuation":Lkotlin/coroutines/Continuation;
    .restart local v14    # "$result":Ljava/lang/Object;
    :pswitch_0
    iget-object v0, v1, Lcom/goudong/jd/update/UpdateChecker$check$1;->L$0:Ljava/lang/Object;

    check-cast v0, Lcom/goudong/jd/update/UpdateChecker;

    .local v0, "this":Lcom/goudong/jd/update/UpdateChecker;
    :try_start_0
    invoke-static {v14}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_1

    move-object v3, v14

    goto :goto_1

    .end local v0    # "this":Lcom/goudong/jd/update/UpdateChecker;
    :pswitch_1
    invoke-static {v14}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    move-object/from16 v13, p0

    .line 16
    .local v13, "this":Lcom/goudong/jd/update/UpdateChecker;
    nop

    .line 17
    :try_start_1
    iget-object v3, v13, Lcom/goudong/jd/update/UpdateChecker;->apiClient:Lcom/goudong/jd/data/network/ApiClient;

    const-string v5, "http://180.152.5.230:5701/static/update_apk/version.json"

    iput-object v13, v1, Lcom/goudong/jd/update/UpdateChecker$check$1;->L$0:Ljava/lang/Object;

    const/4 v4, 0x1

    iput v4, v1, Lcom/goudong/jd/update/UpdateChecker$check$1;->label:I

    const/4 v4, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x0

    const/16 v12, 0x7d

    const/16 v16, 0x0

    move-object v11, v1

    move-object/from16 v17, v13

    .end local v13    # "this":Lcom/goudong/jd/update/UpdateChecker;
    .local v17, "this":Lcom/goudong/jd/update/UpdateChecker;
    move-object/from16 v13, v16

    invoke-static/range {v3 .. v13}, Lcom/goudong/jd/data/network/ApiClient;->requestText$default(Lcom/goudong/jd/data/network/ApiClient;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;Lokhttp3/RequestBody;ZZLkotlin/coroutines/Continuation;ILjava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    if-ne v3, v0, :cond_1

    .line 15
    return-object v0

    .line 17
    :cond_1
    move-object/from16 v0, v17

    .end local v17    # "this":Lcom/goudong/jd/update/UpdateChecker;
    .restart local v0    # "this":Lcom/goudong/jd/update/UpdateChecker;
    :goto_1
    check-cast v3, Ljava/lang/String;
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    .line 16
    nop

    .line 21
    .local v3, "text":Ljava/lang/String;
    nop

    .line 22
    :try_start_2
    iget-object v4, v0, Lcom/goudong/jd/update/UpdateChecker;->gson:Lcom/google/gson/Gson;

    .end local v0    # "this":Lcom/goudong/jd/update/UpdateChecker;
    move-object v0, v3

    check-cast v0, Ljava/lang/CharSequence;

    invoke-static {v0}, Lkotlin/text/StringsKt;->trim(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    .end local v3    # "text":Ljava/lang/String;
    const-class v3, Lcom/goudong/jd/update/UpdateInfo;

    invoke-virtual {v4, v0, v3}, Lcom/google/gson/Gson;->fromJson(Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/goudong/jd/update/UpdateInfo;
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0

    .line 21
    if-nez v0, :cond_2

    .line 25
    return-object v15

    .line 26
    .local v0, "info":Lcom/goudong/jd/update/UpdateInfo;
    :cond_2
    invoke-virtual {v0}, Lcom/goudong/jd/update/UpdateInfo;->getVersionCode()I

    move-result v3

    const/16 v4, 0xaf

    if-le v3, v4, :cond_3

    move-object v15, v0

    nop

    .end local v0    # "info":Lcom/goudong/jd/update/UpdateInfo;
    :cond_3
    return-object v15

    .line 23
    :catch_0
    move-exception v0

    .line 24
    return-object v15

    .line 18
    :catch_1
    move-exception v0

    .line 19
    return-object v15

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
