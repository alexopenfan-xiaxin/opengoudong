.class public final Lcom/goudong/jd/ui/projects/KugouRushFragment;
.super Landroidx/fragment/app/Fragment;
.source "KugouRushFragment.kt"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/goudong/jd/ui/projects/KugouRushFragment$AccountTierState;,
        Lcom/goudong/jd/ui/projects/KugouRushFragment$Companion;
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nKugouRushFragment.kt\nKotlin\n*S Kotlin\n*F\n+ 1 KugouRushFragment.kt\ncom/goudong/jd/ui/projects/KugouRushFragment\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 3 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,1302:1\n1#2:1303\n1#2:1328\n1#2:1375\n1855#3,2:1304\n1549#3:1306\n1620#3,3:1307\n766#3:1310\n857#3,2:1311\n1855#3:1313\n1054#3:1314\n1855#3,2:1315\n1856#3:1317\n1603#3,9:1318\n1855#3:1327\n1856#3:1329\n1612#3:1330\n766#3:1331\n857#3,2:1332\n1549#3:1334\n1620#3,3:1335\n766#3:1338\n857#3,2:1339\n766#3:1341\n857#3,2:1342\n1054#3:1344\n1549#3:1345\n1620#3,3:1346\n766#3:1349\n857#3,2:1350\n766#3:1352\n857#3,2:1353\n766#3:1355\n857#3,2:1356\n1549#3:1358\n1620#3,3:1359\n766#3:1362\n857#3,2:1363\n1603#3,9:1365\n1855#3:1374\n1856#3:1376\n1612#3:1377\n766#3:1378\n857#3,2:1379\n1747#3,3:1381\n*S KotlinDebug\n*F\n+ 1 KugouRushFragment.kt\ncom/goudong/jd/ui/projects/KugouRushFragment\n*L\n771#1:1328\n859#1:1375\n347#1:1304,2\n513#1:1306\n513#1:1307,3\n513#1:1310\n513#1:1311,2\n680#1:1313\n733#1:1314\n733#1:1315,2\n680#1:1317\n771#1:1318,9\n771#1:1327\n771#1:1329\n771#1:1330\n826#1:1331\n826#1:1332,2\n826#1:1334\n826#1:1335,3\n827#1:1338\n827#1:1339,2\n830#1:1341\n830#1:1342,2\n830#1:1344\n832#1:1345\n832#1:1346,3\n839#1:1349\n839#1:1350,2\n848#1:1352\n848#1:1353,2\n852#1:1355\n852#1:1356,2\n852#1:1358\n852#1:1359,3\n853#1:1362\n853#1:1363,2\n859#1:1365,9\n859#1:1374\n859#1:1376\n859#1:1377\n942#1:1378\n942#1:1379,2\n954#1:1381,3\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u0089\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\u0008\u0002\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0008\u0004\n\u0002\u0018\u0002\n\u0002\u0008\u0005\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0002\u0008\u0007\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0005\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0010\u0008\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0010\u0002\n\u0002\u0008\u0007\n\u0002\u0018\u0002\n\u0002\u0008\u000e\n\u0002\u0010#\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\"\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0008\n\u0002\u0018\u0002\n\u0002\u0008\u000c\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0007\n\u0002\u0018\u0002\n\u0002\u0008\u000c\n\u0002\u0018\u0002\n\u0002\u0008\u000e\n\u0002\u0010$\n\u0002\u0010\u0000\n\u0002\u0008\u0003*\u0001\u0016\u0018\u0000 \u00a8\u00012\u00020\u0001:\u0004\u00a7\u0001\u00a8\u0001B\u0005\u00a2\u0006\u0002\u0010\u0002J\u0010\u0010H\u001a\u00020I2\u0006\u0010J\u001a\u00020\u000bH\u0002J\u001c\u0010K\u001a\u00020I2\u0008\u0010L\u001a\u0004\u0018\u00010,2\u0008\u0008\u0002\u0010M\u001a\u00020\u000eH\u0002J\u001a\u0010N\u001a\u00020I2\u0006\u0010O\u001a\u00020 2\u0008\u0010P\u001a\u0004\u0018\u00010QH\u0002J\u0018\u0010R\u001a\u00020\u000e2\u0006\u0010O\u001a\u00020 2\u0006\u0010S\u001a\u00020\u000eH\u0002J\u0008\u0010T\u001a\u00020>H\u0002J\u0010\u0010U\u001a\u00020I2\u0006\u0010V\u001a\u00020\u000bH\u0002J\u0008\u0010W\u001a\u00020IH\u0002J\u0008\u0010X\u001a\u00020\u000eH\u0002J\u0010\u0010Y\u001a\u00020\u00042\u0006\u0010Z\u001a\u00020\u000bH\u0002J\u0008\u0010[\u001a\u00020IH\u0002J\u0008\u0010\\\u001a\u00020IH\u0002J\u0016\u0010]\u001a\u0008\u0012\u0004\u0012\u00020>0\u00082\u0006\u0010^\u001a\u00020\u000bH\u0002J,\u0010_\u001a\u0008\u0012\u0004\u0012\u00020>0`2\u000c\u0010a\u001a\u0008\u0012\u0004\u0012\u00020b0\u00082\u000e\u0010c\u001a\n\u0012\u0004\u0012\u00020>\u0018\u00010dH\u0002J\u0018\u0010e\u001a\u00020I2\u000e\u0010f\u001a\n\u0012\u0004\u0012\u00020g\u0018\u00010\u0008H\u0002J\u0010\u0010h\u001a\u00020\u000b2\u0006\u0010i\u001a\u00020gH\u0002J\u0008\u0010j\u001a\u00020\u000eH\u0002J\u0008\u0010k\u001a\u00020\u000eH\u0002J\u0008\u0010l\u001a\u00020\u000eH\u0002J\u0008\u0010m\u001a\u00020\u000eH\u0002J\u0014\u0010n\u001a\u0004\u0018\u00010\u000b2\u0008\u0010V\u001a\u0004\u0018\u00010\u000bH\u0002J\u001c\u0010o\u001a\u0008\u0012\u0004\u0012\u00020\u000b0p2\u000c\u0010q\u001a\u0008\u0012\u0004\u0012\u00020\u000b0\u0008H\u0002J\u0010\u0010r\u001a\u00020\u00042\u0006\u0010Z\u001a\u00020\u000bH\u0002J\u0008\u0010s\u001a\u00020IH\u0002J\u0008\u0010t\u001a\u00020IH\u0002J\u0008\u0010u\u001a\u00020IH\u0002J\u0010\u0010v\u001a\u00020\u000b2\u0006\u0010w\u001a\u00020\u000bH\u0002J\u0008\u0010x\u001a\u00020>H\u0002J\u0018\u0010y\u001a\u00020I2\u0006\u0010z\u001a\u00020\u000b2\u0006\u0010S\u001a\u00020\u000eH\u0002J&\u0010{\u001a\u00020/2\u0006\u0010|\u001a\u00020}2\u0008\u0010~\u001a\u0004\u0018\u00010\u007f2\n\u0010\u0080\u0001\u001a\u0005\u0018\u00010\u0081\u0001H\u0016J\t\u0010\u0082\u0001\u001a\u00020IH\u0016J\t\u0010\u0083\u0001\u001a\u00020IH\u0016J\t\u0010\u0084\u0001\u001a\u00020IH\u0016J\u001e\u0010\u0085\u0001\u001a\u00020I2\u0007\u0010\u0086\u0001\u001a\u00020/2\n\u0010\u0080\u0001\u001a\u0005\u0018\u00010\u0081\u0001H\u0016J\t\u0010\u0087\u0001\u001a\u00020>H\u0002J\u0014\u0010\u0088\u0001\u001a\r \u008a\u0001*\u0005\u0018\u00010\u0089\u00010\u0089\u0001H\u0002J\t\u0010\u008b\u0001\u001a\u00020IH\u0002J\t\u0010\u008c\u0001\u001a\u00020IH\u0002J\t\u0010\u008d\u0001\u001a\u00020IH\u0002J$\u0010\u008e\u0001\u001a\u00020I2\u000e\u0010f\u001a\n\u0012\u0004\u0012\u00020g\u0018\u00010\u00082\t\u0008\u0002\u0010\u008f\u0001\u001a\u00020\u000eH\u0002J\u0011\u0010\u0090\u0001\u001a\u00020I2\u0006\u0010i\u001a\u00020gH\u0002J\t\u0010\u0091\u0001\u001a\u00020IH\u0002J\t\u0010\u0092\u0001\u001a\u00020IH\u0002J\t\u0010\u0093\u0001\u001a\u00020IH\u0002J\u001b\u0010\u0094\u0001\u001a\u00020I2\u0008\u0010\u0095\u0001\u001a\u00030\u0096\u00012\u0006\u0010z\u001a\u00020\u000bH\u0002J\u0011\u0010\u0097\u0001\u001a\u00020I2\u0006\u0010w\u001a\u00020\u000bH\u0002J+\u0010\u0098\u0001\u001a\u00020I2\u0006\u0010z\u001a\u00020\u000b2\u0007\u0010\u0099\u0001\u001a\u00020>2\u0006\u0010S\u001a\u00020\u000e2\u0007\u0010\u009a\u0001\u001a\u00020\u000eH\u0002J\u000f\u0010\u009b\u0001\u001a\u0008\u0012\u0004\u0012\u00020\t0\u0008H\u0002J\u0012\u0010\u009c\u0001\u001a\u00020I2\u0007\u0010\u009d\u0001\u001a\u00020\u000eH\u0002J\t\u0010\u009e\u0001\u001a\u00020IH\u0002J\t\u0010\u009f\u0001\u001a\u00020IH\u0002J\t\u0010\u00a0\u0001\u001a\u00020IH\u0002J\u001a\u0010\u00a1\u0001\u001a\u00020I2\u0006\u0010^\u001a\u00020\u000b2\u0007\u0010\u00a2\u0001\u001a\u00020>H\u0002J\t\u0010\u00a3\u0001\u001a\u00020IH\u0002J\u001d\u0010\u00a4\u0001\u001a\u0016\u0012\u0012\u0012\u0010\u0012\u0004\u0012\u00020\u000b\u0012\u0005\u0012\u00030\u00a6\u00010\u00a5\u00010\u0008H\u0002R\u0010\u0010\u0003\u001a\u0004\u0018\u00010\u0004X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0010\u0010\u0005\u001a\u0004\u0018\u00010\u0006X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0014\u0010\u0007\u001a\u0008\u0012\u0004\u0012\u00020\t0\u0008X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0010\u0010\n\u001a\u0004\u0018\u00010\u000bX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0010\u0010\u000c\u001a\u0004\u0018\u00010\u0004X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\r\u001a\u00020\u000eX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0010\u0010\u000f\u001a\u0004\u0018\u00010\u0010X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0010\u0010\u0011\u001a\u0004\u0018\u00010\u0004X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0010\u0010\u0012\u001a\u0004\u0018\u00010\u0004X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0013\u001a\u00020\u0014X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0010\u0010\u0015\u001a\u00020\u0016X\u0082\u0004\u00a2\u0006\u0004\n\u0002\u0010\u0017R\u000e\u0010\u0018\u001a\u00020\u0006X\u0082.\u00a2\u0006\u0002\n\u0000R\u0010\u0010\u0019\u001a\u0004\u0018\u00010\u001aX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0010\u0010\u001b\u001a\u0004\u0018\u00010\u0004X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0010\u0010\u001c\u001a\u0004\u0018\u00010\u001aX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u001d\u001a\u00020\u000eX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0010\u0010\u001e\u001a\u0004\u0018\u00010\u0006X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0014\u0010\u001f\u001a\u0008\u0012\u0004\u0012\u00020 0\u0008X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0010\u0010!\u001a\u0004\u0018\u00010\u0004X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0010\u0010\"\u001a\u0004\u0018\u00010\u0004X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0010\u0010#\u001a\u0004\u0018\u00010$X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0010\u0010%\u001a\u0004\u0018\u00010\u0004X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010&\u001a\u00020\u000eX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0010\u0010\'\u001a\u0004\u0018\u00010\u001aX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0010\u0010(\u001a\u0004\u0018\u00010\u0004X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0010\u0010)\u001a\u0004\u0018\u00010\u0004X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0010\u0010*\u001a\u0004\u0018\u00010\u0004X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0010\u0010+\u001a\u0004\u0018\u00010,X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010-\u001a\u00020\u000eX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0010\u0010.\u001a\u0004\u0018\u00010/X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0010\u00100\u001a\u0004\u0018\u00010/X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u00101\u001a\u000202X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u00103\u001a\u00020\u000eX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0014\u00104\u001a\u00020\u000b8BX\u0082\u0004\u00a2\u0006\u0006\u001a\u0004\u00085\u00106R\u001e\u00107\u001a\u0012\u0012\u0004\u0012\u00020\u000b08j\u0008\u0012\u0004\u0012\u00020\u000b`9X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0010\u0010:\u001a\u0004\u0018\u00010;X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010<\u001a\u00020\u000eX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010=\u001a\u00020>X\u0082\u000e\u00a2\u0006\u0002\n\u0000R*\u0010?\u001a\u001e\u0012\u0004\u0012\u00020\u000b\u0012\u0004\u0012\u00020A0@j\u000e\u0012\u0004\u0012\u00020\u000b\u0012\u0004\u0012\u00020A`BX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0010\u0010C\u001a\u0004\u0018\u00010\u0004X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0010\u0010D\u001a\u0004\u0018\u00010EX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0010\u0010F\u001a\u0004\u0018\u00010\u0004X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010G\u001a\u00020\u000eX\u0082\u000e\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u00a9\u0001"
    }
    d2 = {
        "Lcom/goudong/jd/ui/projects/KugouRushFragment;",
        "Landroidx/fragment/app/Fragment;",
        "()V",
        "accountListHintText",
        "Landroid/widget/TextView;",
        "accountListWrap",
        "Landroid/widget/LinearLayout;",
        "accounts",
        "",
        "Lcom/goudong/jd/data/model/KugouAccount;",
        "activeTaskId",
        "",
        "authHint",
        "authorized",
        "",
        "autoRushSwitch",
        "Landroid/widget/Switch;",
        "balanceHint",
        "cashShareHint",
        "clockHandler",
        "Landroid/os/Handler;",
        "clockRunnable",
        "com/goudong/jd/ui/projects/KugouRushFragment$clockRunnable$1",
        "Lcom/goudong/jd/ui/projects/KugouRushFragment$clockRunnable$1;",
        "contentRoot",
        "countdownJob",
        "Lkotlinx/coroutines/Job;",
        "countdownText",
        "crossDeviceSyncJob",
        "followLiveLogs",
        "guideHost",
        "kugouSessions",
        "Lcom/goudong/jd/data/model/KugouWithdrawTask;",
        "levelHintText",
        "loadLevelsBtn",
        "logScroll",
        "Lcom/goudong/jd/ui/common/TaskLogScrollView;",
        "logText",
        "monitorImmediate",
        "monitorJob",
        "nextTimeText",
        "nowTimeText",
        "pageSubtitleText",
        "portalConfig",
        "Lcom/goudong/jd/data/model/KugouPortalConfig;",
        "portalConfigFromCache",
        "proxySettingsCard",
        "Landroid/view/View;",
        "rushModeCard",
        "rushModeSwitchListener",
        "Landroid/widget/CompoundButton$OnCheckedChangeListener;",
        "rushModeSwitchUpdating",
        "rushProduct",
        "getRushProduct",
        "()Ljava/lang/String;",
        "selectedUserIds",
        "Ljava/util/LinkedHashSet;",
        "Lkotlin/collections/LinkedHashSet;",
        "sessionSpinner",
        "Landroid/widget/Spinner;",
        "sessionSpinnerProgrammatic",
        "taskLogIndex",
        "",
        "tierByUser",
        "Ljava/util/LinkedHashMap;",
        "Lcom/goudong/jd/ui/projects/KugouRushFragment$AccountTierState;",
        "Lkotlin/collections/LinkedHashMap;",
        "timeHintText",
        "useProxyCheck",
        "Landroid/widget/CheckBox;",
        "withdrawBtn",
        "withdrawSubmitting",
        "appendLog",
        "",
        "msg",
        "applyPortalConfig",
        "cfg",
        "fromCache",
        "applyRestoredKugouTask",
        "task",
        "json",
        "Lorg/json/JSONObject;",
        "applyTaskResult",
        "immediate",
        "autoPrepMin",
        "bindGuideText",
        "raw",
        "buildPage",
        "canChooseRushMode",
        "captionText",
        "text",
        "clearLogs",
        "clearState",
        "coinsFor",
        "uid",
        "defaultCoins",
        "",
        "levels",
        "Lcom/goudong/jd/data/model/KugouLevel;",
        "previous",
        "",
        "flushTaskLogs",
        "logs",
        "Lcom/goudong/jd/data/model/KuwoTaskLog;",
        "formatTaskLogLine",
        "entry",
        "isAutoRushMode",
        "isDebugRush",
        "isDebugRushMode",
        "isEmbeddedInHub",
        "kugouPortalCopy",
        "kugouSessionSpinnerAdapter",
        "Landroid/widget/ArrayAdapter;",
        "labels",
        "label",
        "loadKugouSessions",
        "loadLevels",
        "loadPage",
        "maskId",
        "id",
        "maxLevelSelect",
        "monitorTask",
        "taskId",
        "onCreateView",
        "inflater",
        "Landroid/view/LayoutInflater;",
        "container",
        "Landroid/view/ViewGroup;",
        "savedInstanceState",
        "Landroid/os/Bundle;",
        "onDestroyView",
        "onPause",
        "onResume",
        "onViewCreated",
        "view",
        "preOpenMin",
        "prefs",
        "Landroid/content/SharedPreferences;",
        "kotlin.jvm.PlatformType",
        "refreshConfigStaleHint",
        "refreshRevenueShareCashHint",
        "renderAccounts",
        "renderServerLogs",
        "scrollToEnd",
        "renderTaskLog",
        "restoreLogs",
        "restoreState",
        "restoreWithdrawUi",
        "runCountdown",
        "info",
        "Lcom/goudong/jd/ui/projects/KugouTimeHelper$NextWithdrawInfo;",
        "saveLastTaskId",
        "saveState",
        "targetHour",
        "useProxy",
        "selectedAccounts",
        "setWithdrawUiLocked",
        "locked",
        "startWithdraw",
        "syncKugouPortalLogs",
        "syncStartButton",
        "trimAccountCoins",
        "keep",
        "updateTimeDisplay",
        "withdrawPicks",
        "",
        "",
        "AccountTierState",
        "Companion",
        "app_debug"
    }
    k = 0x1
    mv = {
        0x1,
        0x9,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field private static final ARG_EMBEDDED_HUB:Ljava/lang/String; = "kugou_embedded_hub"

.field private static final ARG_PRODUCT:Ljava/lang/String; = "kugou_product"

.field public static final Companion:Lcom/goudong/jd/ui/projects/KugouRushFragment$Companion;


# instance fields
.field private accountListHintText:Landroid/widget/TextView;

.field private accountListWrap:Landroid/widget/LinearLayout;

.field private accounts:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/goudong/jd/data/model/KugouAccount;",
            ">;"
        }
    .end annotation
.end field

.field private activeTaskId:Ljava/lang/String;

.field private authHint:Landroid/widget/TextView;

.field private authorized:Z

.field private autoRushSwitch:Landroid/widget/Switch;

.field private balanceHint:Landroid/widget/TextView;

.field private cashShareHint:Landroid/widget/TextView;

.field private final clockHandler:Landroid/os/Handler;

.field private final clockRunnable:Lcom/goudong/jd/ui/projects/KugouRushFragment$clockRunnable$1;

.field private contentRoot:Landroid/widget/LinearLayout;

.field private countdownJob:Lkotlinx/coroutines/Job;

.field private countdownText:Landroid/widget/TextView;

.field private crossDeviceSyncJob:Lkotlinx/coroutines/Job;

.field private followLiveLogs:Z

.field private guideHost:Landroid/widget/LinearLayout;

.field private kugouSessions:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/goudong/jd/data/model/KugouWithdrawTask;",
            ">;"
        }
    .end annotation
.end field

.field private levelHintText:Landroid/widget/TextView;

.field private loadLevelsBtn:Landroid/widget/TextView;

.field private logScroll:Lcom/goudong/jd/ui/common/TaskLogScrollView;

.field private logText:Landroid/widget/TextView;

.field private monitorImmediate:Z

.field private monitorJob:Lkotlinx/coroutines/Job;

.field private nextTimeText:Landroid/widget/TextView;

.field private nowTimeText:Landroid/widget/TextView;

.field private pageSubtitleText:Landroid/widget/TextView;

.field private portalConfig:Lcom/goudong/jd/data/model/KugouPortalConfig;

.field private portalConfigFromCache:Z

.field private proxySettingsCard:Landroid/view/View;

.field private rushModeCard:Landroid/view/View;

.field private final rushModeSwitchListener:Landroid/widget/CompoundButton$OnCheckedChangeListener;

.field private rushModeSwitchUpdating:Z

.field private final selectedUserIds:Ljava/util/LinkedHashSet;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/LinkedHashSet<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private sessionSpinner:Landroid/widget/Spinner;

.field private sessionSpinnerProgrammatic:Z

.field private taskLogIndex:I

.field private final tierByUser:Ljava/util/LinkedHashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/LinkedHashMap<",
            "Ljava/lang/String;",
            "Lcom/goudong/jd/ui/projects/KugouRushFragment$AccountTierState;",
            ">;"
        }
    .end annotation
.end field

.field private timeHintText:Landroid/widget/TextView;

.field private useProxyCheck:Landroid/widget/CheckBox;

.field private withdrawBtn:Landroid/widget/TextView;

.field private withdrawSubmitting:Z


# direct methods
.method public static synthetic $r8$lambda$3G9Rf-T1Kvr_Dh2thImlNvxlc3M(Lcom/goudong/jd/ui/projects/KugouRushFragment;)V
    .locals 0

    invoke-static {p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->renderAccounts$lambda$73$lambda$60$lambda$59$lambda$58(Lcom/goudong/jd/ui/projects/KugouRushFragment;)V

    return-void
.end method

.method public static synthetic $r8$lambda$WNnHw-wNSW2sHyWLY4OigjMyeII(Lcom/goudong/jd/ui/projects/KugouRushFragment;Landroid/widget/CompoundButton;Z)V
    .locals 0

    invoke-static {p0, p1, p2}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->rushModeSwitchListener$lambda$53(Lcom/goudong/jd/ui/projects/KugouRushFragment;Landroid/widget/CompoundButton;Z)V

    return-void
.end method

.method public static synthetic $r8$lambda$dGWR_-agg9KI9w1mMozPUOLeHXU(ZLcom/goudong/jd/ui/projects/KugouRushFragment$AccountTierState;Lcom/goudong/jd/data/model/KugouLevel;Lcom/goudong/jd/ui/projects/KugouRushFragment;Ljava/lang/String;Landroid/widget/CompoundButton;Z)V
    .locals 0

    invoke-static/range {p0 .. p6}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->renderAccounts$lambda$73$lambda$72$lambda$71$lambda$70(ZLcom/goudong/jd/ui/projects/KugouRushFragment$AccountTierState;Lcom/goudong/jd/data/model/KugouLevel;Lcom/goudong/jd/ui/projects/KugouRushFragment;Ljava/lang/String;Landroid/widget/CompoundButton;Z)V

    return-void
.end method

.method public static synthetic $r8$lambda$jxx1IbYkkNJMed2TY4-nRkUPCCs(Lcom/goudong/jd/ui/projects/KugouRushFragment;Ljava/lang/String;Landroid/widget/LinearLayout;Landroid/widget/CompoundButton;Z)V
    .locals 0

    invoke-static {p0, p1, p2, p3, p4}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->renderAccounts$lambda$73$lambda$60$lambda$59(Lcom/goudong/jd/ui/projects/KugouRushFragment;Ljava/lang/String;Landroid/widget/LinearLayout;Landroid/widget/CompoundButton;Z)V

    return-void
.end method

.method public static synthetic $r8$lambda$k0w8aqq9MBRUUx526u7osrILyAo(Lcom/goudong/jd/ui/projects/KugouRushFragment;)V
    .locals 0

    invoke-static {p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->trimAccountCoins$lambda$83(Lcom/goudong/jd/ui/projects/KugouRushFragment;)V

    return-void
.end method

.method static constructor <clinit>()V
    .locals 2

    new-instance v0, Lcom/goudong/jd/ui/projects/KugouRushFragment$Companion;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lcom/goudong/jd/ui/projects/KugouRushFragment$Companion;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    sput-object v0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->Companion:Lcom/goudong/jd/ui/projects/KugouRushFragment$Companion;

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    .line 64
    invoke-direct {p0}, Landroidx/fragment/app/Fragment;-><init>()V

    .line 98
    invoke-static {}, Lkotlin/collections/CollectionsKt;->emptyList()Ljava/util/List;

    move-result-object v0

    iput-object v0, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->kugouSessions:Ljava/util/List;

    .line 110
    invoke-static {}, Lkotlin/collections/CollectionsKt;->emptyList()Ljava/util/List;

    move-result-object v0

    iput-object v0, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->accounts:Ljava/util/List;

    .line 111
    new-instance v0, Ljava/util/LinkedHashSet;

    invoke-direct {v0}, Ljava/util/LinkedHashSet;-><init>()V

    iput-object v0, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->selectedUserIds:Ljava/util/LinkedHashSet;

    .line 112
    new-instance v0, Ljava/util/LinkedHashMap;

    invoke-direct {v0}, Ljava/util/LinkedHashMap;-><init>()V

    iput-object v0, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->tierByUser:Ljava/util/LinkedHashMap;

    .line 124
    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->followLiveLogs:Z

    .line 129
    new-instance v0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    iput-object v0, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->clockHandler:Landroid/os/Handler;

    .line 130
    new-instance v0, Lcom/goudong/jd/ui/projects/KugouRushFragment$clockRunnable$1;

    invoke-direct {v0, p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment$clockRunnable$1;-><init>(Lcom/goudong/jd/ui/projects/KugouRushFragment;)V

    iput-object v0, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->clockRunnable:Lcom/goudong/jd/ui/projects/KugouRushFragment$clockRunnable$1;

    .line 547
    new-instance v0, Lcom/goudong/jd/ui/projects/KugouRushFragment$$ExternalSyntheticLambda3;

    invoke-direct {v0, p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment$$ExternalSyntheticLambda3;-><init>(Lcom/goudong/jd/ui/projects/KugouRushFragment;)V

    iput-object v0, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->rushModeSwitchListener:Landroid/widget/CompoundButton$OnCheckedChangeListener;

    .line 64
    return-void
.end method

.method public static final synthetic access$appendLog(Lcom/goudong/jd/ui/projects/KugouRushFragment;Ljava/lang/String;)V
    .locals 0
    .param p0, "$this"    # Lcom/goudong/jd/ui/projects/KugouRushFragment;
    .param p1, "msg"    # Ljava/lang/String;

    .line 64
    invoke-direct {p0, p1}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->appendLog(Ljava/lang/String;)V

    return-void
.end method

.method public static final synthetic access$applyPortalConfig(Lcom/goudong/jd/ui/projects/KugouRushFragment;Lcom/goudong/jd/data/model/KugouPortalConfig;Z)V
    .locals 0
    .param p0, "$this"    # Lcom/goudong/jd/ui/projects/KugouRushFragment;
    .param p1, "cfg"    # Lcom/goudong/jd/data/model/KugouPortalConfig;
    .param p2, "fromCache"    # Z

    .line 64
    invoke-direct {p0, p1, p2}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->applyPortalConfig(Lcom/goudong/jd/data/model/KugouPortalConfig;Z)V

    return-void
.end method

.method public static final synthetic access$applyRestoredKugouTask(Lcom/goudong/jd/ui/projects/KugouRushFragment;Lcom/goudong/jd/data/model/KugouWithdrawTask;Lorg/json/JSONObject;)V
    .locals 0
    .param p0, "$this"    # Lcom/goudong/jd/ui/projects/KugouRushFragment;
    .param p1, "task"    # Lcom/goudong/jd/data/model/KugouWithdrawTask;
    .param p2, "json"    # Lorg/json/JSONObject;

    .line 64
    invoke-direct {p0, p1, p2}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->applyRestoredKugouTask(Lcom/goudong/jd/data/model/KugouWithdrawTask;Lorg/json/JSONObject;)V

    return-void
.end method

.method public static final synthetic access$applyTaskResult(Lcom/goudong/jd/ui/projects/KugouRushFragment;Lcom/goudong/jd/data/model/KugouWithdrawTask;Z)Z
    .locals 1
    .param p0, "$this"    # Lcom/goudong/jd/ui/projects/KugouRushFragment;
    .param p1, "task"    # Lcom/goudong/jd/data/model/KugouWithdrawTask;
    .param p2, "immediate"    # Z

    .line 64
    invoke-direct {p0, p1, p2}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->applyTaskResult(Lcom/goudong/jd/data/model/KugouWithdrawTask;Z)Z

    move-result v0

    return v0
.end method

.method public static final synthetic access$clearLogs(Lcom/goudong/jd/ui/projects/KugouRushFragment;)V
    .locals 0
    .param p0, "$this"    # Lcom/goudong/jd/ui/projects/KugouRushFragment;

    .line 64
    invoke-direct {p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->clearLogs()V

    return-void
.end method

.method public static final synthetic access$defaultCoins(Lcom/goudong/jd/ui/projects/KugouRushFragment;Ljava/util/List;Ljava/util/Set;)Ljava/util/Set;
    .locals 1
    .param p0, "$this"    # Lcom/goudong/jd/ui/projects/KugouRushFragment;
    .param p1, "levels"    # Ljava/util/List;
    .param p2, "previous"    # Ljava/util/Set;

    .line 64
    invoke-direct {p0, p1, p2}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->defaultCoins(Ljava/util/List;Ljava/util/Set;)Ljava/util/Set;

    move-result-object v0

    return-object v0
.end method

.method public static final synthetic access$flushTaskLogs(Lcom/goudong/jd/ui/projects/KugouRushFragment;Ljava/util/List;)V
    .locals 0
    .param p0, "$this"    # Lcom/goudong/jd/ui/projects/KugouRushFragment;
    .param p1, "logs"    # Ljava/util/List;

    .line 64
    invoke-direct {p0, p1}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->flushTaskLogs(Ljava/util/List;)V

    return-void
.end method

.method public static final synthetic access$formatTaskLogLine(Lcom/goudong/jd/ui/projects/KugouRushFragment;Lcom/goudong/jd/data/model/KuwoTaskLog;)Ljava/lang/String;
    .locals 1
    .param p0, "$this"    # Lcom/goudong/jd/ui/projects/KugouRushFragment;
    .param p1, "entry"    # Lcom/goudong/jd/data/model/KuwoTaskLog;

    .line 64
    invoke-direct {p0, p1}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->formatTaskLogLine(Lcom/goudong/jd/data/model/KuwoTaskLog;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public static final synthetic access$getAccounts$p(Lcom/goudong/jd/ui/projects/KugouRushFragment;)Ljava/util/List;
    .locals 1
    .param p0, "$this"    # Lcom/goudong/jd/ui/projects/KugouRushFragment;

    .line 64
    iget-object v0, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->accounts:Ljava/util/List;

    return-object v0
.end method

.method public static final synthetic access$getActiveTaskId$p(Lcom/goudong/jd/ui/projects/KugouRushFragment;)Ljava/lang/String;
    .locals 1
    .param p0, "$this"    # Lcom/goudong/jd/ui/projects/KugouRushFragment;

    .line 64
    iget-object v0, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->activeTaskId:Ljava/lang/String;

    return-object v0
.end method

.method public static final synthetic access$getAuthHint$p(Lcom/goudong/jd/ui/projects/KugouRushFragment;)Landroid/widget/TextView;
    .locals 1
    .param p0, "$this"    # Lcom/goudong/jd/ui/projects/KugouRushFragment;

    .line 64
    iget-object v0, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->authHint:Landroid/widget/TextView;

    return-object v0
.end method

.method public static final synthetic access$getAutoRushSwitch$p(Lcom/goudong/jd/ui/projects/KugouRushFragment;)Landroid/widget/Switch;
    .locals 1
    .param p0, "$this"    # Lcom/goudong/jd/ui/projects/KugouRushFragment;

    .line 64
    iget-object v0, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->autoRushSwitch:Landroid/widget/Switch;

    return-object v0
.end method

.method public static final synthetic access$getBalanceHint$p(Lcom/goudong/jd/ui/projects/KugouRushFragment;)Landroid/widget/TextView;
    .locals 1
    .param p0, "$this"    # Lcom/goudong/jd/ui/projects/KugouRushFragment;

    .line 64
    iget-object v0, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->balanceHint:Landroid/widget/TextView;

    return-object v0
.end method

.method public static final synthetic access$getCashShareHint$p(Lcom/goudong/jd/ui/projects/KugouRushFragment;)Landroid/widget/TextView;
    .locals 1
    .param p0, "$this"    # Lcom/goudong/jd/ui/projects/KugouRushFragment;

    .line 64
    iget-object v0, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->cashShareHint:Landroid/widget/TextView;

    return-object v0
.end method

.method public static final synthetic access$getClockHandler$p(Lcom/goudong/jd/ui/projects/KugouRushFragment;)Landroid/os/Handler;
    .locals 1
    .param p0, "$this"    # Lcom/goudong/jd/ui/projects/KugouRushFragment;

    .line 64
    iget-object v0, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->clockHandler:Landroid/os/Handler;

    return-object v0
.end method

.method public static final synthetic access$getCountdownJob$p(Lcom/goudong/jd/ui/projects/KugouRushFragment;)Lkotlinx/coroutines/Job;
    .locals 1
    .param p0, "$this"    # Lcom/goudong/jd/ui/projects/KugouRushFragment;

    .line 64
    iget-object v0, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->countdownJob:Lkotlinx/coroutines/Job;

    return-object v0
.end method

.method public static final synthetic access$getCountdownText$p(Lcom/goudong/jd/ui/projects/KugouRushFragment;)Landroid/widget/TextView;
    .locals 1
    .param p0, "$this"    # Lcom/goudong/jd/ui/projects/KugouRushFragment;

    .line 64
    iget-object v0, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->countdownText:Landroid/widget/TextView;

    return-object v0
.end method

.method public static final synthetic access$getFollowLiveLogs$p(Lcom/goudong/jd/ui/projects/KugouRushFragment;)Z
    .locals 1
    .param p0, "$this"    # Lcom/goudong/jd/ui/projects/KugouRushFragment;

    .line 64
    iget-boolean v0, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->followLiveLogs:Z

    return v0
.end method

.method public static final synthetic access$getKugouSessions$p(Lcom/goudong/jd/ui/projects/KugouRushFragment;)Ljava/util/List;
    .locals 1
    .param p0, "$this"    # Lcom/goudong/jd/ui/projects/KugouRushFragment;

    .line 64
    iget-object v0, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->kugouSessions:Ljava/util/List;

    return-object v0
.end method

.method public static final synthetic access$getLoadLevelsBtn$p(Lcom/goudong/jd/ui/projects/KugouRushFragment;)Landroid/widget/TextView;
    .locals 1
    .param p0, "$this"    # Lcom/goudong/jd/ui/projects/KugouRushFragment;

    .line 64
    iget-object v0, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->loadLevelsBtn:Landroid/widget/TextView;

    return-object v0
.end method

.method public static final synthetic access$getMonitorImmediate$p(Lcom/goudong/jd/ui/projects/KugouRushFragment;)Z
    .locals 1
    .param p0, "$this"    # Lcom/goudong/jd/ui/projects/KugouRushFragment;

    .line 64
    iget-boolean v0, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->monitorImmediate:Z

    return v0
.end method

.method public static final synthetic access$getRushProduct(Lcom/goudong/jd/ui/projects/KugouRushFragment;)Ljava/lang/String;
    .locals 1
    .param p0, "$this"    # Lcom/goudong/jd/ui/projects/KugouRushFragment;

    .line 64
    invoke-direct {p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->getRushProduct()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public static final synthetic access$getSelectedUserIds$p(Lcom/goudong/jd/ui/projects/KugouRushFragment;)Ljava/util/LinkedHashSet;
    .locals 1
    .param p0, "$this"    # Lcom/goudong/jd/ui/projects/KugouRushFragment;

    .line 64
    iget-object v0, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->selectedUserIds:Ljava/util/LinkedHashSet;

    return-object v0
.end method

.method public static final synthetic access$getSessionSpinner$p(Lcom/goudong/jd/ui/projects/KugouRushFragment;)Landroid/widget/Spinner;
    .locals 1
    .param p0, "$this"    # Lcom/goudong/jd/ui/projects/KugouRushFragment;

    .line 64
    iget-object v0, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->sessionSpinner:Landroid/widget/Spinner;

    return-object v0
.end method

.method public static final synthetic access$getSessionSpinnerProgrammatic$p(Lcom/goudong/jd/ui/projects/KugouRushFragment;)Z
    .locals 1
    .param p0, "$this"    # Lcom/goudong/jd/ui/projects/KugouRushFragment;

    .line 64
    iget-boolean v0, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->sessionSpinnerProgrammatic:Z

    return v0
.end method

.method public static final synthetic access$getTierByUser$p(Lcom/goudong/jd/ui/projects/KugouRushFragment;)Ljava/util/LinkedHashMap;
    .locals 1
    .param p0, "$this"    # Lcom/goudong/jd/ui/projects/KugouRushFragment;

    .line 64
    iget-object v0, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->tierByUser:Ljava/util/LinkedHashMap;

    return-object v0
.end method

.method public static final synthetic access$getUseProxyCheck$p(Lcom/goudong/jd/ui/projects/KugouRushFragment;)Landroid/widget/CheckBox;
    .locals 1
    .param p0, "$this"    # Lcom/goudong/jd/ui/projects/KugouRushFragment;

    .line 64
    iget-object v0, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->useProxyCheck:Landroid/widget/CheckBox;

    return-object v0
.end method

.method public static final synthetic access$getWithdrawBtn$p(Lcom/goudong/jd/ui/projects/KugouRushFragment;)Landroid/widget/TextView;
    .locals 1
    .param p0, "$this"    # Lcom/goudong/jd/ui/projects/KugouRushFragment;

    .line 64
    iget-object v0, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->withdrawBtn:Landroid/widget/TextView;

    return-object v0
.end method

.method public static final synthetic access$kugouSessionSpinnerAdapter(Lcom/goudong/jd/ui/projects/KugouRushFragment;Ljava/util/List;)Landroid/widget/ArrayAdapter;
    .locals 1
    .param p0, "$this"    # Lcom/goudong/jd/ui/projects/KugouRushFragment;
    .param p1, "labels"    # Ljava/util/List;

    .line 64
    invoke-direct {p0, p1}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->kugouSessionSpinnerAdapter(Ljava/util/List;)Landroid/widget/ArrayAdapter;

    move-result-object v0

    return-object v0
.end method

.method public static final synthetic access$loadKugouSessions(Lcom/goudong/jd/ui/projects/KugouRushFragment;)V
    .locals 0
    .param p0, "$this"    # Lcom/goudong/jd/ui/projects/KugouRushFragment;

    .line 64
    invoke-direct {p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->loadKugouSessions()V

    return-void
.end method

.method public static final synthetic access$loadLevels(Lcom/goudong/jd/ui/projects/KugouRushFragment;)V
    .locals 0
    .param p0, "$this"    # Lcom/goudong/jd/ui/projects/KugouRushFragment;

    .line 64
    invoke-direct {p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->loadLevels()V

    return-void
.end method

.method public static final synthetic access$maskId(Lcom/goudong/jd/ui/projects/KugouRushFragment;Ljava/lang/String;)Ljava/lang/String;
    .locals 1
    .param p0, "$this"    # Lcom/goudong/jd/ui/projects/KugouRushFragment;
    .param p1, "id"    # Ljava/lang/String;

    .line 64
    invoke-direct {p0, p1}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->maskId(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public static final synthetic access$monitorTask(Lcom/goudong/jd/ui/projects/KugouRushFragment;Ljava/lang/String;Z)V
    .locals 0
    .param p0, "$this"    # Lcom/goudong/jd/ui/projects/KugouRushFragment;
    .param p1, "taskId"    # Ljava/lang/String;
    .param p2, "immediate"    # Z

    .line 64
    invoke-direct {p0, p1, p2}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->monitorTask(Ljava/lang/String;Z)V

    return-void
.end method

.method public static final synthetic access$preOpenMin(Lcom/goudong/jd/ui/projects/KugouRushFragment;)I
    .locals 1
    .param p0, "$this"    # Lcom/goudong/jd/ui/projects/KugouRushFragment;

    .line 64
    invoke-direct {p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->preOpenMin()I

    move-result v0

    return v0
.end method

.method public static final synthetic access$refreshRevenueShareCashHint(Lcom/goudong/jd/ui/projects/KugouRushFragment;)V
    .locals 0
    .param p0, "$this"    # Lcom/goudong/jd/ui/projects/KugouRushFragment;

    .line 64
    invoke-direct {p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->refreshRevenueShareCashHint()V

    return-void
.end method

.method public static final synthetic access$renderAccounts(Lcom/goudong/jd/ui/projects/KugouRushFragment;)V
    .locals 0
    .param p0, "$this"    # Lcom/goudong/jd/ui/projects/KugouRushFragment;

    .line 64
    invoke-direct {p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->renderAccounts()V

    return-void
.end method

.method public static final synthetic access$renderServerLogs(Lcom/goudong/jd/ui/projects/KugouRushFragment;Ljava/util/List;Z)V
    .locals 0
    .param p0, "$this"    # Lcom/goudong/jd/ui/projects/KugouRushFragment;
    .param p1, "logs"    # Ljava/util/List;
    .param p2, "scrollToEnd"    # Z

    .line 64
    invoke-direct {p0, p1, p2}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->renderServerLogs(Ljava/util/List;Z)V

    return-void
.end method

.method public static final synthetic access$restoreState(Lcom/goudong/jd/ui/projects/KugouRushFragment;)V
    .locals 0
    .param p0, "$this"    # Lcom/goudong/jd/ui/projects/KugouRushFragment;

    .line 64
    invoke-direct {p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->restoreState()V

    return-void
.end method

.method public static final synthetic access$restoreWithdrawUi(Lcom/goudong/jd/ui/projects/KugouRushFragment;)V
    .locals 0
    .param p0, "$this"    # Lcom/goudong/jd/ui/projects/KugouRushFragment;

    .line 64
    invoke-direct {p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->restoreWithdrawUi()V

    return-void
.end method

.method public static final synthetic access$runCountdown(Lcom/goudong/jd/ui/projects/KugouRushFragment;Lcom/goudong/jd/ui/projects/KugouTimeHelper$NextWithdrawInfo;Ljava/lang/String;)V
    .locals 0
    .param p0, "$this"    # Lcom/goudong/jd/ui/projects/KugouRushFragment;
    .param p1, "info"    # Lcom/goudong/jd/ui/projects/KugouTimeHelper$NextWithdrawInfo;
    .param p2, "taskId"    # Ljava/lang/String;

    .line 64
    invoke-direct {p0, p1, p2}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->runCountdown(Lcom/goudong/jd/ui/projects/KugouTimeHelper$NextWithdrawInfo;Ljava/lang/String;)V

    return-void
.end method

.method public static final synthetic access$saveLastTaskId(Lcom/goudong/jd/ui/projects/KugouRushFragment;Ljava/lang/String;)V
    .locals 0
    .param p0, "$this"    # Lcom/goudong/jd/ui/projects/KugouRushFragment;
    .param p1, "id"    # Ljava/lang/String;

    .line 64
    invoke-direct {p0, p1}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->saveLastTaskId(Ljava/lang/String;)V

    return-void
.end method

.method public static final synthetic access$saveState(Lcom/goudong/jd/ui/projects/KugouRushFragment;Ljava/lang/String;IZZ)V
    .locals 0
    .param p0, "$this"    # Lcom/goudong/jd/ui/projects/KugouRushFragment;
    .param p1, "taskId"    # Ljava/lang/String;
    .param p2, "targetHour"    # I
    .param p3, "immediate"    # Z
    .param p4, "useProxy"    # Z

    .line 64
    invoke-direct {p0, p1, p2, p3, p4}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->saveState(Ljava/lang/String;IZZ)V

    return-void
.end method

.method public static final synthetic access$setAccounts$p(Lcom/goudong/jd/ui/projects/KugouRushFragment;Ljava/util/List;)V
    .locals 0
    .param p0, "$this"    # Lcom/goudong/jd/ui/projects/KugouRushFragment;
    .param p1, "<set-?>"    # Ljava/util/List;

    .line 64
    iput-object p1, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->accounts:Ljava/util/List;

    return-void
.end method

.method public static final synthetic access$setActiveTaskId$p(Lcom/goudong/jd/ui/projects/KugouRushFragment;Ljava/lang/String;)V
    .locals 0
    .param p0, "$this"    # Lcom/goudong/jd/ui/projects/KugouRushFragment;
    .param p1, "<set-?>"    # Ljava/lang/String;

    .line 64
    iput-object p1, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->activeTaskId:Ljava/lang/String;

    return-void
.end method

.method public static final synthetic access$setAuthorized$p(Lcom/goudong/jd/ui/projects/KugouRushFragment;Z)V
    .locals 0
    .param p0, "$this"    # Lcom/goudong/jd/ui/projects/KugouRushFragment;
    .param p1, "<set-?>"    # Z

    .line 64
    iput-boolean p1, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->authorized:Z

    return-void
.end method

.method public static final synthetic access$setFollowLiveLogs$p(Lcom/goudong/jd/ui/projects/KugouRushFragment;Z)V
    .locals 0
    .param p0, "$this"    # Lcom/goudong/jd/ui/projects/KugouRushFragment;
    .param p1, "<set-?>"    # Z

    .line 64
    iput-boolean p1, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->followLiveLogs:Z

    return-void
.end method

.method public static final synthetic access$setKugouSessions$p(Lcom/goudong/jd/ui/projects/KugouRushFragment;Ljava/util/List;)V
    .locals 0
    .param p0, "$this"    # Lcom/goudong/jd/ui/projects/KugouRushFragment;
    .param p1, "<set-?>"    # Ljava/util/List;

    .line 64
    iput-object p1, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->kugouSessions:Ljava/util/List;

    return-void
.end method

.method public static final synthetic access$setRushModeSwitchUpdating$p(Lcom/goudong/jd/ui/projects/KugouRushFragment;Z)V
    .locals 0
    .param p0, "$this"    # Lcom/goudong/jd/ui/projects/KugouRushFragment;
    .param p1, "<set-?>"    # Z

    .line 64
    iput-boolean p1, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->rushModeSwitchUpdating:Z

    return-void
.end method

.method public static final synthetic access$setSessionSpinnerProgrammatic$p(Lcom/goudong/jd/ui/projects/KugouRushFragment;Z)V
    .locals 0
    .param p0, "$this"    # Lcom/goudong/jd/ui/projects/KugouRushFragment;
    .param p1, "<set-?>"    # Z

    .line 64
    iput-boolean p1, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->sessionSpinnerProgrammatic:Z

    return-void
.end method

.method public static final synthetic access$setTaskLogIndex$p(Lcom/goudong/jd/ui/projects/KugouRushFragment;I)V
    .locals 0
    .param p0, "$this"    # Lcom/goudong/jd/ui/projects/KugouRushFragment;
    .param p1, "<set-?>"    # I

    .line 64
    iput p1, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->taskLogIndex:I

    return-void
.end method

.method public static final synthetic access$setWithdrawSubmitting$p(Lcom/goudong/jd/ui/projects/KugouRushFragment;Z)V
    .locals 0
    .param p0, "$this"    # Lcom/goudong/jd/ui/projects/KugouRushFragment;
    .param p1, "<set-?>"    # Z

    .line 64
    iput-boolean p1, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->withdrawSubmitting:Z

    return-void
.end method

.method public static final synthetic access$setWithdrawUiLocked(Lcom/goudong/jd/ui/projects/KugouRushFragment;Z)V
    .locals 0
    .param p0, "$this"    # Lcom/goudong/jd/ui/projects/KugouRushFragment;
    .param p1, "locked"    # Z

    .line 64
    invoke-direct {p0, p1}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->setWithdrawUiLocked(Z)V

    return-void
.end method

.method public static final synthetic access$startWithdraw(Lcom/goudong/jd/ui/projects/KugouRushFragment;)V
    .locals 0
    .param p0, "$this"    # Lcom/goudong/jd/ui/projects/KugouRushFragment;

    .line 64
    invoke-direct {p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->startWithdraw()V

    return-void
.end method

.method public static final synthetic access$syncKugouPortalLogs(Lcom/goudong/jd/ui/projects/KugouRushFragment;)V
    .locals 0
    .param p0, "$this"    # Lcom/goudong/jd/ui/projects/KugouRushFragment;

    .line 64
    invoke-direct {p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->syncKugouPortalLogs()V

    return-void
.end method

.method public static final synthetic access$syncStartButton(Lcom/goudong/jd/ui/projects/KugouRushFragment;)V
    .locals 0
    .param p0, "$this"    # Lcom/goudong/jd/ui/projects/KugouRushFragment;

    .line 64
    invoke-direct {p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->syncStartButton()V

    return-void
.end method

.method public static final synthetic access$updateTimeDisplay(Lcom/goudong/jd/ui/projects/KugouRushFragment;)V
    .locals 0
    .param p0, "$this"    # Lcom/goudong/jd/ui/projects/KugouRushFragment;

    .line 64
    invoke-direct {p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->updateTimeDisplay()V

    return-void
.end method

.method private final appendLog(Ljava/lang/String;)V
    .locals 6
    .param p1, "msg"    # Ljava/lang/String;

    .line 1214
    iget-object v0, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->logText:Landroid/widget/TextView;

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Landroid/widget/TextView;->getText()Ljava/lang/CharSequence;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    goto :goto_0

    :cond_0
    move-object v0, v1

    :goto_0
    if-nez v0, :cond_1

    const-string v0, ""

    .line 1215
    .local v0, "cur":Ljava/lang/String;
    :cond_1
    move-object v2, v0

    check-cast v2, Ljava/lang/CharSequence;

    invoke-static {v2}, Lkotlin/text/StringsKt;->isBlank(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_2

    move-object v2, p1

    goto :goto_1

    :cond_2
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, "\n"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    .line 1216
    .local v2, "next":Ljava/lang/String;
    :goto_1
    iget-object v3, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->logText:Landroid/widget/TextView;

    if-nez v3, :cond_3

    goto :goto_2

    :cond_3
    move-object v4, v2

    check-cast v4, Ljava/lang/CharSequence;

    invoke-virtual {v3, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1217
    :goto_2
    iget-object v3, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->logScroll:Lcom/goudong/jd/ui/common/TaskLogScrollView;

    if-eqz v3, :cond_4

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-static {v3, v4, v5, v1}, Lcom/goudong/jd/ui/common/UiKitKt;->scrollTaskLogToBottom$default(Lcom/goudong/jd/ui/common/TaskLogScrollView;ZILjava/lang/Object;)V

    .line 1218
    :cond_4
    invoke-direct {p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->prefs()Landroid/content/SharedPreferences;

    move-result-object v1

    invoke-interface {v1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    const-string v3, "log"

    invoke-interface {v1, v3, v2}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    invoke-interface {v1}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 1219
    return-void
.end method

.method private final applyPortalConfig(Lcom/goudong/jd/data/model/KugouPortalConfig;Z)V
    .locals 9
    .param p1, "cfg"    # Lcom/goudong/jd/data/model/KugouPortalConfig;
    .param p2, "fromCache"    # Z

    .line 475
    iput-object p1, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->portalConfig:Lcom/goudong/jd/data/model/KugouPortalConfig;

    .line 476
    const/4 v0, 0x1

    const/4 v1, 0x0

    if-eqz p2, :cond_0

    if-eqz p1, :cond_0

    move v2, v0

    goto :goto_0

    :cond_0
    move v2, v1

    :goto_0
    iput-boolean v2, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->portalConfigFromCache:Z

    .line 477
    const/4 v2, 0x0

    if-eqz p1, :cond_1

    invoke-virtual {p1}, Lcom/goudong/jd/data/model/KugouPortalConfig;->getPageSubtitle()Ljava/lang/String;

    move-result-object v3

    goto :goto_1

    :cond_1
    move-object v3, v2

    :goto_1
    invoke-direct {p0, v3}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->kugouPortalCopy(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    if-eqz v3, :cond_5

    .line 1303
    .local v3, "it":Ljava/lang/String;
    const/4 v4, 0x0

    .line 477
    .local v4, "$i$a$-let-KugouRushFragment$applyPortalConfig$1":I
    iget-object v5, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->pageSubtitleText:Landroid/widget/TextView;

    if-eqz v5, :cond_3

    move-object v6, v5

    .line 1303
    .local v6, "it":Landroid/widget/TextView;
    const/4 v7, 0x0

    .line 477
    .local v7, "$i$a$-takeIf-KugouRushFragment$applyPortalConfig$1$1":I
    invoke-virtual {v6}, Landroid/widget/TextView;->getVisibility()I

    move-result v8

    if-nez v8, :cond_2

    move v6, v0

    goto :goto_2

    :cond_2
    move v6, v1

    .end local v6    # "it":Landroid/widget/TextView;
    .end local v7    # "$i$a$-takeIf-KugouRushFragment$applyPortalConfig$1$1":I
    :goto_2
    if-eqz v6, :cond_3

    goto :goto_3

    :cond_3
    move-object v5, v2

    :goto_3
    if-nez v5, :cond_4

    goto :goto_4

    :cond_4
    move-object v6, v3

    check-cast v6, Ljava/lang/CharSequence;

    invoke-virtual {v5, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 478
    .end local v3    # "it":Ljava/lang/String;
    .end local v4    # "$i$a$-let-KugouRushFragment$applyPortalConfig$1":I
    :cond_5
    :goto_4
    iget-object v3, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->accountListHintText:Landroid/widget/TextView;

    if-nez v3, :cond_6

    goto :goto_7

    :cond_6
    if-eqz p1, :cond_7

    invoke-virtual {p1}, Lcom/goudong/jd/data/model/KugouPortalConfig;->getAccountListHint()Ljava/lang/String;

    move-result-object v4

    goto :goto_5

    :cond_7
    move-object v4, v2

    :goto_5
    invoke-direct {p0, v4}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->kugouPortalCopy(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    if-eqz v4, :cond_8

    check-cast v4, Ljava/lang/CharSequence;

    goto :goto_6

    .line 479
    :cond_8
    const-string v4, "\u6bcf\u4e2a\u8d26\u53f7\u5355\u72ec\u9009\u6863\u4f4d\u3002\u4f59\u989d\u4e0d\u591f\u7684\u6863\u4f4d\u4e0d\u80fd\u52fe\uff0c\u4e92\u4e0d\u5f71\u54cd\u3002"

    check-cast v4, Ljava/lang/CharSequence;

    .line 478
    :goto_6
    invoke-virtual {v3, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 480
    :goto_7
    if-eqz p1, :cond_9

    invoke-virtual {p1}, Lcom/goudong/jd/data/model/KugouPortalConfig;->getProxyCheckboxLabel()Ljava/lang/String;

    move-result-object v3

    goto :goto_8

    :cond_9
    move-object v3, v2

    :goto_8
    invoke-direct {p0, v3}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->kugouPortalCopy(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    if-eqz v3, :cond_b

    .line 1303
    .restart local v3    # "it":Ljava/lang/String;
    const/4 v4, 0x0

    .line 480
    .local v4, "$i$a$-let-KugouRushFragment$applyPortalConfig$2":I
    iget-object v5, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->useProxyCheck:Landroid/widget/CheckBox;

    if-nez v5, :cond_a

    goto :goto_9

    :cond_a
    move-object v6, v3

    check-cast v6, Ljava/lang/CharSequence;

    invoke-virtual {v5, v6}, Landroid/widget/CheckBox;->setText(Ljava/lang/CharSequence;)V

    .line 481
    .end local v3    # "it":Ljava/lang/String;
    .end local v4    # "$i$a$-let-KugouRushFragment$applyPortalConfig$2":I
    :cond_b
    :goto_9
    iget-object v3, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->levelHintText:Landroid/widget/TextView;

    if-nez v3, :cond_c

    goto :goto_c

    :cond_c
    if-eqz p1, :cond_d

    invoke-virtual {p1}, Lcom/goudong/jd/data/model/KugouPortalConfig;->getLevelHint()Ljava/lang/String;

    move-result-object v4

    goto :goto_a

    :cond_d
    move-object v4, v2

    :goto_a
    invoke-direct {p0, v4}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->kugouPortalCopy(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    if-eqz v4, :cond_e

    check-cast v4, Ljava/lang/CharSequence;

    goto :goto_b

    .line 482
    :cond_e
    const-string v4, "\u5148\u9009\u62e9\u8d26\u53f7\uff0c\u518d\u8bfb\u53d6\u6863\u4f4d\u3002"

    check-cast v4, Ljava/lang/CharSequence;

    .line 481
    :goto_b
    invoke-virtual {v3, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 483
    :goto_c
    nop

    .line 484
    if-eqz p1, :cond_f

    invoke-virtual {p1}, Lcom/goudong/jd/data/model/KugouPortalConfig;->getGuideText()Ljava/lang/String;

    move-result-object v2

    :cond_f
    invoke-direct {p0, v2}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->kugouPortalCopy(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    if-nez v2, :cond_10

    .line 485
    const-string v2, "\ud83d\udca1 \u62a2\u5151\u8bf4\u660e\n\uff08\u914d\u7f6e\u52a0\u8f7d\u5931\u8d25\uff0c\u8bf7\u4e0b\u62c9\u5237\u65b0\uff09"

    .line 483
    :cond_10
    invoke-direct {p0, v2}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->bindGuideText(Ljava/lang/String;)V

    .line 487
    iget-object v2, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->rushModeCard:Landroid/view/View;

    const/16 v3, 0x8

    if-nez v2, :cond_11

    goto :goto_e

    :cond_11
    invoke-direct {p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->canChooseRushMode()Z

    move-result v4

    if-eqz v4, :cond_12

    move v4, v1

    goto :goto_d

    :cond_12
    move v4, v3

    :goto_d
    invoke-virtual {v2, v4}, Landroid/view/View;->setVisibility(I)V

    .line 488
    :goto_e
    iput-boolean v0, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->rushModeSwitchUpdating:Z

    .line 489
    iget-object v0, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->autoRushSwitch:Landroid/widget/Switch;

    if-nez v0, :cond_13

    goto :goto_f

    :cond_13
    invoke-direct {p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->isAutoRushMode()Z

    move-result v2

    invoke-virtual {v0, v2}, Landroid/widget/Switch;->setChecked(Z)V

    .line 490
    :goto_f
    iput-boolean v1, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->rushModeSwitchUpdating:Z

    .line 491
    iget-object v0, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->proxySettingsCard:Landroid/view/View;

    if-nez v0, :cond_14

    goto :goto_10

    :cond_14
    invoke-direct {p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->isAutoRushMode()Z

    move-result v2

    if-eqz v2, :cond_15

    invoke-direct {p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->isDebugRushMode()Z

    move-result v2

    if-nez v2, :cond_15

    move v1, v3

    :cond_15
    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    .line 492
    :goto_10
    invoke-direct {p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->syncStartButton()V

    .line 493
    invoke-direct {p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->updateTimeDisplay()V

    .line 494
    invoke-direct {p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->refreshConfigStaleHint()V

    .line 495
    return-void
.end method

.method static synthetic applyPortalConfig$default(Lcom/goudong/jd/ui/projects/KugouRushFragment;Lcom/goudong/jd/data/model/KugouPortalConfig;ZILjava/lang/Object;)V
    .locals 0

    .line 474
    and-int/lit8 p3, p3, 0x2

    if-eqz p3, :cond_0

    const/4 p2, 0x0

    :cond_0
    invoke-direct {p0, p1, p2}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->applyPortalConfig(Lcom/goudong/jd/data/model/KugouPortalConfig;Z)V

    return-void
.end method

.method private final applyRestoredKugouTask(Lcom/goudong/jd/data/model/KugouWithdrawTask;Lorg/json/JSONObject;)V
    .locals 7
    .param p1, "task"    # Lcom/goudong/jd/data/model/KugouWithdrawTask;
    .param p2, "json"    # Lorg/json/JSONObject;

    .line 1253
    invoke-virtual {p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->getViewLifecycleOwner()Landroidx/lifecycle/LifecycleOwner;

    move-result-object v0

    const-string v1, "getViewLifecycleOwner(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v0}, Landroidx/lifecycle/LifecycleOwnerKt;->getLifecycleScope(Landroidx/lifecycle/LifecycleOwner;)Landroidx/lifecycle/LifecycleCoroutineScope;

    move-result-object v0

    move-object v1, v0

    check-cast v1, Lkotlinx/coroutines/CoroutineScope;

    new-instance v0, Lcom/goudong/jd/ui/projects/KugouRushFragment$applyRestoredKugouTask$1;

    const/4 v2, 0x0

    invoke-direct {v0, p1, p0, p2, v2}, Lcom/goudong/jd/ui/projects/KugouRushFragment$applyRestoredKugouTask$1;-><init>(Lcom/goudong/jd/data/model/KugouWithdrawTask;Lcom/goudong/jd/ui/projects/KugouRushFragment;Lorg/json/JSONObject;Lkotlin/coroutines/Continuation;)V

    move-object v4, v0

    check-cast v4, Lkotlin/jvm/functions/Function2;

    const/4 v5, 0x3

    const/4 v6, 0x0

    const/4 v3, 0x0

    invoke-static/range {v1 .. v6}, Lkotlinx/coroutines/BuildersKt;->launch$default(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/CoroutineContext;Lkotlinx/coroutines/CoroutineStart;Lkotlin/jvm/functions/Function2;ILjava/lang/Object;)Lkotlinx/coroutines/Job;

    .line 1293
    return-void
.end method

.method private final applyTaskResult(Lcom/goudong/jd/data/model/KugouWithdrawTask;Z)Z
    .locals 6
    .param p1, "task"    # Lcom/goudong/jd/data/model/KugouWithdrawTask;
    .param p2, "immediate"    # Z

    .line 1067
    invoke-virtual {p1}, Lcom/goudong/jd/data/model/KugouWithdrawTask;->getLogs()Ljava/util/List;

    move-result-object v0

    invoke-direct {p0, v0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->flushTaskLogs(Ljava/util/List;)V

    .line 1068
    invoke-virtual {p1}, Lcom/goudong/jd/data/model/KugouWithdrawTask;->getStatus()Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x0

    if-eqz v0, :cond_12

    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v2

    const/4 v3, 0x1

    const/4 v4, 0x0

    sparse-switch v2, :sswitch_data_0

    goto/16 :goto_6

    :sswitch_0
    const-string v2, "running"

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_0

    goto/16 :goto_6

    .line 1078
    :cond_0
    iget-object v0, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->countdownJob:Lkotlinx/coroutines/Job;

    if-eqz v0, :cond_1

    invoke-static {v0, v4, v3, v4}, Lkotlinx/coroutines/Job$DefaultImpls;->cancel$default(Lkotlinx/coroutines/Job;Ljava/util/concurrent/CancellationException;ILjava/lang/Object;)V

    .line 1079
    :cond_1
    iget-object v0, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->countdownText:Landroid/widget/TextView;

    if-nez v0, :cond_2

    goto :goto_0

    :cond_2
    const-string v2, "\ud83d\ude80 \u540e\u7aef\u6b63\u5728\u62a2\u5151..."

    check-cast v2, Ljava/lang/CharSequence;

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1080
    :goto_0
    return v1

    .line 1068
    :sswitch_1
    const-string v2, "pending"

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_3

    goto/16 :goto_6

    .line 1070
    :cond_3
    iget-object v0, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->countdownJob:Lkotlinx/coroutines/Job;

    if-eqz v0, :cond_4

    invoke-interface {v0}, Lkotlinx/coroutines/Job;->isActive()Z

    move-result v0

    if-ne v0, v3, :cond_4

    move v0, v3

    goto :goto_1

    :cond_4
    move v0, v1

    .line 1071
    .local v0, "countdownRunning":Z
    :goto_1
    if-nez p2, :cond_9

    if-nez v0, :cond_9

    .line 1072
    invoke-virtual {p1}, Lcom/goudong/jd/data/model/KugouWithdrawTask;->getTargetHour()Ljava/lang/Integer;

    move-result-object v2

    if-eqz v2, :cond_5

    check-cast v2, Ljava/lang/Number;

    invoke-virtual {v2}, Ljava/lang/Number;->intValue()I

    move-result v2

    .line 1303
    .local v2, "it":I
    const/4 v4, 0x0

    .line 1072
    .local v4, "$i$a$-let-KugouRushFragment$applyTaskResult$h$1":I
    sget-object v5, Lcom/goudong/jd/ui/projects/KugouTimeHelper;->INSTANCE:Lcom/goudong/jd/ui/projects/KugouTimeHelper;

    invoke-virtual {v5, v2}, Lcom/goudong/jd/ui/projects/KugouTimeHelper;->formatHour(I)Ljava/lang/String;

    move-result-object v2

    .end local v2    # "it":I
    .end local v4    # "$i$a$-let-KugouRushFragment$applyTaskResult$h$1":I
    if-nez v2, :cond_6

    :cond_5
    const-string v2, ""

    .line 1073
    .local v2, "h":Ljava/lang/String;
    :cond_6
    iget-object v4, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->countdownText:Landroid/widget/TextView;

    if-nez v4, :cond_7

    goto :goto_3

    :cond_7
    move-object v5, v2

    check-cast v5, Ljava/lang/CharSequence;

    invoke-static {v5}, Lkotlin/text/StringsKt;->isBlank(Ljava/lang/CharSequence;)Z

    move-result v5

    xor-int/2addr v3, v5

    if-eqz v3, :cond_8

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "\u23f3 \u7b49\u5f85 "

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v5, " \u5f00\u7a97\u2026"

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    goto :goto_2

    :cond_8
    const-string v3, "\u23f3 \u7b49\u5f85\u540e\u7aef\u5f00\u7a97\u2026"

    :goto_2
    check-cast v3, Ljava/lang/CharSequence;

    invoke-virtual {v4, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1075
    .end local v2    # "h":Ljava/lang/String;
    :cond_9
    :goto_3
    return v1

    .line 1068
    .end local v0    # "countdownRunning":Z
    :sswitch_2
    const-string v2, "failed"

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_a

    goto :goto_6

    .line 1091
    :cond_a
    iget-object v0, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->monitorJob:Lkotlinx/coroutines/Job;

    if-eqz v0, :cond_b

    invoke-static {v0, v4, v3, v4}, Lkotlinx/coroutines/Job$DefaultImpls;->cancel$default(Lkotlinx/coroutines/Job;Ljava/util/concurrent/CancellationException;ILjava/lang/Object;)V

    .line 1092
    :cond_b
    iget-object v0, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->countdownJob:Lkotlinx/coroutines/Job;

    if-eqz v0, :cond_c

    invoke-static {v0, v4, v3, v4}, Lkotlinx/coroutines/Job$DefaultImpls;->cancel$default(Lkotlinx/coroutines/Job;Ljava/util/concurrent/CancellationException;ILjava/lang/Object;)V

    .line 1093
    :cond_c
    iget-object v0, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->countdownText:Landroid/widget/TextView;

    if-nez v0, :cond_d

    goto :goto_4

    :cond_d
    const-string v1, "\u274c \u62a2\u5151\u5931\u8d25"

    check-cast v1, Ljava/lang/CharSequence;

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1094
    :goto_4
    const-string v0, "--- \u4efb\u52a1\u5931\u8d25 ---"

    invoke-direct {p0, v0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->appendLog(Ljava/lang/String;)V

    .line 1095
    invoke-direct {p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->restoreWithdrawUi()V

    .line 1096
    return v3

    .line 1068
    :sswitch_3
    const-string v2, "completed"

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_e

    goto :goto_6

    .line 1083
    :cond_e
    iget-object v0, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->monitorJob:Lkotlinx/coroutines/Job;

    if-eqz v0, :cond_f

    invoke-static {v0, v4, v3, v4}, Lkotlinx/coroutines/Job$DefaultImpls;->cancel$default(Lkotlinx/coroutines/Job;Ljava/util/concurrent/CancellationException;ILjava/lang/Object;)V

    .line 1084
    :cond_f
    iget-object v0, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->countdownJob:Lkotlinx/coroutines/Job;

    if-eqz v0, :cond_10

    invoke-static {v0, v4, v3, v4}, Lkotlinx/coroutines/Job$DefaultImpls;->cancel$default(Lkotlinx/coroutines/Job;Ljava/util/concurrent/CancellationException;ILjava/lang/Object;)V

    .line 1085
    :cond_10
    iget-object v0, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->countdownText:Landroid/widget/TextView;

    if-nez v0, :cond_11

    goto :goto_5

    :cond_11
    const-string v1, "\u2705 \u62a2\u5151\u5df2\u5b8c\u6210"

    check-cast v1, Ljava/lang/CharSequence;

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1086
    :goto_5
    const-string v0, "--- \u4efb\u52a1\u7ed3\u675f ---"

    invoke-direct {p0, v0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->appendLog(Ljava/lang/String;)V

    .line 1087
    invoke-direct {p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->restoreWithdrawUi()V

    .line 1088
    return v3

    .line 1099
    :cond_12
    :goto_6
    return v1

    nop

    :sswitch_data_0
    .sparse-switch
        -0x539f09b5 -> :sswitch_3
        -0x4c696bc3 -> :sswitch_2
        -0x28af7669 -> :sswitch_1
        0x5c6f15bf -> :sswitch_0
    .end sparse-switch
.end method

.method private final autoPrepMin()I
    .locals 4

    .line 568
    iget-object v0, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->portalConfig:Lcom/goudong/jd/data/model/KugouPortalConfig;

    if-eqz v0, :cond_2

    invoke-virtual {v0}, Lcom/goudong/jd/data/model/KugouPortalConfig;->getAutoPrepMin()Ljava/lang/Integer;

    move-result-object v0

    if-eqz v0, :cond_2

    move-object v1, v0

    check-cast v1, Ljava/lang/Number;

    invoke-virtual {v1}, Ljava/lang/Number;->intValue()I

    move-result v1

    .line 1303
    .local v1, "it":I
    const/4 v2, 0x0

    .line 568
    .local v2, "$i$a$-takeIf-KugouRushFragment$autoPrepMin$1":I
    if-lez v1, :cond_0

    const/4 v3, 0x1

    goto :goto_0

    :cond_0
    const/4 v3, 0x0

    .end local v1    # "it":I
    .end local v2    # "$i$a$-takeIf-KugouRushFragment$autoPrepMin$1":I
    :goto_0
    if-eqz v3, :cond_1

    goto :goto_1

    :cond_1
    const/4 v0, 0x0

    :goto_1
    if-eqz v0, :cond_2

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    goto :goto_2

    :cond_2
    const/16 v0, 0xa

    :goto_2
    return v0
.end method

.method private final bindGuideText(Ljava/lang/String;)V
    .locals 14
    .param p1, "raw"    # Ljava/lang/String;

    .line 510
    iget-object v0, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->guideHost:Landroid/widget/LinearLayout;

    if-nez v0, :cond_0

    return-void

    .line 511
    .local v0, "host":Landroid/widget/LinearLayout;
    :cond_0
    invoke-virtual {p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->getContext()Landroid/content/Context;

    move-result-object v1

    if-nez v1, :cond_1

    return-void

    .line 512
    .local v1, "ctx":Landroid/content/Context;
    :cond_1
    invoke-virtual {v0}, Landroid/widget/LinearLayout;->removeAllViews()V

    .line 513
    move-object v2, p1

    check-cast v2, Ljava/lang/CharSequence;

    invoke-static {v2}, Lkotlin/text/StringsKt;->lines(Ljava/lang/CharSequence;)Ljava/util/List;

    move-result-object v2

    check-cast v2, Ljava/lang/Iterable;

    .local v2, "$this$map$iv":Ljava/lang/Iterable;
    const/4 v3, 0x0

    .line 1306
    .local v3, "$i$f$map":I
    new-instance v4, Ljava/util/ArrayList;

    const/16 v5, 0xa

    invoke-static {v2, v5}, Lkotlin/collections/CollectionsKt;->collectionSizeOrDefault(Ljava/lang/Iterable;I)I

    move-result v5

    invoke-direct {v4, v5}, Ljava/util/ArrayList;-><init>(I)V

    check-cast v4, Ljava/util/Collection;

    .local v4, "destination$iv$iv":Ljava/util/Collection;
    move-object v5, v2

    .local v5, "$this$mapTo$iv$iv":Ljava/lang/Iterable;
    const/4 v6, 0x0

    .line 1307
    .local v6, "$i$f$mapTo":I
    invoke-interface {v5}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v7

    :goto_0
    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    move-result v8

    if-eqz v8, :cond_2

    invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v8

    .line 1308
    .local v8, "item$iv$iv":Ljava/lang/Object;
    move-object v9, v8

    check-cast v9, Ljava/lang/String;

    .local v9, "it":Ljava/lang/String;
    const/4 v10, 0x0

    .line 513
    .local v10, "$i$a$-map-KugouRushFragment$bindGuideText$lines$1":I
    move-object v11, v9

    check-cast v11, Ljava/lang/CharSequence;

    invoke-static {v11}, Lkotlin/text/StringsKt;->trim(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v11

    invoke-virtual {v11}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v11

    .line 1308
    .end local v9    # "it":Ljava/lang/String;
    .end local v10    # "$i$a$-map-KugouRushFragment$bindGuideText$lines$1":I
    invoke-interface {v4, v11}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_0

    .line 1309
    .end local v8    # "item$iv$iv":Ljava/lang/Object;
    :cond_2
    nop

    .end local v4    # "destination$iv$iv":Ljava/util/Collection;
    .end local v5    # "$this$mapTo$iv$iv":Ljava/lang/Iterable;
    .end local v6    # "$i$f$mapTo":I
    check-cast v4, Ljava/util/List;

    .line 1306
    nop

    .end local v2    # "$this$map$iv":Ljava/lang/Iterable;
    .end local v3    # "$i$f$map":I
    check-cast v4, Ljava/lang/Iterable;

    .line 513
    move-object v2, v4

    .local v2, "$this$filter$iv":Ljava/lang/Iterable;
    const/4 v3, 0x0

    .line 1310
    .local v3, "$i$f$filter":I
    new-instance v4, Ljava/util/ArrayList;

    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    check-cast v4, Ljava/util/Collection;

    .restart local v4    # "destination$iv$iv":Ljava/util/Collection;
    move-object v5, v2

    .local v5, "$this$filterTo$iv$iv":Ljava/lang/Iterable;
    const/4 v6, 0x0

    .line 1311
    .local v6, "$i$f$filterTo":I
    invoke-interface {v5}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v7

    :cond_3
    :goto_1
    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    move-result v8

    const/4 v9, 0x1

    const/4 v10, 0x0

    if-eqz v8, :cond_5

    invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v8

    .local v8, "element$iv$iv":Ljava/lang/Object;
    move-object v11, v8

    check-cast v11, Ljava/lang/String;

    .local v11, "it":Ljava/lang/String;
    const/4 v12, 0x0

    .line 513
    .local v12, "$i$a$-filter-KugouRushFragment$bindGuideText$lines$2":I
    move-object v13, v11

    check-cast v13, Ljava/lang/CharSequence;

    invoke-interface {v13}, Ljava/lang/CharSequence;->length()I

    move-result v13

    if-lez v13, :cond_4

    goto :goto_2

    :cond_4
    move v9, v10

    .line 1311
    .end local v11    # "it":Ljava/lang/String;
    .end local v12    # "$i$a$-filter-KugouRushFragment$bindGuideText$lines$2":I
    :goto_2
    if-eqz v9, :cond_3

    invoke-interface {v4, v8}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_1

    .line 1312
    .end local v8    # "element$iv$iv":Ljava/lang/Object;
    :cond_5
    nop

    .end local v4    # "destination$iv$iv":Ljava/util/Collection;
    .end local v5    # "$this$filterTo$iv$iv":Ljava/lang/Iterable;
    .end local v6    # "$i$f$filterTo":I
    check-cast v4, Ljava/util/List;

    .line 1310
    nop

    .line 513
    .end local v2    # "$this$filter$iv":Ljava/lang/Iterable;
    .end local v3    # "$i$f$filter":I
    move-object v2, v4

    .line 514
    .local v2, "lines":Ljava/util/List;
    nop

    .line 515
    invoke-interface {v2}, Ljava/util/List;->isEmpty()Z

    move-result v3

    const-string v4, "\u62a2\u5151\u8bf4\u660e"

    if-eqz v3, :cond_6

    move-object v3, p1

    check-cast v3, Ljava/lang/CharSequence;

    invoke-static {v3}, Lkotlin/text/StringsKt;->trim(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Lkotlin/collections/CollectionsKt;->listOf(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v3

    invoke-static {v4, v3}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v3

    goto :goto_4

    .line 516
    :cond_6
    invoke-static {v2}, Lkotlin/collections/CollectionsKt;->first(Ljava/util/List;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/CharSequence;

    const-string v5, "\u8bf4\u660e"

    check-cast v5, Ljava/lang/CharSequence;

    const/4 v6, 0x2

    const/4 v7, 0x0

    invoke-static {v3, v5, v10, v6, v7}, Lkotlin/text/StringsKt;->contains$default(Ljava/lang/CharSequence;Ljava/lang/CharSequence;ZILjava/lang/Object;)Z

    move-result v3

    const-string v5, "\ud83d\udca1"

    if-nez v3, :cond_8

    invoke-static {v2}, Lkotlin/collections/CollectionsKt;->first(Ljava/util/List;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/String;

    invoke-static {v3, v5, v10, v6, v7}, Lkotlin/text/StringsKt;->startsWith$default(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_7

    goto :goto_3

    .line 519
    :cond_7
    invoke-static {v4, v2}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v3

    goto :goto_4

    .line 517
    :cond_8
    :goto_3
    invoke-static {v2}, Lkotlin/collections/CollectionsKt;->first(Ljava/util/List;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/String;

    check-cast v5, Ljava/lang/CharSequence;

    invoke-static {v3, v5}, Lkotlin/text/StringsKt;->removePrefix(Ljava/lang/String;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v3

    check-cast v3, Ljava/lang/CharSequence;

    invoke-static {v3}, Lkotlin/text/StringsKt;->trim(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v3

    move-object v5, v2

    check-cast v5, Ljava/lang/Iterable;

    invoke-static {v5, v9}, Lkotlin/collections/CollectionsKt;->drop(Ljava/lang/Iterable;I)Ljava/util/List;

    move-result-object v5

    invoke-static {v3, v5}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v3

    .line 514
    :goto_4
    invoke-virtual {v3}, Lkotlin/Pair;->component1()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/String;

    .local v5, "title":Ljava/lang/String;
    invoke-virtual {v3}, Lkotlin/Pair;->component2()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/util/List;

    .line 521
    .local v3, "body":Ljava/util/List;
    nop

    .line 522
    nop

    .line 523
    move-object v6, v5

    check-cast v6, Ljava/lang/CharSequence;

    invoke-static {v6}, Lkotlin/text/StringsKt;->isBlank(Ljava/lang/CharSequence;)Z

    move-result v7

    if-eqz v7, :cond_9

    .line 1303
    const/4 v6, 0x0

    .line 523
    .local v6, "$i$a$-ifBlank-KugouRushFragment$bindGuideText$1":I
    nop

    .end local v6    # "$i$a$-ifBlank-KugouRushFragment$bindGuideText$1":I
    goto :goto_5

    :cond_9
    move-object v4, v6

    :goto_5
    check-cast v4, Ljava/lang/String;

    .line 524
    move-object v6, v3

    check-cast v6, Ljava/util/Collection;

    invoke-interface {v6}, Ljava/util/Collection;->isEmpty()Z

    move-result v7

    if-eqz v7, :cond_a

    .line 1303
    const/4 v6, 0x0

    .line 524
    .local v6, "$i$a$-ifEmpty-KugouRushFragment$bindGuideText$2":I
    move-object v7, p1

    check-cast v7, Ljava/lang/CharSequence;

    invoke-static {v7}, Lkotlin/text/StringsKt;->trim(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-static {v7}, Lkotlin/collections/CollectionsKt;->listOf(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v6

    .end local v6    # "$i$a$-ifEmpty-KugouRushFragment$bindGuideText$2":I
    :cond_a
    check-cast v6, Ljava/util/List;

    .line 522
    invoke-static {v1, v4, v6}, Lcom/goudong/jd/ui/common/UiKitKt;->rushInstructionBlock(Landroid/content/Context;Ljava/lang/String;Ljava/util/List;)Landroid/widget/LinearLayout;

    move-result-object v4

    check-cast v4, Landroid/view/View;

    .line 521
    invoke-virtual {v0, v4}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 527
    return-void
.end method

.method private final buildPage()V
    .locals 27

    .line 204
    move-object/from16 v0, p0

    invoke-virtual/range {p0 .. p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->requireContext()Landroid/content/Context;

    move-result-object v1

    const-string v2, "requireContext(...)"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 205
    .local v1, "ctx":Landroid/content/Context;
    iget-object v3, v0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->contentRoot:Landroid/widget/LinearLayout;

    const-string v9, "contentRoot"

    const/4 v10, 0x0

    if-nez v3, :cond_0

    invoke-static {v9}, Lkotlin/jvm/internal/Intrinsics;->throwUninitializedPropertyAccessException(Ljava/lang/String;)V

    move-object v3, v10

    :cond_0
    invoke-virtual {v3}, Landroid/widget/LinearLayout;->removeAllViews()V

    .line 206
    invoke-direct/range {p0 .. p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->isEmbeddedInHub()Z

    move-result v11

    .line 207
    .local v11, "inHub":Z
    const/4 v12, 0x2

    const/16 v13, 0x8

    const/4 v14, 0x0

    if-eqz v11, :cond_2

    .line 208
    iput-object v10, v0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->pageSubtitleText:Landroid/widget/TextView;

    .line 209
    invoke-static {v1}, Lcom/goudong/jd/ui/common/UiKitKt;->pageContentPad(Landroid/content/Context;)I

    move-result v3

    .line 210
    .local v3, "p":I
    iget-object v4, v0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->contentRoot:Landroid/widget/LinearLayout;

    if-nez v4, :cond_1

    invoke-static {v9}, Lkotlin/jvm/internal/Intrinsics;->throwUninitializedPropertyAccessException(Ljava/lang/String;)V

    move-object v4, v10

    :cond_1
    invoke-static {v1, v12}, Lcom/goudong/jd/ui/common/UiKitKt;->dp(Landroid/content/Context;I)I

    move-result v5

    invoke-virtual {v4, v3, v5, v3, v3}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .end local v3    # "p":I
    goto :goto_2

    .line 212
    :cond_2
    invoke-direct/range {p0 .. p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->getRushProduct()Ljava/lang/String;

    move-result-object v3

    const-string v4, "std"

    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_3

    const-string v3, "\ud83c\udfa7 \u9177\u72d7\u666e\u901a\u7248"

    goto :goto_0

    :cond_3
    const-string v3, "\ud83c\udfa7 \u9177\u72d7\u6982\u5ff5\u7248"

    :goto_0
    move-object v4, v3

    .line 213
    .local v4, "main":Ljava/lang/String;
    iget-object v3, v0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->contentRoot:Landroid/widget/LinearLayout;

    if-nez v3, :cond_4

    invoke-static {v9}, Lkotlin/jvm/internal/Intrinsics;->throwUninitializedPropertyAccessException(Ljava/lang/String;)V

    move-object v15, v10

    goto :goto_1

    :cond_4
    move-object v15, v3

    :goto_1
    sget-object v3, Lcom/goudong/jd/ui/projects/KugouTimeHelper;->INSTANCE:Lcom/goudong/jd/ui/projects/KugouTimeHelper;

    invoke-virtual {v3}, Lcom/goudong/jd/ui/projects/KugouTimeHelper;->getWithdrawHours()Ljava/util/List;

    move-result-object v5

    const/4 v7, 0x4

    const/4 v8, 0x0

    const/4 v6, 0x0

    move-object v3, v1

    invoke-static/range {v3 .. v8}, Lcom/goudong/jd/ui/common/UiKitKt;->pageRushTitleWithSessions$default(Landroid/content/Context;Ljava/lang/String;Ljava/util/List;IILjava/lang/Object;)Landroid/widget/TextView;

    move-result-object v3

    check-cast v3, Landroid/view/View;

    invoke-virtual {v15, v3}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 214
    const-string v3, ""

    invoke-static {v1, v3, v14, v12, v10}, Lcom/goudong/jd/ui/common/UiKitKt;->pageScreenSubtitle$default(Landroid/content/Context;Ljava/lang/String;IILjava/lang/Object;)Landroid/widget/TextView;

    move-result-object v3

    .line 1303
    move-object v5, v3

    .local v5, "$this$buildPage_u24lambda_u242":Landroid/widget/TextView;
    const/4 v6, 0x0

    .line 214
    .local v6, "$i$a$-apply-KugouRushFragment$buildPage$1":I
    invoke-virtual {v5, v13}, Landroid/widget/TextView;->setVisibility(I)V

    .end local v5    # "$this$buildPage_u24lambda_u242":Landroid/widget/TextView;
    .end local v6    # "$i$a$-apply-KugouRushFragment$buildPage$1":I
    iput-object v3, v0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->pageSubtitleText:Landroid/widget/TextView;

    .line 215
    iget-object v3, v0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->contentRoot:Landroid/widget/LinearLayout;

    if-nez v3, :cond_5

    invoke-static {v9}, Lkotlin/jvm/internal/Intrinsics;->throwUninitializedPropertyAccessException(Ljava/lang/String;)V

    move-object v3, v10

    :cond_5
    iget-object v5, v0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->pageSubtitleText:Landroid/widget/TextView;

    check-cast v5, Landroid/view/View;

    invoke-virtual {v3, v5}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 218
    .end local v4    # "main":Ljava/lang/String;
    :goto_2
    const/4 v3, 0x1

    invoke-static {v1, v14, v3, v10}, Lcom/goudong/jd/ui/common/UiKitKt;->authWarningBanner$default(Landroid/content/Context;IILjava/lang/Object;)Landroid/widget/TextView;

    move-result-object v4

    iput-object v4, v0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->authHint:Landroid/widget/TextView;

    .line 219
    iget-object v4, v0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->contentRoot:Landroid/widget/LinearLayout;

    if-nez v4, :cond_6

    invoke-static {v9}, Lkotlin/jvm/internal/Intrinsics;->throwUninitializedPropertyAccessException(Ljava/lang/String;)V

    move-object v4, v10

    :cond_6
    iget-object v5, v0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->authHint:Landroid/widget/TextView;

    check-cast v5, Landroid/view/View;

    invoke-virtual {v4, v5}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 221
    new-instance v4, Landroid/widget/TextView;

    invoke-direct {v4, v1}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object v5, v4

    .local v5, "$this$buildPage_u24lambda_u244":Landroid/widget/TextView;
    const/4 v6, 0x0

    .line 222
    .local v6, "$i$a$-apply-KugouRushFragment$buildPage$2":I
    invoke-virtual {v5, v13}, Landroid/widget/TextView;->setVisibility(I)V

    .line 223
    sget v7, Lcom/goudong/jd/R$color;->tag_cash_text:I

    invoke-static {v1, v7}, Landroidx/core/content/ContextCompat;->getColor(Landroid/content/Context;I)I

    move-result v7

    invoke-virtual {v5, v7}, Landroid/widget/TextView;->setTextColor(I)V

    .line 224
    const/high16 v7, 0x41400000    # 12.0f

    invoke-static {v5, v7}, Lcom/goudong/jd/ui/common/AppTypographyKt;->setTextSp(Landroid/widget/TextView;F)V

    .line 225
    invoke-static {v1, v12}, Lcom/goudong/jd/ui/common/UiKitKt;->dp(Landroid/content/Context;I)I

    move-result v8

    int-to-float v8, v8

    const/high16 v15, 0x3f800000    # 1.0f

    invoke-virtual {v5, v8, v15}, Landroid/widget/TextView;->setLineSpacing(FF)V

    .line 226
    const/16 v8, 0xc

    invoke-static {v1, v8}, Lcom/goudong/jd/ui/common/UiKitKt;->dp(Landroid/content/Context;I)I

    move-result v12

    const/16 v7, 0xa

    invoke-static {v1, v7}, Lcom/goudong/jd/ui/common/UiKitKt;->dp(Landroid/content/Context;I)I

    move-result v15

    invoke-static {v1, v8}, Lcom/goudong/jd/ui/common/UiKitKt;->dp(Landroid/content/Context;I)I

    move-result v13

    invoke-static {v1, v7}, Lcom/goudong/jd/ui/common/UiKitKt;->dp(Landroid/content/Context;I)I

    move-result v8

    invoke-virtual {v5, v12, v15, v13, v8}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 227
    new-instance v8, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v8}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    move-object v12, v8

    .local v12, "$this$buildPage_u24lambda_u244_u24lambda_u243":Landroid/graphics/drawable/GradientDrawable;
    const/4 v13, 0x0

    .line 228
    .local v13, "$i$a$-apply-KugouRushFragment$buildPage$2$1":I
    sget v15, Lcom/goudong/jd/R$color;->tag_cash_bg:I

    invoke-static {v1, v15}, Landroidx/core/content/ContextCompat;->getColor(Landroid/content/Context;I)I

    move-result v15

    invoke-virtual {v12, v15}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 229
    invoke-static {v1, v7}, Lcom/goudong/jd/ui/common/UiKitKt;->dp(Landroid/content/Context;I)I

    move-result v15

    int-to-float v15, v15

    invoke-virtual {v12, v15}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 230
    invoke-static {v1, v3}, Lcom/goudong/jd/ui/common/UiKitKt;->dp(Landroid/content/Context;I)I

    move-result v15

    sget v7, Lcom/goudong/jd/R$color;->tag_cash_text:I

    invoke-static {v1, v7}, Landroidx/core/content/ContextCompat;->getColor(Landroid/content/Context;I)I

    move-result v7

    invoke-virtual {v12, v15, v7}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    .line 231
    nop

    .line 227
    .end local v12    # "$this$buildPage_u24lambda_u244_u24lambda_u243":Landroid/graphics/drawable/GradientDrawable;
    .end local v13    # "$i$a$-apply-KugouRushFragment$buildPage$2$1":I
    check-cast v8, Landroid/graphics/drawable/Drawable;

    invoke-virtual {v5, v8}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 232
    invoke-static {v1, v14, v3, v10}, Lcom/goudong/jd/ui/common/UiKitKt;->cardInPageLayoutParams$default(Landroid/content/Context;IILjava/lang/Object;)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v7

    check-cast v7, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v5, v7}, Landroid/widget/TextView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 233
    nop

    .line 221
    .end local v5    # "$this$buildPage_u24lambda_u244":Landroid/widget/TextView;
    .end local v6    # "$i$a$-apply-KugouRushFragment$buildPage$2":I
    iput-object v4, v0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->cashShareHint:Landroid/widget/TextView;

    .line 234
    iget-object v4, v0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->contentRoot:Landroid/widget/LinearLayout;

    if-nez v4, :cond_7

    invoke-static {v9}, Lkotlin/jvm/internal/Intrinsics;->throwUninitializedPropertyAccessException(Ljava/lang/String;)V

    move-object v4, v10

    :cond_7
    iget-object v5, v0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->cashShareHint:Landroid/widget/TextView;

    check-cast v5, Landroid/view/View;

    invoke-virtual {v4, v5}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 236
    invoke-static {v1}, Lcom/goudong/jd/ui/common/UiKitKt;->cardView(Landroid/content/Context;)Landroid/widget/LinearLayout;

    move-result-object v4

    move-object v5, v4

    .local v5, "$this$buildPage_u24lambda_u248":Landroid/widget/LinearLayout;
    const/4 v6, 0x0

    .line 237
    .local v6, "$i$a$-apply-KugouRushFragment$buildPage$3":I
    invoke-static {v1, v14, v3, v10}, Lcom/goudong/jd/ui/common/UiKitKt;->cardInPageLayoutParams$default(Landroid/content/Context;IILjava/lang/Object;)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v7

    check-cast v7, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v5, v7}, Landroid/widget/LinearLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 238
    const-string v7, "\u53c2\u4e0e\u65b9\u5f0f"

    invoke-direct {v0, v7}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->label(Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v7

    check-cast v7, Landroid/view/View;

    invoke-virtual {v5, v7}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 239
    new-instance v7, Landroid/widget/LinearLayout;

    invoke-direct {v7, v1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object v8, v7

    .local v8, "$this$buildPage_u24lambda_u248_u24lambda_u245":Landroid/widget/LinearLayout;
    const/4 v12, 0x0

    .line 240
    .local v12, "$i$a$-apply-KugouRushFragment$buildPage$3$row$1":I
    invoke-virtual {v8, v14}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 241
    const/16 v13, 0x10

    invoke-virtual {v8, v13}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 242
    const/16 v15, 0x8

    invoke-static {v1, v15}, Lcom/goudong/jd/ui/common/UiKitKt;->dp(Landroid/content/Context;I)I

    move-result v13

    invoke-virtual {v8, v14, v13, v14, v14}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 243
    nop

    .line 239
    .end local v8    # "$this$buildPage_u24lambda_u248_u24lambda_u245":Landroid/widget/LinearLayout;
    .end local v12    # "$i$a$-apply-KugouRushFragment$buildPage$3$row$1":I
    nop

    .line 244
    .local v7, "row":Landroid/widget/LinearLayout;
    const-string v8, "\u5f00\u542f\uff1a\u6574\u70b9\u524d\u7cfb\u7edf\u81ea\u52a8\u67e5\u6863\u5e76\u5230\u70b9\u62a2\u5151\uff1b\u5173\u95ed\uff1a\u624b\u52a8\u9009\u6863\u5e76\u5b9a\u65f6\u53c2\u4e0e"

    invoke-static {v1, v8}, Lcom/goudong/jd/ui/common/UiKitKt;->bodyText(Landroid/content/Context;Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v8

    move-object v12, v8

    .local v12, "$this$buildPage_u24lambda_u248_u24lambda_u246":Landroid/widget/TextView;
    const/4 v13, 0x0

    .line 245
    .local v13, "$i$a$-apply-KugouRushFragment$buildPage$3$hint$1":I
    new-instance v15, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v10, -0x2

    const/high16 v3, 0x3f800000    # 1.0f

    invoke-direct {v15, v14, v10, v3}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    check-cast v15, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v12, v15}, Landroid/widget/TextView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 246
    nop

    .line 244
    .end local v12    # "$this$buildPage_u24lambda_u248_u24lambda_u246":Landroid/widget/TextView;
    .end local v13    # "$i$a$-apply-KugouRushFragment$buildPage$3$hint$1":I
    move-object v3, v8

    .line 247
    .local v3, "hint":Landroid/widget/TextView;
    new-instance v8, Landroid/widget/Switch;

    invoke-direct {v8, v1}, Landroid/widget/Switch;-><init>(Landroid/content/Context;)V

    move-object v12, v8

    .local v12, "$this$buildPage_u24lambda_u248_u24lambda_u247":Landroid/widget/Switch;
    const/4 v13, 0x0

    .line 248
    .local v13, "$i$a$-apply-KugouRushFragment$buildPage$3$1":I
    const-string v15, "\u81ea\u52a8\u62a2\u5151"

    check-cast v15, Ljava/lang/CharSequence;

    invoke-virtual {v12, v15}, Landroid/widget/Switch;->setText(Ljava/lang/CharSequence;)V

    .line 249
    const/4 v15, 0x1

    invoke-virtual {v12, v15}, Landroid/widget/Switch;->setChecked(Z)V

    .line 250
    iget-object v15, v0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->rushModeSwitchListener:Landroid/widget/CompoundButton$OnCheckedChangeListener;

    invoke-virtual {v12, v15}, Landroid/widget/Switch;->setOnCheckedChangeListener(Landroid/widget/CompoundButton$OnCheckedChangeListener;)V

    .line 251
    nop

    .line 247
    .end local v12    # "$this$buildPage_u24lambda_u248_u24lambda_u247":Landroid/widget/Switch;
    .end local v13    # "$i$a$-apply-KugouRushFragment$buildPage$3$1":I
    iput-object v8, v0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->autoRushSwitch:Landroid/widget/Switch;

    .line 252
    move-object v8, v3

    check-cast v8, Landroid/view/View;

    invoke-virtual {v7, v8}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 253
    iget-object v8, v0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->autoRushSwitch:Landroid/widget/Switch;

    check-cast v8, Landroid/view/View;

    invoke-virtual {v7, v8}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 254
    move-object v8, v7

    check-cast v8, Landroid/view/View;

    invoke-virtual {v5, v8}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 255
    nop

    .line 236
    .end local v3    # "hint":Landroid/widget/TextView;
    .end local v5    # "$this$buildPage_u24lambda_u248":Landroid/widget/LinearLayout;
    .end local v6    # "$i$a$-apply-KugouRushFragment$buildPage$3":I
    .end local v7    # "row":Landroid/widget/LinearLayout;
    check-cast v4, Landroid/view/View;

    iput-object v4, v0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->rushModeCard:Landroid/view/View;

    .line 256
    iget-object v3, v0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->contentRoot:Landroid/widget/LinearLayout;

    if-nez v3, :cond_8

    invoke-static {v9}, Lkotlin/jvm/internal/Intrinsics;->throwUninitializedPropertyAccessException(Ljava/lang/String;)V

    const/4 v3, 0x0

    :cond_8
    iget-object v4, v0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->rushModeCard:Landroid/view/View;

    invoke-virtual {v3, v4}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 258
    iget-object v3, v0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->contentRoot:Landroid/widget/LinearLayout;

    if-nez v3, :cond_9

    invoke-static {v9}, Lkotlin/jvm/internal/Intrinsics;->throwUninitializedPropertyAccessException(Ljava/lang/String;)V

    const/4 v3, 0x0

    :cond_9
    invoke-static {v1}, Lcom/goudong/jd/ui/common/UiKitKt;->cardView(Landroid/content/Context;)Landroid/widget/LinearLayout;

    move-result-object v4

    move-object v5, v4

    .local v5, "$this$buildPage_u24lambda_u2416":Landroid/widget/LinearLayout;
    const/4 v6, 0x0

    .line 259
    .local v6, "$i$a$-apply-KugouRushFragment$buildPage$4":I
    const/4 v7, 0x1

    const/4 v8, 0x0

    invoke-static {v1, v14, v7, v8}, Lcom/goudong/jd/ui/common/UiKitKt;->cardInPageLayoutParams$default(Landroid/content/Context;IILjava/lang/Object;)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v12

    check-cast v12, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v5, v12}, Landroid/widget/LinearLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 260
    const-string v7, "\u8d26\u53f7\u9009\u62e9"

    invoke-direct {v0, v7}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->label(Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v7

    check-cast v7, Landroid/view/View;

    invoke-virtual {v5, v7}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 261
    const-string v7, "\u6bcf\u4e2a\u8d26\u53f7\u5355\u72ec\u9009\u6863\u4f4d\u3002\u4f59\u989d\u4e0d\u591f\u7684\u6863\u4f4d\u4e0d\u80fd\u52fe\uff0c\u4e92\u4e0d\u5f71\u54cd\u3002"

    invoke-static {v1, v7}, Lcom/goudong/jd/ui/common/UiKitKt;->captionText(Landroid/content/Context;Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v7

    move-object v8, v7

    .local v8, "$this$buildPage_u24lambda_u2416_u24lambda_u249":Landroid/widget/TextView;
    const/4 v12, 0x0

    .line 262
    .local v12, "$i$a$-apply-KugouRushFragment$buildPage$4$1":I
    const/4 v13, 0x4

    invoke-static {v1, v13}, Lcom/goudong/jd/ui/common/UiKitKt;->dp(Landroid/content/Context;I)I

    move-result v15

    const/16 v13, 0x8

    invoke-static {v1, v13}, Lcom/goudong/jd/ui/common/UiKitKt;->dp(Landroid/content/Context;I)I

    move-result v10

    invoke-virtual {v8, v14, v15, v14, v10}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 263
    nop

    .line 261
    .end local v8    # "$this$buildPage_u24lambda_u2416_u24lambda_u249":Landroid/widget/TextView;
    .end local v12    # "$i$a$-apply-KugouRushFragment$buildPage$4$1":I
    iput-object v7, v0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->accountListHintText:Landroid/widget/TextView;

    .line 264
    iget-object v7, v0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->accountListHintText:Landroid/widget/TextView;

    check-cast v7, Landroid/view/View;

    invoke-virtual {v5, v7}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 265
    new-instance v7, Landroid/widget/LinearLayout;

    invoke-direct {v7, v1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 1303
    move-object v8, v7

    .local v8, "$this$buildPage_u24lambda_u2416_u24lambda_u2410":Landroid/widget/LinearLayout;
    const/4 v10, 0x0

    .line 265
    .local v10, "$i$a$-apply-KugouRushFragment$buildPage$4$2":I
    const/4 v12, 0x1

    invoke-virtual {v8, v12}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .end local v8    # "$this$buildPage_u24lambda_u2416_u24lambda_u2410":Landroid/widget/LinearLayout;
    .end local v10    # "$i$a$-apply-KugouRushFragment$buildPage$4$2":I
    iput-object v7, v0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->accountListWrap:Landroid/widget/LinearLayout;

    .line 266
    iget-object v7, v0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->accountListWrap:Landroid/widget/LinearLayout;

    check-cast v7, Landroid/view/View;

    invoke-virtual {v5, v7}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 267
    new-instance v7, Landroid/widget/LinearLayout;

    invoke-direct {v7, v1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object v8, v7

    .local v8, "$this$buildPage_u24lambda_u2416_u24lambda_u2411":Landroid/widget/LinearLayout;
    const/4 v10, 0x0

    .line 268
    .local v10, "$i$a$-apply-KugouRushFragment$buildPage$4$row$1":I
    invoke-virtual {v8, v14}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 269
    const/16 v12, 0x10

    invoke-virtual {v8, v12}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 270
    const/16 v12, 0xa

    invoke-static {v1, v12}, Lcom/goudong/jd/ui/common/UiKitKt;->dp(Landroid/content/Context;I)I

    move-result v13

    invoke-virtual {v8, v14, v13, v14, v14}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 271
    nop

    .line 267
    .end local v8    # "$this$buildPage_u24lambda_u2416_u24lambda_u2411":Landroid/widget/LinearLayout;
    .end local v10    # "$i$a$-apply-KugouRushFragment$buildPage$4$row$1":I
    nop

    .line 272
    .restart local v7    # "row":Landroid/widget/LinearLayout;
    new-instance v8, Landroid/widget/TextView;

    invoke-direct {v8, v1}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object v10, v8

    .local v10, "$this$buildPage_u24lambda_u2416_u24lambda_u2413":Landroid/widget/TextView;
    const/4 v12, 0x0

    .line 273
    .local v12, "$i$a$-apply-KugouRushFragment$buildPage$4$3":I
    const-string v13, "\u8bfb\u53d6\u6863\u4f4d"

    check-cast v13, Ljava/lang/CharSequence;

    invoke-virtual {v10, v13}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 274
    invoke-virtual/range {p0 .. p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->requireContext()Landroid/content/Context;

    move-result-object v13

    invoke-static {v13, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    sget v15, Lcom/goudong/jd/R$color;->chip_active_text:I

    invoke-static {v13, v15}, Lcom/goudong/jd/ui/common/AppThemeKt;->themeColor(Landroid/content/Context;I)I

    move-result v13

    invoke-virtual {v10, v13}, Landroid/widget/TextView;->setTextColor(I)V

    .line 275
    const/high16 v13, 0x41400000    # 12.0f

    invoke-static {v10, v13}, Lcom/goudong/jd/ui/common/AppTypographyKt;->setTextSp(Landroid/widget/TextView;F)V

    .line 276
    invoke-virtual {v10}, Landroid/widget/TextView;->getTypeface()Landroid/graphics/Typeface;

    move-result-object v13

    const/4 v15, 0x1

    invoke-virtual {v10, v13, v15}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 277
    const/16 v13, 0x11

    invoke-virtual {v10, v13}, Landroid/widget/TextView;->setGravity(I)V

    .line 278
    new-instance v15, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v15}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    move-object/from16 v18, v15

    .local v18, "$this$buildPage_u24lambda_u2416_u24lambda_u2413_u24lambda_u2412":Landroid/graphics/drawable/GradientDrawable;
    const/16 v19, 0x0

    .line 279
    .local v19, "$i$a$-apply-KugouRushFragment$buildPage$4$3$1":I
    invoke-virtual/range {p0 .. p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->requireContext()Landroid/content/Context;

    move-result-object v13

    invoke-static {v13, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    sget v14, Lcom/goudong/jd/R$color;->brand_primary:I

    invoke-static {v13, v14}, Lcom/goudong/jd/ui/common/AppThemeKt;->themeColor(Landroid/content/Context;I)I

    move-result v13

    move-object/from16 v14, v18

    .end local v18    # "$this$buildPage_u24lambda_u2416_u24lambda_u2413_u24lambda_u2412":Landroid/graphics/drawable/GradientDrawable;
    .local v14, "$this$buildPage_u24lambda_u2416_u24lambda_u2413_u24lambda_u2412":Landroid/graphics/drawable/GradientDrawable;
    invoke-virtual {v14, v13}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 280
    move/from16 v18, v6

    const/16 v13, 0x8

    .end local v6    # "$i$a$-apply-KugouRushFragment$buildPage$4":I
    .local v18, "$i$a$-apply-KugouRushFragment$buildPage$4":I
    invoke-static {v1, v13}, Lcom/goudong/jd/ui/common/UiKitKt;->dp(Landroid/content/Context;I)I

    move-result v6

    int-to-float v6, v6

    invoke-virtual {v14, v6}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 281
    nop

    .line 278
    .end local v14    # "$this$buildPage_u24lambda_u2416_u24lambda_u2413_u24lambda_u2412":Landroid/graphics/drawable/GradientDrawable;
    .end local v19    # "$i$a$-apply-KugouRushFragment$buildPage$4$3$1":I
    check-cast v15, Landroid/graphics/drawable/Drawable;

    invoke-virtual {v10, v15}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 282
    const/16 v6, 0xe

    invoke-static {v1, v6}, Lcom/goudong/jd/ui/common/UiKitKt;->dp(Landroid/content/Context;I)I

    move-result v14

    invoke-static {v1, v13}, Lcom/goudong/jd/ui/common/UiKitKt;->dp(Landroid/content/Context;I)I

    move-result v15

    invoke-static {v1, v6}, Lcom/goudong/jd/ui/common/UiKitKt;->dp(Landroid/content/Context;I)I

    move-result v6

    move/from16 v19, v11

    .end local v11    # "inHub":Z
    .local v19, "inHub":Z
    invoke-static {v1, v13}, Lcom/goudong/jd/ui/common/UiKitKt;->dp(Landroid/content/Context;I)I

    move-result v11

    invoke-virtual {v10, v14, v15, v6, v11}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 283
    move-object/from16 v20, v10

    check-cast v20, Landroid/view/View;

    new-instance v6, Lcom/goudong/jd/ui/projects/KugouRushFragment$buildPage$4$3$2;

    invoke-direct {v6, v0}, Lcom/goudong/jd/ui/projects/KugouRushFragment$buildPage$4$3$2;-><init>(Lcom/goudong/jd/ui/projects/KugouRushFragment;)V

    move-object/from16 v23, v6

    check-cast v23, Lkotlin/jvm/functions/Function1;

    const/16 v24, 0x1

    const/16 v25, 0x0

    const-wide/16 v21, 0x0

    invoke-static/range {v20 .. v25}, Lcom/goudong/jd/ui/common/UiKitKt;->setDebouncedClickListener$default(Landroid/view/View;JLkotlin/jvm/functions/Function1;ILjava/lang/Object;)V

    .line 284
    nop

    .line 272
    .end local v10    # "$this$buildPage_u24lambda_u2416_u24lambda_u2413":Landroid/widget/TextView;
    .end local v12    # "$i$a$-apply-KugouRushFragment$buildPage$4$3":I
    iput-object v8, v0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->loadLevelsBtn:Landroid/widget/TextView;

    .line 285
    iget-object v6, v0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->loadLevelsBtn:Landroid/widget/TextView;

    check-cast v6, Landroid/view/View;

    invoke-virtual {v7, v6}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 286
    new-instance v6, Landroid/widget/TextView;

    invoke-direct {v6, v1}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object v8, v6

    .local v8, "$this$buildPage_u24lambda_u2416_u24lambda_u2415":Landroid/widget/TextView;
    const/4 v10, 0x0

    .line 287
    .local v10, "$i$a$-apply-KugouRushFragment$buildPage$4$4":I
    sget v11, Lcom/goudong/jd/R$color;->text_muted:I

    invoke-static {v1, v11}, Lcom/goudong/jd/ui/common/AppThemeKt;->themeColor(Landroid/content/Context;I)I

    move-result v11

    invoke-virtual {v8, v11}, Landroid/widget/TextView;->setTextColor(I)V

    .line 288
    const/high16 v11, 0x41300000    # 11.0f

    invoke-static {v8, v11}, Lcom/goudong/jd/ui/common/AppTypographyKt;->setTextSp(Landroid/widget/TextView;F)V

    .line 289
    new-instance v11, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v12, 0x3f800000    # 1.0f

    const/4 v13, -0x2

    const/4 v14, 0x0

    invoke-direct {v11, v14, v13, v12}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    move-object v12, v11

    .local v12, "$this$buildPage_u24lambda_u2416_u24lambda_u2415_u24lambda_u2414":Landroid/widget/LinearLayout$LayoutParams;
    const/4 v13, 0x0

    .line 290
    .local v13, "$i$a$-apply-KugouRushFragment$buildPage$4$4$1":I
    const/16 v14, 0xa

    invoke-static {v1, v14}, Lcom/goudong/jd/ui/common/UiKitKt;->dp(Landroid/content/Context;I)I

    move-result v15

    invoke-virtual {v12, v15}, Landroid/widget/LinearLayout$LayoutParams;->setMarginStart(I)V

    .line 291
    nop

    .line 289
    .end local v12    # "$this$buildPage_u24lambda_u2416_u24lambda_u2415_u24lambda_u2414":Landroid/widget/LinearLayout$LayoutParams;
    .end local v13    # "$i$a$-apply-KugouRushFragment$buildPage$4$4$1":I
    check-cast v11, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v8, v11}, Landroid/widget/TextView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 292
    nop

    .line 286
    .end local v8    # "$this$buildPage_u24lambda_u2416_u24lambda_u2415":Landroid/widget/TextView;
    .end local v10    # "$i$a$-apply-KugouRushFragment$buildPage$4$4":I
    iput-object v6, v0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->balanceHint:Landroid/widget/TextView;

    .line 293
    iget-object v6, v0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->balanceHint:Landroid/widget/TextView;

    check-cast v6, Landroid/view/View;

    invoke-virtual {v7, v6}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 294
    move-object v6, v7

    check-cast v6, Landroid/view/View;

    invoke-virtual {v5, v6}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 295
    nop

    .line 258
    .end local v5    # "$this$buildPage_u24lambda_u2416":Landroid/widget/LinearLayout;
    .end local v7    # "row":Landroid/widget/LinearLayout;
    .end local v18    # "$i$a$-apply-KugouRushFragment$buildPage$4":I
    check-cast v4, Landroid/view/View;

    invoke-virtual {v3, v4}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 297
    iget-object v3, v0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->contentRoot:Landroid/widget/LinearLayout;

    if-nez v3, :cond_a

    invoke-static {v9}, Lkotlin/jvm/internal/Intrinsics;->throwUninitializedPropertyAccessException(Ljava/lang/String;)V

    const/4 v3, 0x0

    :cond_a
    invoke-static {v1}, Lcom/goudong/jd/ui/common/UiKitKt;->cardView(Landroid/content/Context;)Landroid/widget/LinearLayout;

    move-result-object v4

    move-object v5, v4

    .local v5, "$this$buildPage_u24lambda_u2419":Landroid/widget/LinearLayout;
    const/4 v6, 0x0

    .line 298
    .local v6, "$i$a$-apply-KugouRushFragment$buildPage$5":I
    const/4 v7, 0x1

    const/4 v8, 0x0

    const/4 v10, 0x0

    invoke-static {v1, v10, v7, v8}, Lcom/goudong/jd/ui/common/UiKitKt;->cardInPageLayoutParams$default(Landroid/content/Context;IILjava/lang/Object;)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v11

    check-cast v11, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v5, v11}, Landroid/widget/LinearLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 299
    const-string v7, "\u62a2\u5151\u8bbe\u7f6e"

    invoke-direct {v0, v7}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->label(Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v7

    check-cast v7, Landroid/view/View;

    invoke-virtual {v5, v7}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 300
    const-string v7, "\u5148\u9009\u62e9\u8d26\u53f7\uff0c\u518d\u8bfb\u53d6\u6863\u4f4d\u3002"

    invoke-static {v1, v7}, Lcom/goudong/jd/ui/common/UiKitKt;->captionText(Landroid/content/Context;Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v7

    move-object v8, v7

    .local v8, "$this$buildPage_u24lambda_u2419_u24lambda_u2417":Landroid/widget/TextView;
    const/4 v10, 0x0

    .line 301
    .local v10, "$i$a$-apply-KugouRushFragment$buildPage$5$1":I
    const/4 v11, 0x4

    invoke-static {v1, v11}, Lcom/goudong/jd/ui/common/UiKitKt;->dp(Landroid/content/Context;I)I

    move-result v12

    const/16 v11, 0x8

    invoke-static {v1, v11}, Lcom/goudong/jd/ui/common/UiKitKt;->dp(Landroid/content/Context;I)I

    move-result v13

    const/4 v11, 0x0

    invoke-virtual {v8, v11, v12, v11, v13}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 302
    nop

    .line 300
    .end local v8    # "$this$buildPage_u24lambda_u2419_u24lambda_u2417":Landroid/widget/TextView;
    .end local v10    # "$i$a$-apply-KugouRushFragment$buildPage$5$1":I
    iput-object v7, v0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->levelHintText:Landroid/widget/TextView;

    .line 303
    iget-object v7, v0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->levelHintText:Landroid/widget/TextView;

    check-cast v7, Landroid/view/View;

    invoke-virtual {v5, v7}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 304
    new-instance v7, Landroid/widget/LinearLayout;

    invoke-direct {v7, v1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object v8, v7

    .local v8, "$this$buildPage_u24lambda_u2419_u24lambda_u2418":Landroid/widget/LinearLayout;
    const/4 v10, 0x0

    .line 305
    .local v10, "$i$a$-apply-KugouRushFragment$buildPage$5$2":I
    const/4 v11, 0x1

    invoke-virtual {v8, v11}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 306
    const/4 v12, 0x0

    const/4 v13, 0x0

    invoke-static {v1, v13, v11, v12}, Lcom/goudong/jd/ui/common/UiKitKt;->infoBannerBackground$default(Landroid/content/Context;IILjava/lang/Object;)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v14

    check-cast v14, Landroid/graphics/drawable/Drawable;

    invoke-virtual {v8, v14}, Landroid/widget/LinearLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 307
    const/16 v11, 0xc

    invoke-static {v1, v11}, Lcom/goudong/jd/ui/common/UiKitKt;->dp(Landroid/content/Context;I)I

    move-result v12

    const/16 v13, 0xa

    invoke-static {v1, v13}, Lcom/goudong/jd/ui/common/UiKitKt;->dp(Landroid/content/Context;I)I

    move-result v14

    invoke-static {v1, v11}, Lcom/goudong/jd/ui/common/UiKitKt;->dp(Landroid/content/Context;I)I

    move-result v15

    invoke-static {v1, v13}, Lcom/goudong/jd/ui/common/UiKitKt;->dp(Landroid/content/Context;I)I

    move-result v11

    invoke-virtual {v8, v12, v14, v15, v11}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 308
    new-instance v11, Landroid/widget/LinearLayout$LayoutParams;

    .line 309
    nop

    .line 310
    nop

    .line 308
    const/4 v12, -0x1

    const/4 v13, -0x2

    invoke-direct {v11, v12, v13}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    check-cast v11, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v8, v11}, Landroid/widget/LinearLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 312
    nop

    .line 304
    .end local v8    # "$this$buildPage_u24lambda_u2419_u24lambda_u2418":Landroid/widget/LinearLayout;
    .end local v10    # "$i$a$-apply-KugouRushFragment$buildPage$5$2":I
    iput-object v7, v0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->guideHost:Landroid/widget/LinearLayout;

    .line 313
    iget-object v7, v0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->guideHost:Landroid/widget/LinearLayout;

    check-cast v7, Landroid/view/View;

    invoke-virtual {v5, v7}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 314
    const-string v7, "\u52a0\u8f7d\u8bf4\u660e\u4e2d\u2026"

    invoke-direct {v0, v7}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->bindGuideText(Ljava/lang/String;)V

    .line 315
    nop

    .line 297
    .end local v5    # "$this$buildPage_u24lambda_u2419":Landroid/widget/LinearLayout;
    .end local v6    # "$i$a$-apply-KugouRushFragment$buildPage$5":I
    check-cast v4, Landroid/view/View;

    invoke-virtual {v3, v4}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 317
    invoke-static {v1}, Lcom/goudong/jd/ui/common/UiKitKt;->cardView(Landroid/content/Context;)Landroid/widget/LinearLayout;

    move-result-object v3

    move-object v4, v3

    .local v4, "$this$buildPage_u24lambda_u2421":Landroid/widget/LinearLayout;
    const/4 v5, 0x0

    .line 318
    .local v5, "$i$a$-apply-KugouRushFragment$buildPage$6":I
    const/4 v6, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-static {v1, v8, v6, v7}, Lcom/goudong/jd/ui/common/UiKitKt;->cardInPageLayoutParams$default(Landroid/content/Context;IILjava/lang/Object;)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v10

    check-cast v10, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v4, v10}, Landroid/widget/LinearLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 319
    const-string v6, "\u7f51\u7edc\u8bbe\u7f6e"

    invoke-direct {v0, v6}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->label(Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v6

    check-cast v6, Landroid/view/View;

    invoke-virtual {v4, v6}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 320
    new-instance v6, Landroid/widget/CheckBox;

    invoke-direct {v6, v1}, Landroid/widget/CheckBox;-><init>(Landroid/content/Context;)V

    move-object v7, v6

    .local v7, "$this$buildPage_u24lambda_u2421_u24lambda_u2420":Landroid/widget/CheckBox;
    const/4 v8, 0x0

    .line 321
    .local v8, "$i$a$-apply-KugouRushFragment$buildPage$6$1":I
    const-string v10, "\u542f\u7528\u4ee3\u7406\u62a2\u5151"

    check-cast v10, Ljava/lang/CharSequence;

    invoke-virtual {v7, v10}, Landroid/widget/CheckBox;->setText(Ljava/lang/CharSequence;)V

    .line 322
    invoke-direct/range {p0 .. p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->prefs()Landroid/content/SharedPreferences;

    move-result-object v10

    const-string v11, "use_proxy"

    const/4 v13, 0x0

    invoke-interface {v10, v11, v13}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v10

    invoke-virtual {v7, v10}, Landroid/widget/CheckBox;->setChecked(Z)V

    .line 323
    sget v10, Lcom/goudong/jd/R$color;->text_primary:I

    invoke-static {v1, v10}, Lcom/goudong/jd/ui/common/AppThemeKt;->themeColor(Landroid/content/Context;I)I

    move-result v10

    invoke-virtual {v7, v10}, Landroid/widget/CheckBox;->setTextColor(I)V

    .line 324
    const/16 v10, 0x8

    invoke-static {v1, v10}, Lcom/goudong/jd/ui/common/UiKitKt;->dp(Landroid/content/Context;I)I

    move-result v11

    invoke-virtual {v7, v13, v11, v13, v13}, Landroid/widget/CheckBox;->setPadding(IIII)V

    .line 325
    nop

    .line 320
    .end local v7    # "$this$buildPage_u24lambda_u2421_u24lambda_u2420":Landroid/widget/CheckBox;
    .end local v8    # "$i$a$-apply-KugouRushFragment$buildPage$6$1":I
    iput-object v6, v0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->useProxyCheck:Landroid/widget/CheckBox;

    .line 326
    iget-object v6, v0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->useProxyCheck:Landroid/widget/CheckBox;

    check-cast v6, Landroid/view/View;

    invoke-virtual {v4, v6}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 327
    nop

    .line 317
    .end local v4    # "$this$buildPage_u24lambda_u2421":Landroid/widget/LinearLayout;
    .end local v5    # "$i$a$-apply-KugouRushFragment$buildPage$6":I
    check-cast v3, Landroid/view/View;

    iput-object v3, v0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->proxySettingsCard:Landroid/view/View;

    .line 328
    iget-object v8, v0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->contentRoot:Landroid/widget/LinearLayout;

    if-nez v8, :cond_b

    invoke-static {v9}, Lkotlin/jvm/internal/Intrinsics;->throwUninitializedPropertyAccessException(Ljava/lang/String;)V

    const/4 v8, 0x0

    :cond_b
    iget-object v3, v0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->proxySettingsCard:Landroid/view/View;

    invoke-virtual {v8, v3}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 330
    iget-object v8, v0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->contentRoot:Landroid/widget/LinearLayout;

    if-nez v8, :cond_c

    invoke-static {v9}, Lkotlin/jvm/internal/Intrinsics;->throwUninitializedPropertyAccessException(Ljava/lang/String;)V

    const/4 v8, 0x0

    :cond_c
    invoke-static {v1}, Lcom/goudong/jd/ui/common/UiKitKt;->cardView(Landroid/content/Context;)Landroid/widget/LinearLayout;

    move-result-object v3

    move-object v4, v3

    .local v4, "$this$buildPage_u24lambda_u2433":Landroid/widget/LinearLayout;
    const/4 v5, 0x0

    .line 331
    .local v5, "$i$a$-apply-KugouRushFragment$buildPage$7":I
    const/4 v6, 0x1

    const/4 v7, 0x0

    const/4 v10, 0x0

    invoke-static {v1, v10, v6, v7}, Lcom/goudong/jd/ui/common/UiKitKt;->cardInPageLayoutParams$default(Landroid/content/Context;IILjava/lang/Object;)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v11

    check-cast v11, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v4, v11}, Landroid/widget/LinearLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 332
    new-instance v6, Landroid/widget/TextView;

    invoke-direct {v6, v1}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    iput-object v6, v0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->nowTimeText:Landroid/widget/TextView;

    .line 333
    new-instance v6, Landroid/widget/TextView;

    invoke-direct {v6, v1}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    iput-object v6, v0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->nextTimeText:Landroid/widget/TextView;

    .line 334
    new-instance v6, Landroid/widget/TextView;

    invoke-direct {v6, v1}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object v10, v6

    .local v10, "$this$buildPage_u24lambda_u2433_u24lambda_u2422":Landroid/widget/TextView;
    const/4 v11, 0x0

    .line 335
    .local v11, "$i$a$-apply-KugouRushFragment$buildPage$7$1":I
    sget v13, Lcom/goudong/jd/R$color;->text_secondary:I

    invoke-static {v1, v13}, Lcom/goudong/jd/ui/common/AppThemeKt;->themeColor(Landroid/content/Context;I)I

    move-result v13

    invoke-virtual {v10, v13}, Landroid/widget/TextView;->setTextColor(I)V

    .line 336
    invoke-virtual {v10}, Landroid/widget/TextView;->getTypeface()Landroid/graphics/Typeface;

    move-result-object v13

    const/4 v14, 0x1

    invoke-virtual {v10, v13, v14}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 337
    nop

    .line 334
    .end local v10    # "$this$buildPage_u24lambda_u2433_u24lambda_u2422":Landroid/widget/TextView;
    .end local v11    # "$i$a$-apply-KugouRushFragment$buildPage$7$1":I
    iput-object v6, v0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->timeHintText:Landroid/widget/TextView;

    .line 338
    iget-object v6, v0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->nowTimeText:Landroid/widget/TextView;

    const/high16 v10, 0x41500000    # 13.0f

    if-eqz v6, :cond_d

    .local v6, "$this$buildPage_u24lambda_u2433_u24lambda_u2423":Landroid/widget/TextView;
    const/4 v11, 0x0

    .line 339
    .local v11, "$i$a$-apply-KugouRushFragment$buildPage$7$2":I
    invoke-static {v6, v10}, Lcom/goudong/jd/ui/common/AppTypographyKt;->setTextSp(Landroid/widget/TextView;F)V

    .line 340
    sget v13, Lcom/goudong/jd/R$color;->text_primary:I

    invoke-static {v1, v13}, Lcom/goudong/jd/ui/common/AppThemeKt;->themeColor(Landroid/content/Context;I)I

    move-result v13

    invoke-virtual {v6, v13}, Landroid/widget/TextView;->setTextColor(I)V

    .line 341
    nop

    .line 338
    .end local v6    # "$this$buildPage_u24lambda_u2433_u24lambda_u2423":Landroid/widget/TextView;
    .end local v11    # "$i$a$-apply-KugouRushFragment$buildPage$7$2":I
    nop

    .line 342
    :cond_d
    iget-object v6, v0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->nextTimeText:Landroid/widget/TextView;

    if-eqz v6, :cond_e

    .local v6, "$this$buildPage_u24lambda_u2433_u24lambda_u2424":Landroid/widget/TextView;
    const/4 v11, 0x0

    .line 343
    .local v11, "$i$a$-apply-KugouRushFragment$buildPage$7$3":I
    invoke-static {v6, v10}, Lcom/goudong/jd/ui/common/AppTypographyKt;->setTextSp(Landroid/widget/TextView;F)V

    .line 344
    sget v13, Lcom/goudong/jd/R$color;->text_secondary:I

    invoke-static {v1, v13}, Lcom/goudong/jd/ui/common/AppThemeKt;->themeColor(Landroid/content/Context;I)I

    move-result v13

    invoke-virtual {v6, v13}, Landroid/widget/TextView;->setTextColor(I)V

    .line 345
    nop

    .line 342
    .end local v6    # "$this$buildPage_u24lambda_u2433_u24lambda_u2424":Landroid/widget/TextView;
    .end local v11    # "$i$a$-apply-KugouRushFragment$buildPage$7$3":I
    nop

    .line 346
    :cond_e
    iget-object v6, v0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->timeHintText:Landroid/widget/TextView;

    if-eqz v6, :cond_f

    invoke-static {v6, v10}, Lcom/goudong/jd/ui/common/AppTypographyKt;->setTextSp(Landroid/widget/TextView;F)V

    sget-object v6, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 347
    :cond_f
    iget-object v6, v0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->nowTimeText:Landroid/widget/TextView;

    iget-object v10, v0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->nextTimeText:Landroid/widget/TextView;

    iget-object v11, v0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->timeHintText:Landroid/widget/TextView;

    const/4 v13, 0x3

    new-array v13, v13, [Landroid/widget/TextView;

    const/4 v14, 0x0

    aput-object v6, v13, v14

    const/4 v6, 0x1

    aput-object v10, v13, v6

    const/4 v6, 0x2

    aput-object v11, v13, v6

    invoke-static {v13}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v6

    check-cast v6, Ljava/lang/Iterable;

    .local v6, "$this$forEach$iv":Ljava/lang/Iterable;
    const/4 v10, 0x0

    .line 1304
    .local v10, "$i$f$forEach":I
    invoke-interface {v6}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v11

    :goto_3
    invoke-interface {v11}, Ljava/util/Iterator;->hasNext()Z

    move-result v13

    if-eqz v13, :cond_11

    invoke-interface {v11}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v13

    .local v13, "element$iv":Ljava/lang/Object;
    move-object v14, v13

    check-cast v14, Landroid/widget/TextView;

    .local v14, "tv":Landroid/widget/TextView;
    const/4 v15, 0x0

    .line 347
    .local v15, "$i$a$-forEach-KugouRushFragment$buildPage$7$4":I
    if-eqz v14, :cond_10

    move-object/from16 v17, v14

    .line 1303
    .local v17, "it":Landroid/widget/TextView;
    const/16 v18, 0x0

    .line 347
    .local v18, "$i$a$-let-KugouRushFragment$buildPage$7$4$1":I
    move-object/from16 v7, v17

    check-cast v7, Landroid/view/View;

    invoke-virtual {v4, v7}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .end local v17    # "it":Landroid/widget/TextView;
    .end local v18    # "$i$a$-let-KugouRushFragment$buildPage$7$4$1":I
    sget-object v7, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    sget-object v7, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 1304
    :cond_10
    nop

    .end local v14    # "tv":Landroid/widget/TextView;
    .end local v15    # "$i$a$-forEach-KugouRushFragment$buildPage$7$4":I
    const/4 v7, 0x0

    .end local v13    # "element$iv":Ljava/lang/Object;
    goto :goto_3

    .line 1305
    :cond_11
    nop

    .line 348
    .end local v6    # "$this$forEach$iv":Ljava/lang/Iterable;
    .end local v10    # "$i$f$forEach":I
    new-instance v6, Landroid/widget/LinearLayout;

    invoke-direct {v6, v1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object v7, v6

    .local v7, "$this$buildPage_u24lambda_u2433_u24lambda_u2427":Landroid/widget/LinearLayout;
    const/4 v10, 0x0

    .line 349
    .local v10, "$i$a$-apply-KugouRushFragment$buildPage$7$actionRow$1":I
    const/4 v11, 0x0

    invoke-virtual {v7, v11}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 350
    const/16 v13, 0x10

    invoke-virtual {v7, v13}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 351
    const/16 v13, 0xc

    invoke-static {v1, v13}, Lcom/goudong/jd/ui/common/UiKitKt;->dp(Landroid/content/Context;I)I

    move-result v13

    invoke-virtual {v7, v11, v13, v11, v11}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 352
    nop

    .line 348
    .end local v7    # "$this$buildPage_u24lambda_u2433_u24lambda_u2427":Landroid/widget/LinearLayout;
    .end local v10    # "$i$a$-apply-KugouRushFragment$buildPage$7$actionRow$1":I
    nop

    .line 353
    .local v6, "actionRow":Landroid/widget/LinearLayout;
    new-instance v7, Landroid/widget/TextView;

    invoke-direct {v7, v1}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object v10, v7

    .local v10, "$this$buildPage_u24lambda_u2433_u24lambda_u2429":Landroid/widget/TextView;
    const/4 v11, 0x0

    .line 354
    .local v11, "$i$a$-apply-KugouRushFragment$buildPage$7$5":I
    const-string v13, "\u5f00\u59cb\u62a2\u5151"

    check-cast v13, Ljava/lang/CharSequence;

    invoke-virtual {v10, v13}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 355
    invoke-virtual/range {p0 .. p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->requireContext()Landroid/content/Context;

    move-result-object v13

    invoke-static {v13, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    sget v14, Lcom/goudong/jd/R$color;->chip_active_text:I

    invoke-static {v13, v14}, Lcom/goudong/jd/ui/common/AppThemeKt;->themeColor(Landroid/content/Context;I)I

    move-result v13

    invoke-virtual {v10, v13}, Landroid/widget/TextView;->setTextColor(I)V

    .line 356
    const/high16 v13, 0x41600000    # 14.0f

    invoke-static {v10, v13}, Lcom/goudong/jd/ui/common/AppTypographyKt;->setTextSp(Landroid/widget/TextView;F)V

    .line 357
    invoke-virtual {v10}, Landroid/widget/TextView;->getTypeface()Landroid/graphics/Typeface;

    move-result-object v14

    const/4 v15, 0x1

    invoke-virtual {v10, v14, v15}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 358
    const/16 v14, 0x11

    invoke-virtual {v10, v14}, Landroid/widget/TextView;->setGravity(I)V

    .line 359
    new-instance v14, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v14}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    move-object v15, v14

    .local v15, "$this$buildPage_u24lambda_u2433_u24lambda_u2429_u24lambda_u2428":Landroid/graphics/drawable/GradientDrawable;
    const/16 v16, 0x0

    .line 360
    .local v16, "$i$a$-apply-KugouRushFragment$buildPage$7$5$1":I
    sget v12, Lcom/goudong/jd/R$color;->brand_secondary:I

    invoke-static {v1, v12}, Landroidx/core/content/ContextCompat;->getColor(Landroid/content/Context;I)I

    move-result v12

    invoke-virtual {v15, v12}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 361
    const/16 v12, 0xa

    invoke-static {v1, v12}, Lcom/goudong/jd/ui/common/UiKitKt;->dp(Landroid/content/Context;I)I

    move-result v13

    int-to-float v13, v13

    invoke-virtual {v15, v13}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 362
    nop

    .line 359
    .end local v15    # "$this$buildPage_u24lambda_u2433_u24lambda_u2429_u24lambda_u2428":Landroid/graphics/drawable/GradientDrawable;
    .end local v16    # "$i$a$-apply-KugouRushFragment$buildPage$7$5$1":I
    check-cast v14, Landroid/graphics/drawable/Drawable;

    invoke-virtual {v10, v14}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 363
    const/16 v13, 0x18

    invoke-static {v1, v13}, Lcom/goudong/jd/ui/common/UiKitKt;->dp(Landroid/content/Context;I)I

    move-result v14

    invoke-static {v1, v12}, Lcom/goudong/jd/ui/common/UiKitKt;->dp(Landroid/content/Context;I)I

    move-result v15

    invoke-static {v1, v13}, Lcom/goudong/jd/ui/common/UiKitKt;->dp(Landroid/content/Context;I)I

    move-result v13

    move/from16 v16, v5

    .end local v5    # "$i$a$-apply-KugouRushFragment$buildPage$7":I
    .local v16, "$i$a$-apply-KugouRushFragment$buildPage$7":I
    invoke-static {v1, v12}, Lcom/goudong/jd/ui/common/UiKitKt;->dp(Landroid/content/Context;I)I

    move-result v5

    invoke-virtual {v10, v14, v15, v13, v5}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 364
    move-object/from16 v21, v10

    check-cast v21, Landroid/view/View;

    new-instance v5, Lcom/goudong/jd/ui/projects/KugouRushFragment$buildPage$7$5$2;

    invoke-direct {v5, v0}, Lcom/goudong/jd/ui/projects/KugouRushFragment$buildPage$7$5$2;-><init>(Lcom/goudong/jd/ui/projects/KugouRushFragment;)V

    move-object/from16 v24, v5

    check-cast v24, Lkotlin/jvm/functions/Function1;

    const/16 v25, 0x1

    const/16 v26, 0x0

    const-wide/16 v22, 0x0

    invoke-static/range {v21 .. v26}, Lcom/goudong/jd/ui/common/UiKitKt;->setDebouncedClickListener$default(Landroid/view/View;JLkotlin/jvm/functions/Function1;ILjava/lang/Object;)V

    .line 365
    nop

    .line 353
    .end local v10    # "$this$buildPage_u24lambda_u2433_u24lambda_u2429":Landroid/widget/TextView;
    .end local v11    # "$i$a$-apply-KugouRushFragment$buildPage$7$5":I
    iput-object v7, v0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->withdrawBtn:Landroid/widget/TextView;

    .line 366
    iget-object v5, v0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->withdrawBtn:Landroid/widget/TextView;

    check-cast v5, Landroid/view/View;

    invoke-virtual {v6, v5}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 367
    new-instance v5, Landroid/widget/TextView;

    invoke-direct {v5, v1}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object v7, v5

    .local v7, "$this$buildPage_u24lambda_u2433_u24lambda_u2432":Landroid/widget/TextView;
    const/4 v10, 0x0

    .line 368
    .local v10, "$i$a$-apply-KugouRushFragment$buildPage$7$6":I
    const/16 v11, 0x8

    invoke-virtual {v7, v11}, Landroid/widget/TextView;->setVisibility(I)V

    .line 369
    invoke-virtual/range {p0 .. p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->requireContext()Landroid/content/Context;

    move-result-object v11

    invoke-static {v11, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    sget v12, Lcom/goudong/jd/R$color;->chip_active_text:I

    invoke-static {v11, v12}, Lcom/goudong/jd/ui/common/AppThemeKt;->themeColor(Landroid/content/Context;I)I

    move-result v11

    invoke-virtual {v7, v11}, Landroid/widget/TextView;->setTextColor(I)V

    .line 370
    const/high16 v11, 0x41600000    # 14.0f

    invoke-static {v7, v11}, Lcom/goudong/jd/ui/common/AppTypographyKt;->setTextSp(Landroid/widget/TextView;F)V

    .line 371
    invoke-virtual {v7}, Landroid/widget/TextView;->getTypeface()Landroid/graphics/Typeface;

    move-result-object v11

    const/4 v12, 0x1

    invoke-virtual {v7, v11, v12}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 372
    const/16 v11, 0x11

    invoke-virtual {v7, v11}, Landroid/widget/TextView;->setGravity(I)V

    .line 373
    new-instance v11, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v11}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    move-object v12, v11

    .local v12, "$this$buildPage_u24lambda_u2433_u24lambda_u2432_u24lambda_u2430":Landroid/graphics/drawable/GradientDrawable;
    const/4 v13, 0x0

    .line 374
    .local v13, "$i$a$-apply-KugouRushFragment$buildPage$7$6$1":I
    invoke-virtual/range {p0 .. p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->requireContext()Landroid/content/Context;

    move-result-object v14

    invoke-static {v14, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    sget v15, Lcom/goudong/jd/R$color;->brand_orange:I

    invoke-static {v14, v15}, Lcom/goudong/jd/ui/common/AppThemeKt;->themeColor(Landroid/content/Context;I)I

    move-result v14

    invoke-virtual/range {p0 .. p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->requireContext()Landroid/content/Context;

    move-result-object v15

    invoke-static {v15, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    sget v2, Lcom/goudong/jd/R$color;->brand_red:I

    invoke-static {v15, v2}, Lcom/goudong/jd/ui/common/AppThemeKt;->themeColor(Landroid/content/Context;I)I

    move-result v2

    filled-new-array {v14, v2}, [I

    move-result-object v2

    invoke-virtual {v12, v2}, Landroid/graphics/drawable/GradientDrawable;->setColors([I)V

    .line 375
    sget-object v2, Landroid/graphics/drawable/GradientDrawable$Orientation;->LEFT_RIGHT:Landroid/graphics/drawable/GradientDrawable$Orientation;

    invoke-virtual {v12, v2}, Landroid/graphics/drawable/GradientDrawable;->setOrientation(Landroid/graphics/drawable/GradientDrawable$Orientation;)V

    .line 376
    const/16 v2, 0xa

    invoke-static {v1, v2}, Lcom/goudong/jd/ui/common/UiKitKt;->dp(Landroid/content/Context;I)I

    move-result v14

    int-to-float v14, v14

    invoke-virtual {v12, v14}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 377
    nop

    .line 373
    .end local v12    # "$this$buildPage_u24lambda_u2433_u24lambda_u2432_u24lambda_u2430":Landroid/graphics/drawable/GradientDrawable;
    .end local v13    # "$i$a$-apply-KugouRushFragment$buildPage$7$6$1":I
    check-cast v11, Landroid/graphics/drawable/Drawable;

    invoke-virtual {v7, v11}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 378
    const/16 v11, 0x10

    invoke-static {v1, v11}, Lcom/goudong/jd/ui/common/UiKitKt;->dp(Landroid/content/Context;I)I

    move-result v12

    invoke-static {v1, v2}, Lcom/goudong/jd/ui/common/UiKitKt;->dp(Landroid/content/Context;I)I

    move-result v13

    invoke-static {v1, v11}, Lcom/goudong/jd/ui/common/UiKitKt;->dp(Landroid/content/Context;I)I

    move-result v14

    invoke-static {v1, v2}, Lcom/goudong/jd/ui/common/UiKitKt;->dp(Landroid/content/Context;I)I

    move-result v11

    invoke-virtual {v7, v12, v13, v14, v11}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 379
    new-instance v11, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v12, -0x2

    invoke-direct {v11, v12, v12}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    move-object v12, v11

    .local v12, "$this$buildPage_u24lambda_u2433_u24lambda_u2432_u24lambda_u2431":Landroid/widget/LinearLayout$LayoutParams;
    const/4 v13, 0x0

    .line 380
    .local v13, "$i$a$-apply-KugouRushFragment$buildPage$7$6$2":I
    invoke-static {v1, v2}, Lcom/goudong/jd/ui/common/UiKitKt;->dp(Landroid/content/Context;I)I

    move-result v14

    invoke-virtual {v12, v14}, Landroid/widget/LinearLayout$LayoutParams;->setMarginStart(I)V

    .line 381
    nop

    .line 379
    .end local v12    # "$this$buildPage_u24lambda_u2433_u24lambda_u2432_u24lambda_u2431":Landroid/widget/LinearLayout$LayoutParams;
    .end local v13    # "$i$a$-apply-KugouRushFragment$buildPage$7$6$2":I
    check-cast v11, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v7, v11}, Landroid/widget/TextView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 382
    nop

    .line 367
    .end local v7    # "$this$buildPage_u24lambda_u2433_u24lambda_u2432":Landroid/widget/TextView;
    .end local v10    # "$i$a$-apply-KugouRushFragment$buildPage$7$6":I
    iput-object v5, v0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->countdownText:Landroid/widget/TextView;

    .line 383
    iget-object v2, v0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->countdownText:Landroid/widget/TextView;

    check-cast v2, Landroid/view/View;

    invoke-virtual {v6, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 384
    move-object v2, v6

    check-cast v2, Landroid/view/View;

    invoke-virtual {v4, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 385
    nop

    .line 330
    .end local v4    # "$this$buildPage_u24lambda_u2433":Landroid/widget/LinearLayout;
    .end local v6    # "actionRow":Landroid/widget/LinearLayout;
    .end local v16    # "$i$a$-apply-KugouRushFragment$buildPage$7":I
    check-cast v3, Landroid/view/View;

    invoke-virtual {v8, v3}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 387
    iget-object v2, v0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->contentRoot:Landroid/widget/LinearLayout;

    if-nez v2, :cond_12

    invoke-static {v9}, Lkotlin/jvm/internal/Intrinsics;->throwUninitializedPropertyAccessException(Ljava/lang/String;)V

    const/4 v10, 0x0

    goto :goto_4

    :cond_12
    move-object v10, v2

    :goto_4
    invoke-static {v1}, Lcom/goudong/jd/ui/common/UiKitKt;->cardView(Landroid/content/Context;)Landroid/widget/LinearLayout;

    move-result-object v2

    move-object v3, v2

    .local v3, "$this$buildPage_u24lambda_u2443":Landroid/widget/LinearLayout;
    const/4 v4, 0x0

    .line 388
    .local v4, "$i$a$-apply-KugouRushFragment$buildPage$8":I
    const/16 v5, 0x14

    invoke-static {v1, v5}, Lcom/goudong/jd/ui/common/UiKitKt;->dp(Landroid/content/Context;I)I

    move-result v5

    invoke-static {v1, v5}, Lcom/goudong/jd/ui/common/UiKitKt;->cardInPageLayoutParams(Landroid/content/Context;I)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v5

    check-cast v5, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v3, v5}, Landroid/widget/LinearLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 389
    new-instance v5, Landroid/widget/LinearLayout;

    invoke-direct {v5, v1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object v6, v5

    .local v6, "$this$buildPage_u24lambda_u2443_u24lambda_u2434":Landroid/widget/LinearLayout;
    const/4 v7, 0x0

    .line 390
    .local v7, "$i$a$-apply-KugouRushFragment$buildPage$8$hdr$1":I
    const/4 v8, 0x0

    invoke-virtual {v6, v8}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 391
    const/16 v8, 0x10

    invoke-virtual {v6, v8}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 392
    nop

    .line 389
    .end local v6    # "$this$buildPage_u24lambda_u2443_u24lambda_u2434":Landroid/widget/LinearLayout;
    .end local v7    # "$i$a$-apply-KugouRushFragment$buildPage$8$hdr$1":I
    nop

    .line 393
    .local v5, "hdr":Landroid/widget/LinearLayout;
    const-string v6, "\u6267\u884c\u65e5\u5fd7"

    invoke-direct {v0, v6}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->label(Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v6

    move-object v7, v6

    .local v7, "$this$buildPage_u24lambda_u2443_u24lambda_u2435":Landroid/widget/TextView;
    const/4 v8, 0x0

    .line 394
    .local v8, "$i$a$-apply-KugouRushFragment$buildPage$8$1":I
    new-instance v9, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v11, 0x3f800000    # 1.0f

    const/4 v12, -0x2

    const/4 v13, 0x0

    invoke-direct {v9, v13, v12, v11}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    check-cast v9, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v7, v9}, Landroid/widget/TextView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 395
    nop

    .line 393
    .end local v7    # "$this$buildPage_u24lambda_u2443_u24lambda_u2435":Landroid/widget/TextView;
    .end local v8    # "$i$a$-apply-KugouRushFragment$buildPage$8$1":I
    check-cast v6, Landroid/view/View;

    invoke-virtual {v5, v6}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 396
    new-instance v6, Landroid/widget/TextView;

    invoke-direct {v6, v1}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object v7, v6

    .local v7, "$this$buildPage_u24lambda_u2443_u24lambda_u2436":Landroid/widget/TextView;
    const/4 v8, 0x0

    .line 397
    .local v8, "$i$a$-apply-KugouRushFragment$buildPage$8$2":I
    const-string v9, "\u6e05\u7a7a"

    check-cast v9, Ljava/lang/CharSequence;

    invoke-virtual {v7, v9}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 398
    sget v9, Lcom/goudong/jd/R$color;->text_muted:I

    invoke-static {v1, v9}, Lcom/goudong/jd/ui/common/AppThemeKt;->themeColor(Landroid/content/Context;I)I

    move-result v9

    invoke-virtual {v7, v9}, Landroid/widget/TextView;->setTextColor(I)V

    .line 399
    const/high16 v9, 0x41400000    # 12.0f

    invoke-static {v7, v9}, Lcom/goudong/jd/ui/common/AppTypographyKt;->setTextSp(Landroid/widget/TextView;F)V

    .line 400
    const/16 v9, 0x8

    invoke-static {v1, v9}, Lcom/goudong/jd/ui/common/UiKitKt;->dp(Landroid/content/Context;I)I

    move-result v11

    const/4 v12, 0x4

    invoke-static {v1, v12}, Lcom/goudong/jd/ui/common/UiKitKt;->dp(Landroid/content/Context;I)I

    move-result v13

    invoke-static {v1, v9}, Lcom/goudong/jd/ui/common/UiKitKt;->dp(Landroid/content/Context;I)I

    move-result v14

    invoke-static {v1, v12}, Lcom/goudong/jd/ui/common/UiKitKt;->dp(Landroid/content/Context;I)I

    move-result v9

    invoke-virtual {v7, v11, v13, v14, v9}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 401
    move-object/from16 v20, v7

    check-cast v20, Landroid/view/View;

    new-instance v9, Lcom/goudong/jd/ui/projects/KugouRushFragment$buildPage$8$2$1;

    invoke-direct {v9, v0}, Lcom/goudong/jd/ui/projects/KugouRushFragment$buildPage$8$2$1;-><init>(Lcom/goudong/jd/ui/projects/KugouRushFragment;)V

    move-object/from16 v23, v9

    check-cast v23, Lkotlin/jvm/functions/Function1;

    const/16 v24, 0x1

    const/16 v25, 0x0

    const-wide/16 v21, 0x0

    invoke-static/range {v20 .. v25}, Lcom/goudong/jd/ui/common/UiKitKt;->setDebouncedClickListener$default(Landroid/view/View;JLkotlin/jvm/functions/Function1;ILjava/lang/Object;)V

    .line 402
    nop

    .line 396
    .end local v7    # "$this$buildPage_u24lambda_u2443_u24lambda_u2436":Landroid/widget/TextView;
    .end local v8    # "$i$a$-apply-KugouRushFragment$buildPage$8$2":I
    check-cast v6, Landroid/view/View;

    invoke-virtual {v5, v6}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 403
    move-object v6, v5

    check-cast v6, Landroid/view/View;

    invoke-virtual {v3, v6}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 404
    const-string v6, "\u5012\u8ba1\u65f6\u62a2\u5151\u4f1a\u5b9e\u65f6\u540c\u6b65\u540e\u7aef\u6bcf\u4e00\u6b65"

    invoke-direct {v0, v6}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->captionText(Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v6

    move-object v7, v6

    .local v7, "$this$buildPage_u24lambda_u2443_u24lambda_u2437":Landroid/widget/TextView;
    const/4 v8, 0x0

    .line 405
    .local v8, "$i$a$-apply-KugouRushFragment$buildPage$8$3":I
    const/4 v9, 0x2

    invoke-static {v1, v9}, Lcom/goudong/jd/ui/common/UiKitKt;->dp(Landroid/content/Context;I)I

    move-result v9

    const/16 v11, 0x8

    invoke-static {v1, v11}, Lcom/goudong/jd/ui/common/UiKitKt;->dp(Landroid/content/Context;I)I

    move-result v12

    const/4 v11, 0x0

    invoke-virtual {v7, v11, v9, v11, v12}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 406
    nop

    .line 404
    .end local v7    # "$this$buildPage_u24lambda_u2443_u24lambda_u2437":Landroid/widget/TextView;
    .end local v8    # "$i$a$-apply-KugouRushFragment$buildPage$8$3":I
    check-cast v6, Landroid/view/View;

    invoke-virtual {v3, v6}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 407
    new-instance v6, Landroid/widget/LinearLayout;

    invoke-direct {v6, v1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object v7, v6

    .local v7, "$this$buildPage_u24lambda_u2443_u24lambda_u2440":Landroid/widget/LinearLayout;
    const/4 v8, 0x0

    .line 408
    .local v8, "$i$a$-apply-KugouRushFragment$buildPage$8$sessionBar$1":I
    const/4 v9, 0x0

    invoke-virtual {v7, v9}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 409
    const/16 v9, 0x10

    invoke-virtual {v7, v9}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 410
    const/16 v9, 0xa

    invoke-static {v1, v9}, Lcom/goudong/jd/ui/common/UiKitKt;->dp(Landroid/content/Context;I)I

    move-result v11

    const/16 v12, 0x8

    invoke-static {v1, v12}, Lcom/goudong/jd/ui/common/UiKitKt;->dp(Landroid/content/Context;I)I

    move-result v13

    invoke-static {v1, v9}, Lcom/goudong/jd/ui/common/UiKitKt;->dp(Landroid/content/Context;I)I

    move-result v14

    invoke-static {v1, v12}, Lcom/goudong/jd/ui/common/UiKitKt;->dp(Landroid/content/Context;I)I

    move-result v9

    invoke-virtual {v7, v11, v13, v14, v9}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 411
    new-instance v9, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v9}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    move-object v11, v9

    .local v11, "$this$buildPage_u24lambda_u2443_u24lambda_u2440_u24lambda_u2438":Landroid/graphics/drawable/GradientDrawable;
    const/4 v12, 0x0

    .line 412
    .local v12, "$i$a$-apply-KugouRushFragment$buildPage$8$sessionBar$1$1":I
    sget v13, Lcom/goudong/jd/R$color;->surface_elevated:I

    invoke-static {v1, v13}, Lcom/goudong/jd/ui/common/AppThemeKt;->themeColor(Landroid/content/Context;I)I

    move-result v13

    invoke-virtual {v11, v13}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 413
    const/16 v13, 0xa

    invoke-static {v1, v13}, Lcom/goudong/jd/ui/common/UiKitKt;->dp(Landroid/content/Context;I)I

    move-result v14

    int-to-float v13, v14

    invoke-virtual {v11, v13}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 414
    const/4 v13, 0x1

    invoke-static {v1, v13}, Lcom/goudong/jd/ui/common/UiKitKt;->dp(Landroid/content/Context;I)I

    move-result v14

    sget v13, Lcom/goudong/jd/R$color;->border_light:I

    invoke-static {v1, v13}, Lcom/goudong/jd/ui/common/AppThemeKt;->themeColor(Landroid/content/Context;I)I

    move-result v13

    invoke-virtual {v11, v14, v13}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    .line 415
    nop

    .line 411
    .end local v11    # "$this$buildPage_u24lambda_u2443_u24lambda_u2440_u24lambda_u2438":Landroid/graphics/drawable/GradientDrawable;
    .end local v12    # "$i$a$-apply-KugouRushFragment$buildPage$8$sessionBar$1$1":I
    check-cast v9, Landroid/graphics/drawable/Drawable;

    invoke-virtual {v7, v9}, Landroid/widget/LinearLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 416
    new-instance v9, Landroid/widget/LinearLayout$LayoutParams;

    .line 417
    nop

    .line 418
    nop

    .line 416
    const/4 v11, -0x1

    const/4 v12, -0x2

    invoke-direct {v9, v11, v12}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 419
    nop

    .line 1303
    move-object v11, v9

    .local v11, "$this$buildPage_u24lambda_u2443_u24lambda_u2440_u24lambda_u2439":Landroid/widget/LinearLayout$LayoutParams;
    const/4 v12, 0x0

    .line 419
    .local v12, "$i$a$-apply-KugouRushFragment$buildPage$8$sessionBar$1$2":I
    const/16 v13, 0xa

    invoke-static {v1, v13}, Lcom/goudong/jd/ui/common/UiKitKt;->dp(Landroid/content/Context;I)I

    move-result v14

    iput v14, v11, Landroid/widget/LinearLayout$LayoutParams;->bottomMargin:I

    .end local v11    # "$this$buildPage_u24lambda_u2443_u24lambda_u2440_u24lambda_u2439":Landroid/widget/LinearLayout$LayoutParams;
    .end local v12    # "$i$a$-apply-KugouRushFragment$buildPage$8$sessionBar$1$2":I
    check-cast v9, Landroid/view/ViewGroup$LayoutParams;

    .line 416
    invoke-virtual {v7, v9}, Landroid/widget/LinearLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 420
    nop

    .line 407
    .end local v7    # "$this$buildPage_u24lambda_u2443_u24lambda_u2440":Landroid/widget/LinearLayout;
    .end local v8    # "$i$a$-apply-KugouRushFragment$buildPage$8$sessionBar$1":I
    nop

    .line 421
    .local v6, "sessionBar":Landroid/widget/LinearLayout;
    new-instance v7, Landroid/widget/TextView;

    invoke-direct {v7, v1}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object v8, v7

    .local v8, "$this$buildPage_u24lambda_u2443_u24lambda_u2441":Landroid/widget/TextView;
    const/4 v9, 0x0

    .line 422
    .local v9, "$i$a$-apply-KugouRushFragment$buildPage$8$4":I
    const-string v11, "\u5386\u53f2\u573a\u6b21"

    check-cast v11, Ljava/lang/CharSequence;

    invoke-virtual {v8, v11}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 423
    sget v11, Lcom/goudong/jd/R$color;->text_muted:I

    invoke-static {v1, v11}, Lcom/goudong/jd/ui/common/AppThemeKt;->themeColor(Landroid/content/Context;I)I

    move-result v11

    invoke-virtual {v8, v11}, Landroid/widget/TextView;->setTextColor(I)V

    .line 424
    const/high16 v11, 0x41400000    # 12.0f

    invoke-static {v8, v11}, Lcom/goudong/jd/ui/common/AppTypographyKt;->setTextSp(Landroid/widget/TextView;F)V

    .line 425
    invoke-virtual {v8}, Landroid/widget/TextView;->getTypeface()Landroid/graphics/Typeface;

    move-result-object v11

    const/4 v12, 0x1

    invoke-virtual {v8, v11, v12}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 426
    const/16 v11, 0xa

    invoke-static {v1, v11}, Lcom/goudong/jd/ui/common/UiKitKt;->dp(Landroid/content/Context;I)I

    move-result v11

    const/4 v12, 0x0

    invoke-virtual {v8, v12, v12, v11, v12}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 427
    nop

    .line 421
    .end local v8    # "$this$buildPage_u24lambda_u2443_u24lambda_u2441":Landroid/widget/TextView;
    .end local v9    # "$i$a$-apply-KugouRushFragment$buildPage$8$4":I
    check-cast v7, Landroid/view/View;

    invoke-virtual {v6, v7}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 428
    new-instance v7, Landroid/widget/Spinner;

    invoke-direct {v7, v1}, Landroid/widget/Spinner;-><init>(Landroid/content/Context;)V

    move-object v8, v7

    .local v8, "$this$buildPage_u24lambda_u2443_u24lambda_u2442":Landroid/widget/Spinner;
    const/4 v9, 0x0

    .line 429
    .local v9, "$i$a$-apply-KugouRushFragment$buildPage$8$5":I
    new-instance v11, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v12, 0x3f800000    # 1.0f

    const/4 v13, -0x2

    const/4 v14, 0x0

    invoke-direct {v11, v14, v13, v12}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    check-cast v11, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v8, v11}, Landroid/widget/Spinner;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 430
    new-instance v11, Lcom/goudong/jd/ui/projects/KugouRushFragment$buildPage$8$5$1;

    invoke-direct {v11, v0}, Lcom/goudong/jd/ui/projects/KugouRushFragment$buildPage$8$5$1;-><init>(Lcom/goudong/jd/ui/projects/KugouRushFragment;)V

    check-cast v11, Landroid/widget/AdapterView$OnItemSelectedListener;

    invoke-virtual {v8, v11}, Landroid/widget/Spinner;->setOnItemSelectedListener(Landroid/widget/AdapterView$OnItemSelectedListener;)V

    .line 438
    nop

    .line 428
    .end local v8    # "$this$buildPage_u24lambda_u2443_u24lambda_u2442":Landroid/widget/Spinner;
    .end local v9    # "$i$a$-apply-KugouRushFragment$buildPage$8$5":I
    iput-object v7, v0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->sessionSpinner:Landroid/widget/Spinner;

    .line 439
    iget-object v7, v0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->sessionSpinner:Landroid/widget/Spinner;

    check-cast v7, Landroid/view/View;

    invoke-virtual {v6, v7}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 440
    move-object v7, v6

    check-cast v7, Landroid/view/View;

    invoke-virtual {v3, v7}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 441
    new-instance v7, Lcom/goudong/jd/ui/projects/KugouRushFragment$buildPage$8$logViews$1;

    invoke-direct {v7, v1}, Lcom/goudong/jd/ui/projects/KugouRushFragment$buildPage$8$logViews$1;-><init>(Landroid/content/Context;)V

    check-cast v7, Lkotlin/jvm/functions/Function1;

    const/16 v8, 0x168

    invoke-static {v1, v8, v7}, Lcom/goudong/jd/ui/common/UiKitKt;->makeTaskLogScrollView(Landroid/content/Context;ILkotlin/jvm/functions/Function1;)Lkotlin/Pair;

    move-result-object v7

    .line 449
    .local v7, "logViews":Lkotlin/Pair;
    invoke-virtual {v7}, Lkotlin/Pair;->getFirst()Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Lcom/goudong/jd/ui/common/TaskLogScrollView;

    iput-object v8, v0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->logScroll:Lcom/goudong/jd/ui/common/TaskLogScrollView;

    .line 450
    invoke-virtual {v7}, Lkotlin/Pair;->getSecond()Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Landroid/widget/TextView;

    iput-object v8, v0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->logText:Landroid/widget/TextView;

    .line 451
    iget-object v8, v0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->logScroll:Lcom/goudong/jd/ui/common/TaskLogScrollView;

    check-cast v8, Landroid/view/View;

    invoke-virtual {v3, v8}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 452
    nop

    .line 387
    .end local v3    # "$this$buildPage_u24lambda_u2443":Landroid/widget/LinearLayout;
    .end local v4    # "$i$a$-apply-KugouRushFragment$buildPage$8":I
    .end local v5    # "hdr":Landroid/widget/LinearLayout;
    .end local v6    # "sessionBar":Landroid/widget/LinearLayout;
    .end local v7    # "logViews":Lkotlin/Pair;
    check-cast v2, Landroid/view/View;

    invoke-virtual {v10, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 453
    invoke-direct/range {p0 .. p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->restoreLogs()V

    .line 454
    return-void
.end method

.method private final canChooseRushMode()Z
    .locals 4

    .line 545
    iget-object v0, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->portalConfig:Lcom/goudong/jd/data/model/KugouPortalConfig;

    const/4 v1, 0x0

    if-eqz v0, :cond_1

    iget-object v0, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->portalConfig:Lcom/goudong/jd/data/model/KugouPortalConfig;

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Lcom/goudong/jd/data/model/KugouPortalConfig;->getRushModeChoiceAllowed()Ljava/lang/Boolean;

    move-result-object v0

    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v3

    invoke-static {v0, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    goto :goto_0

    :cond_0
    move v0, v1

    :goto_0
    if-eqz v0, :cond_1

    move v1, v2

    :cond_1
    return v1
.end method

.method private final captionText(Ljava/lang/String;)Landroid/widget/TextView;
    .locals 2
    .param p1, "text"    # Ljava/lang/String;

    .line 1300
    invoke-virtual {p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->requireContext()Landroid/content/Context;

    move-result-object v0

    const-string v1, "requireContext(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v0, p1}, Lcom/goudong/jd/ui/common/UiKitKt;->captionText(Landroid/content/Context;Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v0

    return-object v0
.end method

.method private final clearLogs()V
    .locals 2

    .line 1158
    iget-object v0, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->logText:Landroid/widget/TextView;

    if-nez v0, :cond_0

    goto :goto_0

    :cond_0
    const-string v1, ""

    check-cast v1, Ljava/lang/CharSequence;

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1159
    :goto_0
    const/4 v0, 0x0

    iput v0, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->taskLogIndex:I

    .line 1160
    invoke-direct {p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->prefs()Landroid/content/SharedPreferences;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const-string v1, "log"

    invoke-interface {v0, v1}, Landroid/content/SharedPreferences$Editor;->remove(Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 1161
    return-void
.end method

.method private final clearState()V
    .locals 2

    .line 1235
    invoke-direct {p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->prefs()Landroid/content/SharedPreferences;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const-string v1, "state"

    invoke-interface {v0, v1}, Landroid/content/SharedPreferences$Editor;->remove(Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    return-void
.end method

.method private final coinsFor(Ljava/lang/String;)Ljava/util/List;
    .locals 12
    .param p1, "uid"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")",
            "Ljava/util/List<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation

    .line 851
    iget-object v0, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->tierByUser:Ljava/util/LinkedHashMap;

    invoke-virtual {v0, p1}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/goudong/jd/ui/projects/KugouRushFragment$AccountTierState;

    if-nez v0, :cond_0

    invoke-static {}, Lkotlin/collections/CollectionsKt;->emptyList()Ljava/util/List;

    move-result-object v0

    return-object v0

    .line 852
    .local v0, "state":Lcom/goudong/jd/ui/projects/KugouRushFragment$AccountTierState;
    :cond_0
    invoke-virtual {v0}, Lcom/goudong/jd/ui/projects/KugouRushFragment$AccountTierState;->getLevels()Ljava/util/List;

    move-result-object v1

    check-cast v1, Ljava/lang/Iterable;

    .local v1, "$this$filter$iv":Ljava/lang/Iterable;
    const/4 v2, 0x0

    .line 1355
    .local v2, "$i$f$filter":I
    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    check-cast v3, Ljava/util/Collection;

    .local v3, "destination$iv$iv":Ljava/util/Collection;
    move-object v4, v1

    .local v4, "$this$filterTo$iv$iv":Ljava/lang/Iterable;
    const/4 v5, 0x0

    .line 1356
    .local v5, "$i$f$filterTo":I
    invoke-interface {v4}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v6

    :cond_1
    :goto_0
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    if-eqz v7, :cond_2

    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v7

    .local v7, "element$iv$iv":Ljava/lang/Object;
    move-object v8, v7

    check-cast v8, Lcom/goudong/jd/data/model/KugouLevel;

    .local v8, "it":Lcom/goudong/jd/data/model/KugouLevel;
    const/4 v9, 0x0

    .line 852
    .local v9, "$i$a$-filter-KugouRushFragment$coinsFor$affordable$1":I
    invoke-virtual {v8}, Lcom/goudong/jd/data/model/KugouLevel;->getAffordable()Z

    move-result v8

    .line 1356
    .end local v8    # "it":Lcom/goudong/jd/data/model/KugouLevel;
    .end local v9    # "$i$a$-filter-KugouRushFragment$coinsFor$affordable$1":I
    if-eqz v8, :cond_1

    invoke-interface {v3, v7}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_0

    .line 1357
    .end local v7    # "element$iv$iv":Ljava/lang/Object;
    :cond_2
    nop

    .end local v3    # "destination$iv$iv":Ljava/util/Collection;
    .end local v4    # "$this$filterTo$iv$iv":Ljava/lang/Iterable;
    .end local v5    # "$i$f$filterTo":I
    check-cast v3, Ljava/util/List;

    .line 1355
    nop

    .end local v1    # "$this$filter$iv":Ljava/lang/Iterable;
    .end local v2    # "$i$f$filter":I
    check-cast v3, Ljava/lang/Iterable;

    .line 852
    move-object v1, v3

    .local v1, "$this$map$iv":Ljava/lang/Iterable;
    const/4 v2, 0x0

    .line 1358
    .local v2, "$i$f$map":I
    new-instance v3, Ljava/util/ArrayList;

    const/16 v4, 0xa

    invoke-static {v1, v4}, Lkotlin/collections/CollectionsKt;->collectionSizeOrDefault(Ljava/lang/Iterable;I)I

    move-result v4

    invoke-direct {v3, v4}, Ljava/util/ArrayList;-><init>(I)V

    check-cast v3, Ljava/util/Collection;

    .restart local v3    # "destination$iv$iv":Ljava/util/Collection;
    move-object v4, v1

    .local v4, "$this$mapTo$iv$iv":Ljava/lang/Iterable;
    const/4 v5, 0x0

    .line 1359
    .local v5, "$i$f$mapTo":I
    invoke-interface {v4}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v6

    :goto_1
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    if-eqz v7, :cond_3

    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v7

    .line 1360
    .local v7, "item$iv$iv":Ljava/lang/Object;
    move-object v8, v7

    check-cast v8, Lcom/goudong/jd/data/model/KugouLevel;

    .restart local v8    # "it":Lcom/goudong/jd/data/model/KugouLevel;
    const/4 v9, 0x0

    .line 852
    .local v9, "$i$a$-map-KugouRushFragment$coinsFor$affordable$2":I
    invoke-virtual {v8}, Lcom/goudong/jd/data/model/KugouLevel;->getCoins()I

    move-result v8

    .end local v8    # "it":Lcom/goudong/jd/data/model/KugouLevel;
    .end local v9    # "$i$a$-map-KugouRushFragment$coinsFor$affordable$2":I
    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    .line 1360
    invoke-interface {v3, v8}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_1

    .line 1361
    .end local v7    # "item$iv$iv":Ljava/lang/Object;
    :cond_3
    nop

    .end local v3    # "destination$iv$iv":Ljava/util/Collection;
    .end local v4    # "$this$mapTo$iv$iv":Ljava/lang/Iterable;
    .end local v5    # "$i$f$mapTo":I
    check-cast v3, Ljava/util/List;

    .line 1358
    nop

    .end local v1    # "$this$map$iv":Ljava/lang/Iterable;
    .end local v2    # "$i$f$map":I
    check-cast v3, Ljava/lang/Iterable;

    .line 852
    invoke-static {v3}, Lkotlin/collections/CollectionsKt;->toSet(Ljava/lang/Iterable;)Ljava/util/Set;

    move-result-object v1

    .line 853
    .local v1, "affordable":Ljava/util/Set;
    invoke-virtual {v0}, Lcom/goudong/jd/ui/projects/KugouRushFragment$AccountTierState;->getSelectedCoins()Ljava/util/Set;

    move-result-object v2

    check-cast v2, Ljava/lang/Iterable;

    .local v2, "$this$filter$iv":Ljava/lang/Iterable;
    const/4 v3, 0x0

    .line 1362
    .local v3, "$i$f$filter":I
    new-instance v4, Ljava/util/ArrayList;

    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    check-cast v4, Ljava/util/Collection;

    .local v4, "destination$iv$iv":Ljava/util/Collection;
    move-object v5, v2

    .local v5, "$this$filterTo$iv$iv":Ljava/lang/Iterable;
    const/4 v6, 0x0

    .line 1363
    .local v6, "$i$f$filterTo":I
    invoke-interface {v5}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v7

    :cond_4
    :goto_2
    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    move-result v8

    if-eqz v8, :cond_7

    invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v8

    .local v8, "element$iv$iv":Ljava/lang/Object;
    move-object v9, v8

    check-cast v9, Ljava/lang/Number;

    invoke-virtual {v9}, Ljava/lang/Number;->intValue()I

    move-result v9

    .local v9, "it":I
    const/4 v10, 0x0

    .line 853
    .local v10, "$i$a$-filter-KugouRushFragment$coinsFor$coins$1":I
    invoke-interface {v1}, Ljava/util/Set;->isEmpty()Z

    move-result v11

    if-nez v11, :cond_6

    invoke-static {v9}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v11

    invoke-interface {v1, v11}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v11

    if-eqz v11, :cond_5

    goto :goto_3

    :cond_5
    const/4 v11, 0x0

    goto :goto_4

    :cond_6
    :goto_3
    const/4 v11, 0x1

    .line 1363
    .end local v9    # "it":I
    .end local v10    # "$i$a$-filter-KugouRushFragment$coinsFor$coins$1":I
    :goto_4
    if-eqz v11, :cond_4

    invoke-interface {v4, v8}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_2

    .line 1364
    .end local v8    # "element$iv$iv":Ljava/lang/Object;
    :cond_7
    nop

    .end local v4    # "destination$iv$iv":Ljava/util/Collection;
    .end local v5    # "$this$filterTo$iv$iv":Ljava/lang/Iterable;
    .end local v6    # "$i$f$filterTo":I
    check-cast v4, Ljava/util/List;

    .line 1362
    nop

    .end local v2    # "$this$filter$iv":Ljava/lang/Iterable;
    .end local v3    # "$i$f$filter":I
    check-cast v4, Ljava/lang/Iterable;

    .line 853
    invoke-static {v4}, Lkotlin/collections/CollectionsKt;->sortedDescending(Ljava/lang/Iterable;)Ljava/util/List;

    move-result-object v2

    .line 854
    .local v2, "coins":Ljava/util/List;
    invoke-direct {p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->maxLevelSelect()I

    move-result v3

    .line 855
    .local v3, "maxLv":I
    if-lez v3, :cond_8

    move-object v4, v2

    check-cast v4, Ljava/lang/Iterable;

    invoke-static {v4, v3}, Lkotlin/collections/CollectionsKt;->take(Ljava/lang/Iterable;I)Ljava/util/List;

    move-result-object v4

    goto :goto_5

    :cond_8
    move-object v4, v2

    :goto_5
    return-object v4
.end method

.method private final defaultCoins(Ljava/util/List;Ljava/util/Set;)Ljava/util/Set;
    .locals 14
    .param p1, "levels"    # Ljava/util/List;
    .param p2, "previous"    # Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/goudong/jd/data/model/KugouLevel;",
            ">;",
            "Ljava/util/Set<",
            "Ljava/lang/Integer;",
            ">;)",
            "Ljava/util/Set<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation

    .line 826
    move-object v0, p1

    check-cast v0, Ljava/lang/Iterable;

    .local v0, "$this$filter$iv":Ljava/lang/Iterable;
    const/4 v1, 0x0

    .line 1331
    .local v1, "$i$f$filter":I
    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    check-cast v2, Ljava/util/Collection;

    .local v2, "destination$iv$iv":Ljava/util/Collection;
    move-object v3, v0

    .local v3, "$this$filterTo$iv$iv":Ljava/lang/Iterable;
    const/4 v4, 0x0

    .line 1332
    .local v4, "$i$f$filterTo":I
    invoke-interface {v3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :cond_0
    :goto_0
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_1

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    .local v6, "element$iv$iv":Ljava/lang/Object;
    move-object v7, v6

    check-cast v7, Lcom/goudong/jd/data/model/KugouLevel;

    .local v7, "it":Lcom/goudong/jd/data/model/KugouLevel;
    const/4 v8, 0x0

    .line 826
    .local v8, "$i$a$-filter-KugouRushFragment$defaultCoins$affordable$1":I
    invoke-virtual {v7}, Lcom/goudong/jd/data/model/KugouLevel;->getAffordable()Z

    move-result v7

    .line 1332
    .end local v7    # "it":Lcom/goudong/jd/data/model/KugouLevel;
    .end local v8    # "$i$a$-filter-KugouRushFragment$defaultCoins$affordable$1":I
    if-eqz v7, :cond_0

    invoke-interface {v2, v6}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_0

    .line 1333
    .end local v6    # "element$iv$iv":Ljava/lang/Object;
    :cond_1
    nop

    .end local v2    # "destination$iv$iv":Ljava/util/Collection;
    .end local v3    # "$this$filterTo$iv$iv":Ljava/lang/Iterable;
    .end local v4    # "$i$f$filterTo":I
    check-cast v2, Ljava/util/List;

    .line 1331
    nop

    .end local v0    # "$this$filter$iv":Ljava/lang/Iterable;
    .end local v1    # "$i$f$filter":I
    check-cast v2, Ljava/lang/Iterable;

    .line 826
    move-object v0, v2

    .local v0, "$this$map$iv":Ljava/lang/Iterable;
    const/4 v1, 0x0

    .line 1334
    .local v1, "$i$f$map":I
    new-instance v2, Ljava/util/ArrayList;

    const/16 v3, 0xa

    invoke-static {v0, v3}, Lkotlin/collections/CollectionsKt;->collectionSizeOrDefault(Ljava/lang/Iterable;I)I

    move-result v4

    invoke-direct {v2, v4}, Ljava/util/ArrayList;-><init>(I)V

    check-cast v2, Ljava/util/Collection;

    .restart local v2    # "destination$iv$iv":Ljava/util/Collection;
    move-object v4, v0

    .local v4, "$this$mapTo$iv$iv":Ljava/lang/Iterable;
    const/4 v5, 0x0

    .line 1335
    .local v5, "$i$f$mapTo":I
    invoke-interface {v4}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v6

    :goto_1
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    if-eqz v7, :cond_2

    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v7

    .line 1336
    .local v7, "item$iv$iv":Ljava/lang/Object;
    move-object v8, v7

    check-cast v8, Lcom/goudong/jd/data/model/KugouLevel;

    .local v8, "it":Lcom/goudong/jd/data/model/KugouLevel;
    const/4 v9, 0x0

    .line 826
    .local v9, "$i$a$-map-KugouRushFragment$defaultCoins$affordable$2":I
    invoke-virtual {v8}, Lcom/goudong/jd/data/model/KugouLevel;->getCoins()I

    move-result v8

    .end local v8    # "it":Lcom/goudong/jd/data/model/KugouLevel;
    .end local v9    # "$i$a$-map-KugouRushFragment$defaultCoins$affordable$2":I
    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    .line 1336
    invoke-interface {v2, v8}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_1

    .line 1337
    .end local v7    # "item$iv$iv":Ljava/lang/Object;
    :cond_2
    nop

    .end local v2    # "destination$iv$iv":Ljava/util/Collection;
    .end local v4    # "$this$mapTo$iv$iv":Ljava/lang/Iterable;
    .end local v5    # "$i$f$mapTo":I
    check-cast v2, Ljava/util/List;

    .line 1334
    nop

    .end local v0    # "$this$map$iv":Ljava/lang/Iterable;
    .end local v1    # "$i$f$map":I
    check-cast v2, Ljava/lang/Iterable;

    .line 826
    invoke-static {v2}, Lkotlin/collections/CollectionsKt;->toSet(Ljava/lang/Iterable;)Ljava/util/Set;

    move-result-object v0

    .line 827
    .local v0, "affordable":Ljava/util/Set;
    if-eqz p2, :cond_5

    move-object/from16 v1, p2

    check-cast v1, Ljava/lang/Iterable;

    .local v1, "$this$filter$iv":Ljava/lang/Iterable;
    const/4 v2, 0x0

    .line 1338
    .local v2, "$i$f$filter":I
    new-instance v4, Ljava/util/ArrayList;

    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    check-cast v4, Ljava/util/Collection;

    .local v4, "destination$iv$iv":Ljava/util/Collection;
    move-object v5, v1

    .local v5, "$this$filterTo$iv$iv":Ljava/lang/Iterable;
    const/4 v6, 0x0

    .line 1339
    .local v6, "$i$f$filterTo":I
    invoke-interface {v5}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v7

    :cond_3
    :goto_2
    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    move-result v8

    if-eqz v8, :cond_4

    invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v8

    .local v8, "element$iv$iv":Ljava/lang/Object;
    move-object v9, v8

    check-cast v9, Ljava/lang/Number;

    invoke-virtual {v9}, Ljava/lang/Number;->intValue()I

    move-result v9

    .local v9, "it":I
    const/4 v10, 0x0

    .line 827
    .local v10, "$i$a$-filter-KugouRushFragment$defaultCoins$kept$1":I
    invoke-static {v9}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v11

    invoke-interface {v0, v11}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v9

    .line 1339
    .end local v9    # "it":I
    .end local v10    # "$i$a$-filter-KugouRushFragment$defaultCoins$kept$1":I
    if-eqz v9, :cond_3

    invoke-interface {v4, v8}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_2

    .line 1340
    .end local v8    # "element$iv$iv":Ljava/lang/Object;
    :cond_4
    nop

    .end local v4    # "destination$iv$iv":Ljava/util/Collection;
    .end local v5    # "$this$filterTo$iv$iv":Ljava/lang/Iterable;
    .end local v6    # "$i$f$filterTo":I
    check-cast v4, Ljava/util/List;

    .line 1338
    nop

    .end local v1    # "$this$filter$iv":Ljava/lang/Iterable;
    .end local v2    # "$i$f$filter":I
    goto :goto_3

    .line 827
    :cond_5
    const/4 v4, 0x0

    :goto_3
    if-nez v4, :cond_6

    invoke-static {}, Lkotlin/collections/CollectionsKt;->emptyList()Ljava/util/List;

    move-result-object v4

    :cond_6
    move-object v1, v4

    .line 828
    .local v1, "kept":Ljava/util/List;
    move-object v2, v1

    check-cast v2, Ljava/util/Collection;

    invoke-interface {v2}, Ljava/util/Collection;->isEmpty()Z

    move-result v2

    xor-int/lit8 v2, v2, 0x1

    if-eqz v2, :cond_7

    move-object v2, v1

    check-cast v2, Ljava/lang/Iterable;

    invoke-static {v2}, Lkotlin/collections/CollectionsKt;->toMutableSet(Ljava/lang/Iterable;)Ljava/util/Set;

    move-result-object v2

    return-object v2

    .line 829
    :cond_7
    invoke-direct {p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->maxLevelSelect()I

    move-result v2

    .line 830
    .local v2, "maxLv":I
    move-object v4, p1

    check-cast v4, Ljava/lang/Iterable;

    .local v4, "$this$filter$iv":Ljava/lang/Iterable;
    const/4 v5, 0x0

    .line 1341
    .local v5, "$i$f$filter":I
    new-instance v6, Ljava/util/ArrayList;

    invoke-direct {v6}, Ljava/util/ArrayList;-><init>()V

    check-cast v6, Ljava/util/Collection;

    .local v6, "destination$iv$iv":Ljava/util/Collection;
    move-object v7, v4

    .local v7, "$this$filterTo$iv$iv":Ljava/lang/Iterable;
    const/4 v8, 0x0

    .line 1342
    .local v8, "$i$f$filterTo":I
    invoke-interface {v7}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v9

    :cond_8
    :goto_4
    invoke-interface {v9}, Ljava/util/Iterator;->hasNext()Z

    move-result v10

    if-eqz v10, :cond_9

    invoke-interface {v9}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v10

    .local v10, "element$iv$iv":Ljava/lang/Object;
    move-object v11, v10

    check-cast v11, Lcom/goudong/jd/data/model/KugouLevel;

    .local v11, "it":Lcom/goudong/jd/data/model/KugouLevel;
    const/4 v12, 0x0

    .line 830
    .local v12, "$i$a$-filter-KugouRushFragment$defaultCoins$sorted$1":I
    invoke-virtual {v11}, Lcom/goudong/jd/data/model/KugouLevel;->getAffordable()Z

    move-result v11

    .line 1342
    .end local v11    # "it":Lcom/goudong/jd/data/model/KugouLevel;
    .end local v12    # "$i$a$-filter-KugouRushFragment$defaultCoins$sorted$1":I
    if-eqz v11, :cond_8

    invoke-interface {v6, v10}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_4

    .line 1343
    .end local v10    # "element$iv$iv":Ljava/lang/Object;
    :cond_9
    nop

    .end local v6    # "destination$iv$iv":Ljava/util/Collection;
    .end local v7    # "$this$filterTo$iv$iv":Ljava/lang/Iterable;
    .end local v8    # "$i$f$filterTo":I
    check-cast v6, Ljava/util/List;

    .line 1341
    nop

    .end local v4    # "$this$filter$iv":Ljava/lang/Iterable;
    .end local v5    # "$i$f$filter":I
    check-cast v6, Ljava/lang/Iterable;

    .line 830
    move-object v4, v6

    .local v4, "$this$sortedByDescending$iv":Ljava/lang/Iterable;
    const/4 v5, 0x0

    .line 1344
    .local v5, "$i$f$sortedByDescending":I
    new-instance v6, Lcom/goudong/jd/ui/projects/KugouRushFragment$defaultCoins$$inlined$sortedByDescending$1;

    invoke-direct {v6}, Lcom/goudong/jd/ui/projects/KugouRushFragment$defaultCoins$$inlined$sortedByDescending$1;-><init>()V

    check-cast v6, Ljava/util/Comparator;

    invoke-static {v4, v6}, Lkotlin/collections/CollectionsKt;->sortedWith(Ljava/lang/Iterable;Ljava/util/Comparator;)Ljava/util/List;

    move-result-object v4

    .line 830
    .end local v4    # "$this$sortedByDescending$iv":Ljava/lang/Iterable;
    .end local v5    # "$i$f$sortedByDescending":I
    nop

    .line 831
    .local v4, "sorted":Ljava/util/List;
    if-lez v2, :cond_a

    move-object v5, v4

    check-cast v5, Ljava/lang/Iterable;

    invoke-static {v5, v2}, Lkotlin/collections/CollectionsKt;->take(Ljava/lang/Iterable;I)Ljava/util/List;

    move-result-object v5

    goto :goto_5

    :cond_a
    move-object v5, v4

    .line 832
    .local v5, "take":Ljava/util/List;
    :goto_5
    move-object v6, v5

    check-cast v6, Ljava/lang/Iterable;

    .local v6, "$this$map$iv":Ljava/lang/Iterable;
    const/4 v7, 0x0

    .line 1345
    .local v7, "$i$f$map":I
    new-instance v8, Ljava/util/ArrayList;

    invoke-static {v6, v3}, Lkotlin/collections/CollectionsKt;->collectionSizeOrDefault(Ljava/lang/Iterable;I)I

    move-result v3

    invoke-direct {v8, v3}, Ljava/util/ArrayList;-><init>(I)V

    move-object v3, v8

    check-cast v3, Ljava/util/Collection;

    .local v3, "destination$iv$iv":Ljava/util/Collection;
    move-object v8, v6

    .local v8, "$this$mapTo$iv$iv":Ljava/lang/Iterable;
    const/4 v9, 0x0

    .line 1346
    .local v9, "$i$f$mapTo":I
    invoke-interface {v8}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v10

    :goto_6
    invoke-interface {v10}, Ljava/util/Iterator;->hasNext()Z

    move-result v11

    if-eqz v11, :cond_b

    invoke-interface {v10}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v11

    .line 1347
    .local v11, "item$iv$iv":Ljava/lang/Object;
    move-object v12, v11

    check-cast v12, Lcom/goudong/jd/data/model/KugouLevel;

    .local v12, "it":Lcom/goudong/jd/data/model/KugouLevel;
    const/4 v13, 0x0

    .line 832
    .local v13, "$i$a$-map-KugouRushFragment$defaultCoins$1":I
    invoke-virtual {v12}, Lcom/goudong/jd/data/model/KugouLevel;->getCoins()I

    move-result v12

    .end local v12    # "it":Lcom/goudong/jd/data/model/KugouLevel;
    .end local v13    # "$i$a$-map-KugouRushFragment$defaultCoins$1":I
    invoke-static {v12}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v12

    .line 1347
    invoke-interface {v3, v12}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_6

    .line 1348
    .end local v11    # "item$iv$iv":Ljava/lang/Object;
    :cond_b
    nop

    .end local v3    # "destination$iv$iv":Ljava/util/Collection;
    .end local v8    # "$this$mapTo$iv$iv":Ljava/lang/Iterable;
    .end local v9    # "$i$f$mapTo":I
    check-cast v3, Ljava/util/List;

    .line 1345
    nop

    .end local v6    # "$this$map$iv":Ljava/lang/Iterable;
    .end local v7    # "$i$f$map":I
    check-cast v3, Ljava/lang/Iterable;

    .line 832
    invoke-static {v3}, Lkotlin/collections/CollectionsKt;->toMutableSet(Ljava/lang/Iterable;)Ljava/util/Set;

    move-result-object v3

    return-object v3
.end method

.method private final flushTaskLogs(Ljava/util/List;)V
    .locals 4
    .param p1, "logs"    # Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/goudong/jd/data/model/KuwoTaskLog;",
            ">;)V"
        }
    .end annotation

    .line 1184
    iget-boolean v0, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->followLiveLogs:Z

    if-nez v0, :cond_0

    return-void

    .line 1185
    :cond_0
    move-object v0, p1

    check-cast v0, Ljava/util/Collection;

    const/4 v1, 0x1

    if-eqz v0, :cond_2

    invoke-interface {v0}, Ljava/util/Collection;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_1

    goto :goto_0

    :cond_1
    const/4 v0, 0x0

    goto :goto_1

    :cond_2
    :goto_0
    move v0, v1

    :goto_1
    if-eqz v0, :cond_3

    return-void

    .line 1186
    :cond_3
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v0

    iget v2, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->taskLogIndex:I

    if-gt v0, v2, :cond_4

    return-void

    .line 1187
    :cond_4
    iget-object v0, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->logText:Landroid/widget/TextView;

    if-eqz v0, :cond_5

    invoke-virtual {v0}, Landroid/widget/TextView;->getText()Ljava/lang/CharSequence;

    move-result-object v0

    if-eqz v0, :cond_5

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    goto :goto_2

    :cond_5
    const/4 v0, 0x0

    :goto_2
    if-nez v0, :cond_6

    const-string v0, ""

    :cond_6
    check-cast v0, Ljava/lang/CharSequence;

    invoke-static {v0}, Lkotlin/text/StringsKt;->isBlank(Ljava/lang/CharSequence;)Z

    move-result v0

    .line 1188
    .local v0, "panelEmpty":Z
    if-nez v0, :cond_9

    iget v2, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->taskLogIndex:I

    if-nez v2, :cond_7

    goto :goto_4

    .line 1192
    :cond_7
    iget v1, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->taskLogIndex:I

    .local v1, "i":I
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v2

    :goto_3
    if-ge v1, v2, :cond_8

    .line 1193
    invoke-interface {p1, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/goudong/jd/data/model/KuwoTaskLog;

    invoke-direct {p0, v3}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->renderTaskLog(Lcom/goudong/jd/data/model/KuwoTaskLog;)V

    .line 1192
    add-int/lit8 v1, v1, 0x1

    goto :goto_3

    .line 1195
    .end local v1    # "i":I
    :cond_8
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v1

    iput v1, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->taskLogIndex:I

    .line 1196
    return-void

    .line 1189
    :cond_9
    :goto_4
    invoke-direct {p0, p1, v1}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->renderServerLogs(Ljava/util/List;Z)V

    .line 1190
    return-void
.end method

.method private final formatTaskLogLine(Lcom/goudong/jd/data/model/KuwoTaskLog;)Ljava/lang/String;
    .locals 6
    .param p1, "entry"    # Lcom/goudong/jd/data/model/KuwoTaskLog;

    .line 1164
    const/4 v0, 0x4

    new-array v0, v0, [Lkotlin/Pair;

    const-string v1, "info"

    const-string v2, "\u2139\ufe0f"

    invoke-static {v1, v2}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v1

    const/4 v2, 0x0

    aput-object v1, v0, v2

    const-string v1, "success"

    const-string v2, "\u2705"

    invoke-static {v1, v2}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v1

    const/4 v2, 0x1

    aput-object v1, v0, v2

    const-string v1, "warn"

    const-string v2, "\u26a0\ufe0f"

    invoke-static {v1, v2}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v1

    const/4 v2, 0x2

    aput-object v1, v0, v2

    const-string v1, "error"

    const-string v2, "\u274c"

    invoke-static {v1, v2}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v1

    const/4 v2, 0x3

    aput-object v1, v0, v2

    invoke-static {v0}, Lkotlin/collections/MapsKt;->mapOf([Lkotlin/Pair;)Ljava/util/Map;

    move-result-object v0

    .line 1165
    .local v0, "icons":Ljava/util/Map;
    invoke-virtual {p1}, Lcom/goudong/jd/data/model/KuwoTaskLog;->getLevel()Ljava/lang/String;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    if-nez v1, :cond_0

    const-string v1, "\u2022"

    .line 1166
    .local v1, "icon":Ljava/lang/String;
    :cond_0
    invoke-virtual {p1}, Lcom/goudong/jd/data/model/KuwoTaskLog;->getTime()Ljava/lang/String;

    move-result-object v2

    if-nez v2, :cond_1

    const-string v2, "--"

    :cond_1
    invoke-virtual {p1}, Lcom/goudong/jd/data/model/KuwoTaskLog;->getMessage()Ljava/lang/String;

    move-result-object v3

    if-nez v3, :cond_2

    const-string v3, ""

    :cond_2
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "["

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v4, "] "

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v4, " "

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    return-object v2
.end method

.method private final getRushProduct()Ljava/lang/String;
    .locals 5

    .line 67
    invoke-virtual {p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->getArguments()Landroid/os/Bundle;

    move-result-object v0

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    const-string v2, "kugou_product"

    invoke-virtual {v0, v2}, Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_0

    move-object v2, v0

    .line 1303
    .local v2, "it":Ljava/lang/String;
    const/4 v3, 0x0

    .line 67
    .local v3, "$i$a$-takeIf-KugouRushFragment$rushProduct$1":I
    const-string v4, "std"

    invoke-static {v2, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    .end local v2    # "it":Ljava/lang/String;
    .end local v3    # "$i$a$-takeIf-KugouRushFragment$rushProduct$1":I
    if-eqz v2, :cond_0

    move-object v1, v0

    :cond_0
    if-nez v1, :cond_1

    const-string v1, "concept"

    :cond_1
    return-object v1
.end method

.method private final isAutoRushMode()Z
    .locals 2

    .line 537
    iget-object v0, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->portalConfig:Lcom/goudong/jd/data/model/KugouPortalConfig;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Lcom/goudong/jd/data/model/KugouPortalConfig;->getRushMode()Ljava/lang/String;

    move-result-object v0

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    if-eqz v0, :cond_2

    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v1

    sparse-switch v1, :sswitch_data_0

    goto :goto_1

    :sswitch_0
    const-string v1, "debug"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_1

    goto :goto_1

    :sswitch_1
    const-string v1, "auto"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    goto :goto_1

    :sswitch_2
    const-string v1, "manual"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_2

    .line 538
    :cond_1
    const/4 v0, 0x0

    return v0

    .line 540
    :cond_2
    :goto_1
    const/4 v0, 0x1

    return v0

    nop

    :sswitch_data_0
    .sparse-switch
        -0x4075183a -> :sswitch_2
        0x2dddaf -> :sswitch_1
        0x5b09653 -> :sswitch_0
    .end sparse-switch
.end method

.method private final isDebugRush()Z
    .locals 4

    .line 566
    iget-object v0, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->portalConfig:Lcom/goudong/jd/data/model/KugouPortalConfig;

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Lcom/goudong/jd/data/model/KugouPortalConfig;->getDebugRush()Ljava/lang/Boolean;

    move-result-object v0

    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v3

    invoke-static {v0, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    goto :goto_0

    :cond_0
    move v0, v2

    :goto_0
    if-nez v0, :cond_3

    iget-object v0, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->portalConfig:Lcom/goudong/jd/data/model/KugouPortalConfig;

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Lcom/goudong/jd/data/model/KugouPortalConfig;->getRushMode()Ljava/lang/String;

    move-result-object v0

    goto :goto_1

    :cond_1
    const/4 v0, 0x0

    :goto_1
    const-string v3, "debug"

    invoke-static {v0, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_2

    goto :goto_2

    :cond_2
    move v1, v2

    :cond_3
    :goto_2
    return v1
.end method

.method private final isDebugRushMode()Z
    .locals 4

    .line 534
    iget-object v0, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->portalConfig:Lcom/goudong/jd/data/model/KugouPortalConfig;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Lcom/goudong/jd/data/model/KugouPortalConfig;->getRushMode()Ljava/lang/String;

    move-result-object v0

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    const-string v1, "debug"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    const/4 v1, 0x1

    if-nez v0, :cond_3

    iget-object v0, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->portalConfig:Lcom/goudong/jd/data/model/KugouPortalConfig;

    const/4 v2, 0x0

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Lcom/goudong/jd/data/model/KugouPortalConfig;->getDebugRush()Ljava/lang/Boolean;

    move-result-object v0

    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v3

    invoke-static {v0, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    goto :goto_1

    :cond_1
    move v0, v2

    :goto_1
    if-eqz v0, :cond_2

    goto :goto_2

    :cond_2
    move v1, v2

    :cond_3
    :goto_2
    return v1
.end method

.method private final isEmbeddedInHub()Z
    .locals 4

    .line 81
    invoke-virtual {p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->getArguments()Landroid/os/Bundle;

    move-result-object v0

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const-string v3, "kugou_embedded_hub"

    invoke-virtual {v0, v3}, Landroid/os/Bundle;->getBoolean(Ljava/lang/String;)Z

    move-result v0

    if-ne v0, v1, :cond_0

    move v0, v1

    goto :goto_0

    :cond_0
    move v0, v2

    :goto_0
    if-nez v0, :cond_2

    invoke-virtual {p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->getParentFragment()Landroidx/fragment/app/Fragment;

    move-result-object v0

    instance-of v0, v0, Lcom/goudong/jd/ui/projects/KugouRushHubFragment;

    if-eqz v0, :cond_1

    goto :goto_1

    :cond_1
    move v1, v2

    :cond_2
    :goto_1
    return v1
.end method

.method private final kugouPortalCopy(Ljava/lang/String;)Ljava/lang/String;
    .locals 4
    .param p1, "raw"    # Ljava/lang/String;

    .line 466
    const/4 v0, 0x0

    if-eqz p1, :cond_0

    move-object v1, p1

    check-cast v1, Ljava/lang/CharSequence;

    invoke-static {v1}, Lkotlin/text/StringsKt;->trim(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    goto :goto_0

    :cond_0
    move-object v1, v0

    :goto_0
    if-nez v1, :cond_1

    const-string v1, ""

    .line 467
    .local v1, "s":Ljava/lang/String;
    :cond_1
    move-object v2, v1

    check-cast v2, Ljava/lang/CharSequence;

    invoke-interface {v2}, Ljava/lang/CharSequence;->length()I

    move-result v2

    const/4 v3, 0x1

    if-nez v2, :cond_2

    move v2, v3

    goto :goto_1

    :cond_2
    const/4 v2, 0x0

    :goto_1
    if-eqz v2, :cond_3

    return-object v0

    .line 468
    :cond_3
    invoke-direct {p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->getRushProduct()Ljava/lang/String;

    move-result-object v0

    const-string v2, "std"

    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_4

    .line 469
    const-string v0, "KGPUB"

    const-string v2, "KG_RW"

    invoke-static {v1, v0, v2, v3}, Lkotlin/text/StringsKt;->replace(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)Ljava/lang/String;

    move-result-object v1

    .line 471
    :cond_4
    return-object v1
.end method

.method private final kugouSessionSpinnerAdapter(Ljava/util/List;)Landroid/widget/ArrayAdapter;
    .locals 2
    .param p1, "labels"    # Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)",
            "Landroid/widget/ArrayAdapter<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 647
    invoke-virtual {p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->requireContext()Landroid/content/Context;

    move-result-object v0

    const-string v1, "requireContext(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 648
    .local v0, "ctx":Landroid/content/Context;
    new-instance v1, Lcom/goudong/jd/ui/projects/KugouRushFragment$kugouSessionSpinnerAdapter$1;

    invoke-direct {v1, v0, p1}, Lcom/goudong/jd/ui/projects/KugouRushFragment$kugouSessionSpinnerAdapter$1;-><init>(Landroid/content/Context;Ljava/util/List;)V

    check-cast v1, Landroid/widget/ArrayAdapter;

    return-object v1
.end method

.method private final label(Ljava/lang/String;)Landroid/widget/TextView;
    .locals 5
    .param p1, "text"    # Ljava/lang/String;

    .line 456
    new-instance v0, Landroid/widget/TextView;

    invoke-virtual {p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->requireContext()Landroid/content/Context;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object v1, v0

    .local v1, "$this$label_u24lambda_u2444":Landroid/widget/TextView;
    const/4 v2, 0x0

    .line 457
    .local v2, "$i$a$-apply-KugouRushFragment$label$1":I
    move-object v3, p1

    check-cast v3, Ljava/lang/CharSequence;

    invoke-virtual {v1, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 458
    invoke-virtual {p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->requireContext()Landroid/content/Context;

    move-result-object v3

    const-string v4, "requireContext(...)"

    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    sget v4, Lcom/goudong/jd/R$color;->text_primary:I

    invoke-static {v3, v4}, Lcom/goudong/jd/ui/common/AppThemeKt;->themeColor(Landroid/content/Context;I)I

    move-result v3

    invoke-virtual {v1, v3}, Landroid/widget/TextView;->setTextColor(I)V

    .line 459
    const/high16 v3, 0x41600000    # 14.0f

    invoke-static {v1, v3}, Lcom/goudong/jd/ui/common/AppTypographyKt;->setTextSp(Landroid/widget/TextView;F)V

    .line 460
    invoke-virtual {v1}, Landroid/widget/TextView;->getTypeface()Landroid/graphics/Typeface;

    move-result-object v3

    const/4 v4, 0x1

    invoke-virtual {v1, v3, v4}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 461
    nop

    .line 456
    .end local v1    # "$this$label_u24lambda_u2444":Landroid/widget/TextView;
    .end local v2    # "$i$a$-apply-KugouRushFragment$label$1":I
    nop

    .line 461
    return-object v0
.end method

.method private final loadKugouSessions()V
    .locals 7

    .line 626
    invoke-virtual {p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->getViewLifecycleOwner()Landroidx/lifecycle/LifecycleOwner;

    move-result-object v0

    const-string v1, "getViewLifecycleOwner(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v0}, Landroidx/lifecycle/LifecycleOwnerKt;->getLifecycleScope(Landroidx/lifecycle/LifecycleOwner;)Landroidx/lifecycle/LifecycleCoroutineScope;

    move-result-object v0

    move-object v1, v0

    check-cast v1, Lkotlinx/coroutines/CoroutineScope;

    new-instance v0, Lcom/goudong/jd/ui/projects/KugouRushFragment$loadKugouSessions$1;

    const/4 v2, 0x0

    invoke-direct {v0, p0, v2}, Lcom/goudong/jd/ui/projects/KugouRushFragment$loadKugouSessions$1;-><init>(Lcom/goudong/jd/ui/projects/KugouRushFragment;Lkotlin/coroutines/Continuation;)V

    move-object v4, v0

    check-cast v4, Lkotlin/jvm/functions/Function2;

    const/4 v5, 0x3

    const/4 v6, 0x0

    const/4 v3, 0x0

    invoke-static/range {v1 .. v6}, Lkotlinx/coroutines/BuildersKt;->launch$default(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/CoroutineContext;Lkotlinx/coroutines/CoroutineStart;Lkotlin/jvm/functions/Function2;ILjava/lang/Object;)Lkotlinx/coroutines/Job;

    .line 644
    return-void
.end method

.method private final loadLevels()V
    .locals 19

    .line 767
    move-object/from16 v0, p0

    iget-boolean v1, v0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->authorized:Z

    if-nez v1, :cond_1

    .line 768
    move-object v1, v0

    check-cast v1, Landroidx/fragment/app/Fragment;

    invoke-direct/range {p0 .. p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->getRushProduct()Ljava/lang/String;

    move-result-object v2

    const-string v3, "std"

    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_0

    const-string v2, "\u8bf7\u5148\u4e0a\u8f66\u9177\u72d7\u666e\u901a\u7248\uff08KG_RW\uff09"

    goto :goto_0

    :cond_0
    const-string v2, "\u8bf7\u5148\u4e0a\u8f66\u9177\u72d7\u6982\u5ff5\u7248\uff08KGGNB\uff09"

    :goto_0
    invoke-static {v1, v2}, Lcom/goudong/jd/ui/common/UiKitKt;->toast(Landroidx/fragment/app/Fragment;Ljava/lang/String;)V

    .line 769
    return-void

    .line 771
    :cond_1
    invoke-direct/range {p0 .. p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->selectedAccounts()Ljava/util/List;

    move-result-object v1

    check-cast v1, Ljava/lang/Iterable;

    .local v1, "$this$mapNotNull$iv":Ljava/lang/Iterable;
    const/4 v2, 0x0

    .line 1318
    .local v2, "$i$f$mapNotNull":I
    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    check-cast v3, Ljava/util/Collection;

    .local v3, "destination$iv$iv":Ljava/util/Collection;
    move-object v4, v1

    .local v4, "$this$mapNotNullTo$iv$iv":Ljava/lang/Iterable;
    const/4 v5, 0x0

    .line 1326
    .local v5, "$i$f$mapNotNullTo":I
    move-object v6, v4

    .local v6, "$this$forEach$iv$iv$iv":Ljava/lang/Iterable;
    const/4 v7, 0x0

    .line 1327
    .local v7, "$i$f$forEach":I
    invoke-interface {v6}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v8

    :goto_1
    invoke-interface {v8}, Ljava/util/Iterator;->hasNext()Z

    move-result v9

    const/4 v10, 0x0

    if-eqz v9, :cond_4

    invoke-interface {v8}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v9

    .local v9, "element$iv$iv$iv":Ljava/lang/Object;
    move-object v11, v9

    .local v11, "element$iv$iv":Ljava/lang/Object;
    const/4 v12, 0x0

    .line 1326
    .local v12, "$i$a$-forEach-CollectionsKt___CollectionsKt$mapNotNullTo$1$iv$iv":I
    move-object v13, v11

    check-cast v13, Lcom/goudong/jd/data/model/KugouAccount;

    .local v13, "it":Lcom/goudong/jd/data/model/KugouAccount;
    const/4 v14, 0x0

    .line 771
    .local v14, "$i$a$-mapNotNull-KugouRushFragment$loadLevels$targets$1":I
    invoke-virtual {v13}, Lcom/goudong/jd/data/model/KugouAccount;->getUserid()Ljava/lang/String;

    move-result-object v15

    if-eqz v15, :cond_2

    move-object/from16 v16, v15

    .line 1303
    .local v16, "id":Ljava/lang/String;
    const/16 v17, 0x0

    .line 771
    .local v17, "$i$a$-takeIf-KugouRushFragment$loadLevels$targets$1$1":I
    move-object/from16 v18, v16

    check-cast v18, Ljava/lang/CharSequence;

    invoke-static/range {v18 .. v18}, Lkotlin/text/StringsKt;->isBlank(Ljava/lang/CharSequence;)Z

    move-result v18

    xor-int/lit8 v18, v18, 0x1

    .end local v16    # "id":Ljava/lang/String;
    .end local v17    # "$i$a$-takeIf-KugouRushFragment$loadLevels$targets$1$1":I
    if-eqz v18, :cond_2

    move-object v10, v15

    .line 1326
    .end local v13    # "it":Lcom/goudong/jd/data/model/KugouAccount;
    .end local v14    # "$i$a$-mapNotNull-KugouRushFragment$loadLevels$targets$1":I
    :cond_2
    if-eqz v10, :cond_3

    .line 1328
    .local v10, "it$iv$iv":Ljava/lang/Object;
    const/4 v13, 0x0

    .line 1326
    .local v13, "$i$a$-let-CollectionsKt___CollectionsKt$mapNotNullTo$1$1$iv$iv":I
    invoke-interface {v3, v10}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    .line 1327
    .end local v10    # "it$iv$iv":Ljava/lang/Object;
    .end local v11    # "element$iv$iv":Ljava/lang/Object;
    .end local v12    # "$i$a$-forEach-CollectionsKt___CollectionsKt$mapNotNullTo$1$iv$iv":I
    .end local v13    # "$i$a$-let-CollectionsKt___CollectionsKt$mapNotNullTo$1$1$iv$iv":I
    :cond_3
    nop

    .end local v9    # "element$iv$iv$iv":Ljava/lang/Object;
    goto :goto_1

    .line 1329
    :cond_4
    nop

    .line 1330
    .end local v6    # "$this$forEach$iv$iv$iv":Ljava/lang/Iterable;
    .end local v7    # "$i$f$forEach":I
    nop

    .end local v3    # "destination$iv$iv":Ljava/util/Collection;
    .end local v4    # "$this$mapNotNullTo$iv$iv":Ljava/lang/Iterable;
    .end local v5    # "$i$f$mapNotNullTo":I
    check-cast v3, Ljava/util/List;

    .line 1318
    nop

    .line 771
    .end local v1    # "$this$mapNotNull$iv":Ljava/lang/Iterable;
    .end local v2    # "$i$f$mapNotNull":I
    move-object v1, v3

    .line 772
    .local v1, "targets":Ljava/util/List;
    invoke-interface {v1}, Ljava/util/List;->isEmpty()Z

    move-result v2

    if-eqz v2, :cond_5

    .line 773
    move-object v2, v0

    check-cast v2, Landroidx/fragment/app/Fragment;

    const-string v3, "\u8bf7\u81f3\u5c11\u9009\u62e9\u4e00\u4e2a\u8d26\u53f7"

    invoke-static {v2, v3}, Lcom/goudong/jd/ui/common/UiKitKt;->toast(Landroidx/fragment/app/Fragment;Ljava/lang/String;)V

    .line 774
    return-void

    .line 776
    :cond_5
    iget-object v2, v0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->loadLevelsBtn:Landroid/widget/TextView;

    if-eqz v2, :cond_6

    check-cast v2, Landroid/view/View;

    const-string v3, "\u8bfb\u53d6\u6863\u4f4d"

    const-string v4, "\u8bfb\u53d6\u4e2d..."

    invoke-static {v2, v3, v4}, Lcom/goudong/jd/ui/common/UiKitKt;->showBtnLoading(Landroid/view/View;Ljava/lang/String;Ljava/lang/String;)V

    .line 777
    :cond_6
    invoke-virtual/range {p0 .. p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->getViewLifecycleOwner()Landroidx/lifecycle/LifecycleOwner;

    move-result-object v2

    const-string v3, "getViewLifecycleOwner(...)"

    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v2}, Landroidx/lifecycle/LifecycleOwnerKt;->getLifecycleScope(Landroidx/lifecycle/LifecycleOwner;)Landroidx/lifecycle/LifecycleCoroutineScope;

    move-result-object v2

    move-object v3, v2

    check-cast v3, Lkotlinx/coroutines/CoroutineScope;

    new-instance v2, Lcom/goudong/jd/ui/projects/KugouRushFragment$loadLevels$1;

    invoke-direct {v2, v1, v0, v10}, Lcom/goudong/jd/ui/projects/KugouRushFragment$loadLevels$1;-><init>(Ljava/util/List;Lcom/goudong/jd/ui/projects/KugouRushFragment;Lkotlin/coroutines/Continuation;)V

    move-object v6, v2

    check-cast v6, Lkotlin/jvm/functions/Function2;

    const/4 v7, 0x3

    const/4 v8, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-static/range {v3 .. v8}, Lkotlinx/coroutines/BuildersKt;->launch$default(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/CoroutineContext;Lkotlinx/coroutines/CoroutineStart;Lkotlin/jvm/functions/Function2;ILjava/lang/Object;)Lkotlinx/coroutines/Job;

    .line 823
    return-void
.end method

.method private final loadPage()V
    .locals 7

    .line 571
    invoke-virtual {p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->getViewLifecycleOwner()Landroidx/lifecycle/LifecycleOwner;

    move-result-object v0

    const-string v1, "getViewLifecycleOwner(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v0}, Landroidx/lifecycle/LifecycleOwnerKt;->getLifecycleScope(Landroidx/lifecycle/LifecycleOwner;)Landroidx/lifecycle/LifecycleCoroutineScope;

    move-result-object v0

    move-object v1, v0

    check-cast v1, Lkotlinx/coroutines/CoroutineScope;

    new-instance v0, Lcom/goudong/jd/ui/projects/KugouRushFragment$loadPage$1;

    const/4 v2, 0x0

    invoke-direct {v0, p0, v2}, Lcom/goudong/jd/ui/projects/KugouRushFragment$loadPage$1;-><init>(Lcom/goudong/jd/ui/projects/KugouRushFragment;Lkotlin/coroutines/Continuation;)V

    move-object v4, v0

    check-cast v4, Lkotlin/jvm/functions/Function2;

    const/4 v5, 0x3

    const/4 v6, 0x0

    const/4 v3, 0x0

    invoke-static/range {v1 .. v6}, Lkotlinx/coroutines/BuildersKt;->launch$default(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/CoroutineContext;Lkotlinx/coroutines/CoroutineStart;Lkotlin/jvm/functions/Function2;ILjava/lang/Object;)Lkotlinx/coroutines/Job;

    .line 607
    return-void
.end method

.method private final maskId(Ljava/lang/String;)Ljava/lang/String;
    .locals 3
    .param p1, "id"    # Ljava/lang/String;

    .line 1296
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v0

    const/16 v1, 0x8

    if-gt v0, v1, :cond_0

    return-object p1

    .line 1297
    :cond_0
    const/4 v0, 0x4

    invoke-static {p1, v0}, Lkotlin/text/StringsKt;->take(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v1

    invoke-static {p1, v0}, Lkotlin/text/StringsKt;->takeLast(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v0

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "..."

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method private final maxLevelSelect()I
    .locals 5

    .line 529
    iget-object v0, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->portalConfig:Lcom/goudong/jd/data/model/KugouPortalConfig;

    const/4 v1, 0x0

    if-eqz v0, :cond_2

    invoke-virtual {v0}, Lcom/goudong/jd/data/model/KugouPortalConfig;->getMaxLevelSelect()Ljava/lang/Integer;

    move-result-object v0

    if-eqz v0, :cond_2

    move-object v2, v0

    check-cast v2, Ljava/lang/Number;

    invoke-virtual {v2}, Ljava/lang/Number;->intValue()I

    move-result v2

    .line 1303
    .local v2, "it":I
    const/4 v3, 0x0

    .line 529
    .local v3, "$i$a$-takeIf-KugouRushFragment$maxLevelSelect$1":I
    if-lez v2, :cond_0

    const/4 v4, 0x1

    goto :goto_0

    :cond_0
    move v4, v1

    .end local v2    # "it":I
    .end local v3    # "$i$a$-takeIf-KugouRushFragment$maxLevelSelect$1":I
    :goto_0
    if-eqz v4, :cond_1

    goto :goto_1

    :cond_1
    const/4 v0, 0x0

    :goto_1
    if-eqz v0, :cond_2

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v1

    :cond_2
    return v1
.end method

.method private final monitorTask(Ljava/lang/String;Z)V
    .locals 12
    .param p1, "taskId"    # Ljava/lang/String;
    .param p2, "immediate"    # Z

    .line 1027
    iput-boolean p2, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->monitorImmediate:Z

    .line 1028
    iget-object v0, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->monitorJob:Lkotlinx/coroutines/Job;

    if-eqz v0, :cond_0

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-static {v0, v2, v1, v2}, Lkotlinx/coroutines/Job$DefaultImpls;->cancel$default(Lkotlinx/coroutines/Job;Ljava/util/concurrent/CancellationException;ILjava/lang/Object;)V

    .line 1029
    :cond_0
    if-eqz p2, :cond_1

    const-wide/16 v0, 0xfa

    goto :goto_0

    :cond_1
    const-wide/16 v0, 0x320

    :goto_0
    move-wide v4, v0

    .line 1030
    .local v4, "pollMs":J
    invoke-virtual {p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->getViewLifecycleOwner()Landroidx/lifecycle/LifecycleOwner;

    move-result-object v0

    const-string v1, "getViewLifecycleOwner(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v0}, Landroidx/lifecycle/LifecycleOwnerKt;->getLifecycleScope(Landroidx/lifecycle/LifecycleOwner;)Landroidx/lifecycle/LifecycleCoroutineScope;

    move-result-object v0

    check-cast v0, Lkotlinx/coroutines/CoroutineScope;

    new-instance v1, Lcom/goudong/jd/ui/projects/KugouRushFragment$monitorTask$1;

    const/4 v8, 0x0

    move-object v2, v1

    move-object v3, p0

    move-object v6, p1

    move v7, p2

    invoke-direct/range {v2 .. v8}, Lcom/goudong/jd/ui/projects/KugouRushFragment$monitorTask$1;-><init>(Lcom/goudong/jd/ui/projects/KugouRushFragment;JLjava/lang/String;ZLkotlin/coroutines/Continuation;)V

    move-object v9, v1

    check-cast v9, Lkotlin/jvm/functions/Function2;

    const/4 v10, 0x3

    const/4 v11, 0x0

    const/4 v7, 0x0

    move-object v6, v0

    invoke-static/range {v6 .. v11}, Lkotlinx/coroutines/BuildersKt;->launch$default(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/CoroutineContext;Lkotlinx/coroutines/CoroutineStart;Lkotlin/jvm/functions/Function2;ILjava/lang/Object;)Lkotlinx/coroutines/Job;

    move-result-object v0

    iput-object v0, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->monitorJob:Lkotlinx/coroutines/Job;

    .line 1064
    return-void
.end method

.method private final preOpenMin()I
    .locals 2

    .line 531
    sget-object v0, Lcom/goudong/jd/ui/projects/KugouTimeHelper;->INSTANCE:Lcom/goudong/jd/ui/projects/KugouTimeHelper;

    iget-object v1, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->portalConfig:Lcom/goudong/jd/data/model/KugouPortalConfig;

    if-eqz v1, :cond_0

    invoke-virtual {v1}, Lcom/goudong/jd/data/model/KugouPortalConfig;->getPreOpenMin()Ljava/lang/Integer;

    move-result-object v1

    goto :goto_0

    :cond_0
    const/4 v1, 0x0

    :goto_0
    invoke-virtual {v0, v1}, Lcom/goudong/jd/ui/projects/KugouTimeHelper;->resolvePreOpenMin(Ljava/lang/Integer;)I

    move-result v0

    return v0
.end method

.method private final prefs()Landroid/content/SharedPreferences;
    .locals 4

    .line 463
    invoke-virtual {p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->requireContext()Landroid/content/Context;

    move-result-object v0

    invoke-direct {p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->getRushProduct()Ljava/lang/String;

    move-result-object v1

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "kugou_rush_"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v2, 0x0

    invoke-virtual {v0, v1, v2}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v0

    return-object v0
.end method

.method private final refreshConfigStaleHint()V
    .locals 10

    .line 498
    iget-object v0, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->timeHintText:Landroid/widget/TextView;

    if-nez v0, :cond_0

    return-void

    .line 499
    .local v0, "hint":Landroid/widget/TextView;
    :cond_0
    const-string v7, "\uff08\u914d\u7f6e\u6765\u81ea\u79bb\u7ebf\u7f13\u5b58\uff0c\u8054\u7f51\u540e\u5c06\u81ea\u52a8\u5237\u65b0\uff09"

    .line 500
    .local v7, "suffix":Ljava/lang/String;
    invoke-virtual {v0}, Landroid/widget/TextView;->getText()Ljava/lang/CharSequence;

    move-result-object v1

    const/4 v8, 0x0

    if-eqz v1, :cond_1

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    goto :goto_0

    :cond_1
    move-object v1, v8

    :goto_0
    if-nez v1, :cond_2

    const-string v1, ""

    :cond_2
    move-object v9, v1

    .line 501
    .local v9, "base":Ljava/lang/String;
    const/4 v5, 0x4

    const/4 v6, 0x0

    const-string v3, ""

    const/4 v4, 0x0

    move-object v2, v7

    invoke-static/range {v1 .. v6}, Lkotlin/text/StringsKt;->replace$default(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    check-cast v1, Ljava/lang/CharSequence;

    invoke-static {v1}, Lkotlin/text/StringsKt;->trimEnd(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    .line 502
    .local v1, "stripped":Ljava/lang/String;
    iget-boolean v2, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->portalConfigFromCache:Z

    const/4 v3, 0x2

    if-eqz v2, :cond_3

    .line 503
    move-object v2, v9

    check-cast v2, Ljava/lang/CharSequence;

    move-object v5, v7

    check-cast v5, Ljava/lang/CharSequence;

    invoke-static {v2, v5, v4, v3, v8}, Lkotlin/text/StringsKt;->contains$default(Ljava/lang/CharSequence;Ljava/lang/CharSequence;ZILjava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_4

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    check-cast v2, Ljava/lang/CharSequence;

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    goto :goto_1

    .line 504
    :cond_3
    move-object v2, v9

    check-cast v2, Ljava/lang/CharSequence;

    move-object v5, v7

    check-cast v5, Ljava/lang/CharSequence;

    invoke-static {v2, v5, v4, v3, v8}, Lkotlin/text/StringsKt;->contains$default(Ljava/lang/CharSequence;Ljava/lang/CharSequence;ZILjava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_4

    .line 505
    move-object v2, v1

    check-cast v2, Ljava/lang/CharSequence;

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 507
    :cond_4
    :goto_1
    return-void
.end method

.method private final refreshRevenueShareCashHint()V
    .locals 7

    .line 610
    invoke-virtual {p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->getViewLifecycleOwner()Landroidx/lifecycle/LifecycleOwner;

    move-result-object v0

    const-string v1, "getViewLifecycleOwner(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v0}, Landroidx/lifecycle/LifecycleOwnerKt;->getLifecycleScope(Landroidx/lifecycle/LifecycleOwner;)Landroidx/lifecycle/LifecycleCoroutineScope;

    move-result-object v0

    move-object v1, v0

    check-cast v1, Lkotlinx/coroutines/CoroutineScope;

    new-instance v0, Lcom/goudong/jd/ui/projects/KugouRushFragment$refreshRevenueShareCashHint$1;

    const/4 v2, 0x0

    invoke-direct {v0, p0, v2}, Lcom/goudong/jd/ui/projects/KugouRushFragment$refreshRevenueShareCashHint$1;-><init>(Lcom/goudong/jd/ui/projects/KugouRushFragment;Lkotlin/coroutines/Continuation;)V

    move-object v4, v0

    check-cast v4, Lkotlin/jvm/functions/Function2;

    const/4 v5, 0x3

    const/4 v6, 0x0

    const/4 v3, 0x0

    invoke-static/range {v1 .. v6}, Lkotlinx/coroutines/BuildersKt;->launch$default(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/CoroutineContext;Lkotlinx/coroutines/CoroutineStart;Lkotlin/jvm/functions/Function2;ILjava/lang/Object;)Lkotlinx/coroutines/Job;

    .line 623
    return-void
.end method

.method private final renderAccounts()V
    .locals 40

    .line 673
    move-object/from16 v6, p0

    iget-object v0, v6, Lcom/goudong/jd/ui/projects/KugouRushFragment;->accountListWrap:Landroid/widget/LinearLayout;

    if-nez v0, :cond_0

    return-void

    :cond_0
    move-object v7, v0

    .line 674
    .local v7, "wrap":Landroid/widget/LinearLayout;
    invoke-virtual/range {p0 .. p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->getContext()Landroid/content/Context;

    move-result-object v0

    if-nez v0, :cond_1

    return-void

    :cond_1
    move-object v14, v0

    .line 675
    .local v14, "ctx":Landroid/content/Context;
    invoke-virtual {v7}, Landroid/widget/LinearLayout;->removeAllViews()V

    .line 676
    iget-object v0, v6, Lcom/goudong/jd/ui/projects/KugouRushFragment;->accounts:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_3

    .line 677
    invoke-direct/range {p0 .. p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->getRushProduct()Ljava/lang/String;

    move-result-object v0

    const-string v1, "std"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_2

    const-string v0, "KG_RW"

    goto :goto_0

    :cond_2
    const-string v0, "KGGNB"

    :goto_0
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "\u6682\u65e0\u8d26\u53f7\uff0c\u8bf7\u5148\u5728\u9879\u76ee\u4e2d\u5fc3\u586b\u5199 "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {v6, v0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->captionText(Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v0

    check-cast v0, Landroid/view/View;

    invoke-virtual {v7, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 678
    return-void

    .line 680
    :cond_3
    iget-object v0, v6, Lcom/goudong/jd/ui/projects/KugouRushFragment;->accounts:Ljava/util/List;

    move-object v15, v0

    check-cast v15, Ljava/lang/Iterable;

    .local v15, "$this$forEach$iv":Ljava/lang/Iterable;
    const/16 v16, 0x0

    .line 1313
    .local v16, "$i$f$forEach":I
    invoke-interface {v15}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v17

    :goto_1
    invoke-interface/range {v17 .. v17}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_1b

    invoke-interface/range {v17 .. v17}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v18

    .local v18, "element$iv":Ljava/lang/Object;
    move-object/from16 v19, v18

    check-cast v19, Lcom/goudong/jd/data/model/KugouAccount;

    .local v19, "acc":Lcom/goudong/jd/data/model/KugouAccount;
    const/16 v20, 0x0

    .line 681
    .local v20, "$i$a$-forEach-KugouRushFragment$renderAccounts$1":I
    invoke-virtual/range {v19 .. v19}, Lcom/goudong/jd/data/model/KugouAccount;->getUserid()Ljava/lang/String;

    move-result-object v0

    const-string v21, ""

    if-nez v0, :cond_4

    move-object/from16 v0, v21

    :cond_4
    move-object v5, v0

    .line 682
    .local v5, "uid":Ljava/lang/String;
    iget-object v0, v6, Lcom/goudong/jd/ui/projects/KugouRushFragment;->selectedUserIds:Ljava/util/LinkedHashSet;

    invoke-virtual {v0, v5}, Ljava/util/LinkedHashSet;->contains(Ljava/lang/Object;)Z

    move-result v4

    .line 683
    .local v4, "participating":Z
    new-instance v0, Landroid/widget/LinearLayout;

    invoke-direct {v0, v14}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object v1, v0

    .local v1, "$this$renderAccounts_u24lambda_u2473_u24lambda_u2456":Landroid/widget/LinearLayout;
    const/4 v2, 0x0

    .line 684
    .local v2, "$i$a$-apply-KugouRushFragment$renderAccounts$1$card$1":I
    const/4 v3, 0x1

    invoke-virtual {v1, v3}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 685
    const/4 v12, 0x6

    const/4 v13, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x0

    move-object v8, v14

    move v9, v4

    invoke-static/range {v8 .. v13}, Lcom/goudong/jd/ui/common/UiKitKt;->selectableItemSurface$default(Landroid/content/Context;ZZIILjava/lang/Object;)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v8

    check-cast v8, Landroid/graphics/drawable/Drawable;

    invoke-virtual {v1, v8}, Landroid/widget/LinearLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 686
    const/16 v8, 0xa

    invoke-static {v14, v8}, Lcom/goudong/jd/ui/common/UiKitKt;->dp(Landroid/content/Context;I)I

    move-result v9

    const/16 v10, 0x8

    invoke-static {v14, v10}, Lcom/goudong/jd/ui/common/UiKitKt;->dp(Landroid/content/Context;I)I

    move-result v11

    invoke-static {v14, v8}, Lcom/goudong/jd/ui/common/UiKitKt;->dp(Landroid/content/Context;I)I

    move-result v8

    invoke-static {v14, v10}, Lcom/goudong/jd/ui/common/UiKitKt;->dp(Landroid/content/Context;I)I

    move-result v12

    invoke-virtual {v1, v9, v11, v8, v12}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 687
    new-instance v8, Landroid/widget/LinearLayout$LayoutParams;

    .line 688
    nop

    .line 689
    nop

    .line 687
    const/4 v9, -0x1

    const/4 v11, -0x2

    invoke-direct {v8, v9, v11}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 690
    nop

    .line 1303
    move-object v9, v8

    .local v9, "$this$renderAccounts_u24lambda_u2473_u24lambda_u2456_u24lambda_u2455":Landroid/widget/LinearLayout$LayoutParams;
    const/4 v11, 0x0

    .line 690
    .local v11, "$i$a$-apply-KugouRushFragment$renderAccounts$1$card$1$1":I
    invoke-static {v14, v10}, Lcom/goudong/jd/ui/common/UiKitKt;->dp(Landroid/content/Context;I)I

    move-result v12

    iput v12, v9, Landroid/widget/LinearLayout$LayoutParams;->bottomMargin:I

    .end local v9    # "$this$renderAccounts_u24lambda_u2473_u24lambda_u2456_u24lambda_u2455":Landroid/widget/LinearLayout$LayoutParams;
    .end local v11    # "$i$a$-apply-KugouRushFragment$renderAccounts$1$card$1$1":I
    check-cast v8, Landroid/view/ViewGroup$LayoutParams;

    .line 687
    invoke-virtual {v1, v8}, Landroid/widget/LinearLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 691
    nop

    .line 683
    .end local v1    # "$this$renderAccounts_u24lambda_u2473_u24lambda_u2456":Landroid/widget/LinearLayout;
    .end local v2    # "$i$a$-apply-KugouRushFragment$renderAccounts$1$card$1":I
    move-object v8, v0

    .line 692
    .local v8, "card":Landroid/widget/LinearLayout;
    invoke-virtual/range {v19 .. v19}, Lcom/goudong/jd/data/model/KugouAccount;->getNickname()Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_6

    check-cast v0, Ljava/lang/CharSequence;

    invoke-static {v0}, Lkotlin/text/StringsKt;->isBlank(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_5

    .line 1303
    const/4 v0, 0x0

    .line 692
    .local v0, "$i$a$-ifBlank-KugouRushFragment$renderAccounts$1$name$1":I
    invoke-direct {v6, v5}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->maskId(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .end local v0    # "$i$a$-ifBlank-KugouRushFragment$renderAccounts$1$name$1":I
    :cond_5
    check-cast v0, Ljava/lang/String;

    if-nez v0, :cond_7

    :cond_6
    invoke-direct {v6, v5}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->maskId(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    :cond_7
    move-object v9, v0

    .line 693
    .local v9, "name":Ljava/lang/String;
    new-instance v0, Landroid/widget/CheckBox;

    invoke-direct {v0, v14}, Landroid/widget/CheckBox;-><init>(Landroid/content/Context;)V

    move-object v1, v0

    .local v1, "$this$renderAccounts_u24lambda_u2473_u24lambda_u2460":Landroid/widget/CheckBox;
    const/4 v2, 0x0

    .line 694
    .local v2, "$i$a$-apply-KugouRushFragment$renderAccounts$1$1":I
    invoke-direct {v6, v5}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->maskId(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    new-instance v12, Ljava/lang/StringBuilder;

    invoke-direct {v12}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v12, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    const-string v13, "  "

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    invoke-virtual {v12, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v11

    invoke-virtual {v11}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v11

    check-cast v11, Ljava/lang/CharSequence;

    invoke-virtual {v1, v11}, Landroid/widget/CheckBox;->setText(Ljava/lang/CharSequence;)V

    .line 695
    invoke-virtual {v1, v4}, Landroid/widget/CheckBox;->setChecked(Z)V

    .line 696
    sget v11, Lcom/goudong/jd/R$color;->text_primary:I

    invoke-static {v14, v11}, Lcom/goudong/jd/ui/common/AppThemeKt;->themeColor(Landroid/content/Context;I)I

    move-result v11

    invoke-virtual {v1, v11}, Landroid/widget/CheckBox;->setTextColor(I)V

    .line 697
    invoke-virtual {v1}, Landroid/widget/CheckBox;->getTypeface()Landroid/graphics/Typeface;

    move-result-object v11

    invoke-virtual {v1, v11, v3}, Landroid/widget/CheckBox;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 698
    new-instance v11, Lcom/goudong/jd/ui/projects/KugouRushFragment$$ExternalSyntheticLambda1;

    invoke-direct {v11, v6, v5, v7}, Lcom/goudong/jd/ui/projects/KugouRushFragment$$ExternalSyntheticLambda1;-><init>(Lcom/goudong/jd/ui/projects/KugouRushFragment;Ljava/lang/String;Landroid/widget/LinearLayout;)V

    invoke-virtual {v1, v11}, Landroid/widget/CheckBox;->setOnCheckedChangeListener(Landroid/widget/CompoundButton$OnCheckedChangeListener;)V

    .line 702
    nop

    .line 693
    .end local v1    # "$this$renderAccounts_u24lambda_u2473_u24lambda_u2460":Landroid/widget/CheckBox;
    .end local v2    # "$i$a$-apply-KugouRushFragment$renderAccounts$1$1":I
    check-cast v0, Landroid/view/View;

    invoke-virtual {v8, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 703
    iget-object v0, v6, Lcom/goudong/jd/ui/projects/KugouRushFragment;->tierByUser:Ljava/util/LinkedHashMap;

    invoke-virtual {v0, v5}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    move-object v11, v0

    check-cast v11, Lcom/goudong/jd/ui/projects/KugouRushFragment$AccountTierState;

    .line 704
    .local v11, "tier":Lcom/goudong/jd/ui/projects/KugouRushFragment$AccountTierState;
    sget-object v0, Lcom/goudong/jd/ui/projects/KugouTimeHelper;->INSTANCE:Lcom/goudong/jd/ui/projects/KugouTimeHelper;

    invoke-direct/range {p0 .. p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->preOpenMin()I

    move-result v1

    invoke-virtual {v0, v1}, Lcom/goudong/jd/ui/projects/KugouTimeHelper;->getNextWithdrawInfo(I)Lcom/goudong/jd/ui/projects/KugouTimeHelper$NextWithdrawInfo;

    move-result-object v12

    .line 705
    .local v12, "rush":Lcom/goudong/jd/ui/projects/KugouTimeHelper$NextWithdrawInfo;
    if-eqz v11, :cond_8

    sget-object v0, Lcom/goudong/jd/ui/projects/KugouTimeHelper;->INSTANCE:Lcom/goudong/jd/ui/projects/KugouTimeHelper;

    .line 706
    invoke-virtual {v12}, Lcom/goudong/jd/ui/projects/KugouTimeHelper$NextWithdrawInfo;->getHour()I

    move-result v1

    invoke-virtual {v12}, Lcom/goudong/jd/ui/projects/KugouTimeHelper$NextWithdrawInfo;->getDiffMin()I

    move-result v2

    invoke-virtual {v11}, Lcom/goudong/jd/ui/projects/KugouRushFragment$AccountTierState;->getDayApplyCount()I

    move-result v3

    invoke-virtual {v11}, Lcom/goudong/jd/ui/projects/KugouRushFragment$AccountTierState;->getMaxApplyCount()I

    move-result v13

    .line 705
    invoke-virtual {v0, v1, v2, v3, v13}, Lcom/goudong/jd/ui/projects/KugouTimeHelper;->dayApplyBlocksParticipation(IIII)Z

    move-result v0

    if-eqz v0, :cond_8

    const/4 v0, 0x1

    goto :goto_2

    :cond_8
    const/4 v0, 0x0

    :goto_2
    move v13, v0

    .line 708
    .local v13, "withdrawn":Z
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    move-object v1, v0

    .local v1, "$this$renderAccounts_u24lambda_u2473_u24lambda_u2461":Ljava/lang/StringBuilder;
    const/4 v2, 0x0

    .line 709
    .local v2, "$i$a$-buildString-KugouRushFragment$renderAccounts$1$balanceLine$1":I
    invoke-virtual/range {v19 .. v19}, Lcom/goudong/jd/data/model/KugouAccount;->getBalanceKnown()Z

    move-result v3

    const-string v10, " \u91d1\u5e01"

    if-eqz v3, :cond_9

    invoke-virtual/range {v19 .. v19}, Lcom/goudong/jd/data/model/KugouAccount;->getBalance()I

    move-result v3

    move/from16 v23, v2

    .end local v2    # "$i$a$-buildString-KugouRushFragment$renderAccounts$1$balanceLine$1":I
    .local v23, "$i$a$-buildString-KugouRushFragment$renderAccounts$1$balanceLine$1":I
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    move-object/from16 v24, v5

    .end local v5    # "uid":Ljava/lang/String;
    .local v24, "uid":Ljava/lang/String;
    const-string v5, "\u4f59\u989d "

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    goto :goto_3

    .end local v23    # "$i$a$-buildString-KugouRushFragment$renderAccounts$1$balanceLine$1":I
    .end local v24    # "uid":Ljava/lang/String;
    .restart local v2    # "$i$a$-buildString-KugouRushFragment$renderAccounts$1$balanceLine$1":I
    .restart local v5    # "uid":Ljava/lang/String;
    :cond_9
    move/from16 v23, v2

    move-object/from16 v24, v5

    .end local v2    # "$i$a$-buildString-KugouRushFragment$renderAccounts$1$balanceLine$1":I
    .end local v5    # "uid":Ljava/lang/String;
    .restart local v23    # "$i$a$-buildString-KugouRushFragment$renderAccounts$1$balanceLine$1":I
    .restart local v24    # "uid":Ljava/lang/String;
    const-string v2, "\u4f59\u989d\u672a\u77e5"

    :goto_3
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 710
    if-eqz v11, :cond_a

    invoke-virtual {v11}, Lcom/goudong/jd/ui/projects/KugouRushFragment$AccountTierState;->getMaxApplyCount()I

    move-result v2

    if-lez v2, :cond_a

    .line 711
    invoke-virtual {v11}, Lcom/goudong/jd/ui/projects/KugouRushFragment$AccountTierState;->getDayApplyCount()I

    move-result v2

    invoke-virtual {v11}, Lcom/goudong/jd/ui/projects/KugouRushFragment$AccountTierState;->getMaxApplyCount()I

    move-result v3

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    move-object/from16 v25, v9

    .end local v9    # "name":Ljava/lang/String;
    .local v25, "name":Ljava/lang/String;
    const-string v9, " \u00b7 \u4eca\u65e5 "

    invoke-virtual {v5, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v5, "/"

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_4

    .line 710
    .end local v25    # "name":Ljava/lang/String;
    .restart local v9    # "name":Ljava/lang/String;
    :cond_a
    move-object/from16 v25, v9

    .line 713
    .end local v9    # "name":Ljava/lang/String;
    .restart local v25    # "name":Ljava/lang/String;
    :goto_4
    nop

    .line 708
    .end local v1    # "$this$renderAccounts_u24lambda_u2473_u24lambda_u2461":Ljava/lang/StringBuilder;
    .end local v23    # "$i$a$-buildString-KugouRushFragment$renderAccounts$1$balanceLine$1":I
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, "toString(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    move-object v9, v0

    .line 714
    .local v9, "balanceLine":Ljava/lang/String;
    invoke-direct {v6, v9}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->captionText(Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v0

    move-object v1, v0

    .local v1, "$this$renderAccounts_u24lambda_u2473_u24lambda_u2462":Landroid/widget/TextView;
    const/4 v2, 0x0

    .line 715
    .local v2, "$i$a$-apply-KugouRushFragment$renderAccounts$1$2":I
    const/16 v3, 0x8

    invoke-static {v14, v3}, Lcom/goudong/jd/ui/common/UiKitKt;->dp(Landroid/content/Context;I)I

    move-result v5

    const/4 v3, 0x4

    invoke-static {v14, v3}, Lcom/goudong/jd/ui/common/UiKitKt;->dp(Landroid/content/Context;I)I

    move-result v3

    move/from16 v23, v2

    const/4 v2, 0x0

    .end local v2    # "$i$a$-apply-KugouRushFragment$renderAccounts$1$2":I
    .local v23, "$i$a$-apply-KugouRushFragment$renderAccounts$1$2":I
    invoke-virtual {v1, v5, v2, v2, v3}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 716
    nop

    .line 714
    .end local v1    # "$this$renderAccounts_u24lambda_u2473_u24lambda_u2462":Landroid/widget/TextView;
    .end local v23    # "$i$a$-apply-KugouRushFragment$renderAccounts$1$2":I
    check-cast v0, Landroid/view/View;

    invoke-virtual {v8, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 717
    const/4 v5, 0x2

    if-nez v4, :cond_b

    .line 718
    const-string v0, "\u672a\u53c2\u4e0e\u672c\u6b21\u62a2\u5151"

    invoke-direct {v6, v0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->captionText(Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v0

    move-object v1, v0

    .local v1, "$this$renderAccounts_u24lambda_u2473_u24lambda_u2463":Landroid/widget/TextView;
    const/4 v2, 0x0

    .line 719
    .local v2, "$i$a$-apply-KugouRushFragment$renderAccounts$1$3":I
    const/16 v3, 0x8

    invoke-static {v14, v3}, Lcom/goudong/jd/ui/common/UiKitKt;->dp(Landroid/content/Context;I)I

    move-result v3

    invoke-static {v14, v5}, Lcom/goudong/jd/ui/common/UiKitKt;->dp(Landroid/content/Context;I)I

    move-result v5

    const/4 v10, 0x0

    invoke-virtual {v1, v3, v10, v10, v5}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 720
    nop

    .line 718
    .end local v1    # "$this$renderAccounts_u24lambda_u2473_u24lambda_u2463":Landroid/widget/TextView;
    .end local v2    # "$i$a$-apply-KugouRushFragment$renderAccounts$1$3":I
    check-cast v0, Landroid/view/View;

    invoke-virtual {v8, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    move/from16 v34, v4

    move-object/from16 v35, v9

    move-object/from16 v39, v11

    goto/16 :goto_f

    .line 721
    :cond_b
    if-eqz v11, :cond_1a

    invoke-virtual {v11}, Lcom/goudong/jd/ui/projects/KugouRushFragment$AccountTierState;->getLevels()Ljava/util/List;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_c

    move/from16 v34, v4

    move-object/from16 v35, v9

    move-object/from16 v39, v11

    move v11, v5

    goto/16 :goto_e

    .line 726
    :cond_c
    if-eqz v13, :cond_d

    .line 727
    invoke-virtual {v11}, Lcom/goudong/jd/ui/projects/KugouRushFragment$AccountTierState;->getSelectedCoins()Ljava/util/Set;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Set;->clear()V

    .line 728
    const-string v0, "\u4eca\u65e5\u5df2\u63d0\u73b0"

    invoke-direct {v6, v0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->captionText(Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v0

    move-object v1, v0

    .local v1, "$this$renderAccounts_u24lambda_u2473_u24lambda_u2465":Landroid/widget/TextView;
    const/4 v2, 0x0

    .line 729
    .local v2, "$i$a$-apply-KugouRushFragment$renderAccounts$1$5":I
    move/from16 v23, v2

    const/16 v3, 0x8

    .end local v2    # "$i$a$-apply-KugouRushFragment$renderAccounts$1$5":I
    .local v23, "$i$a$-apply-KugouRushFragment$renderAccounts$1$5":I
    invoke-static {v14, v3}, Lcom/goudong/jd/ui/common/UiKitKt;->dp(Landroid/content/Context;I)I

    move-result v2

    invoke-static {v14, v5}, Lcom/goudong/jd/ui/common/UiKitKt;->dp(Landroid/content/Context;I)I

    move-result v3

    const/4 v5, 0x0

    invoke-virtual {v1, v2, v5, v5, v3}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 730
    sget v2, Lcom/goudong/jd/R$color;->text_primary:I

    invoke-static {v14, v2}, Lcom/goudong/jd/ui/common/AppThemeKt;->themeColor(Landroid/content/Context;I)I

    move-result v2

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setTextColor(I)V

    .line 731
    nop

    .line 728
    .end local v1    # "$this$renderAccounts_u24lambda_u2473_u24lambda_u2465":Landroid/widget/TextView;
    .end local v23    # "$i$a$-apply-KugouRushFragment$renderAccounts$1$5":I
    check-cast v0, Landroid/view/View;

    invoke-virtual {v8, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 733
    :cond_d
    invoke-virtual {v11}, Lcom/goudong/jd/ui/projects/KugouRushFragment$AccountTierState;->getLevels()Ljava/util/List;

    move-result-object v0

    check-cast v0, Ljava/lang/Iterable;

    .local v0, "$this$sortedByDescending$iv":Ljava/lang/Iterable;
    const/4 v1, 0x0

    .line 1314
    .local v1, "$i$f$sortedByDescending":I
    new-instance v2, Lcom/goudong/jd/ui/projects/KugouRushFragment$renderAccounts$lambda$73$$inlined$sortedByDescending$1;

    invoke-direct {v2}, Lcom/goudong/jd/ui/projects/KugouRushFragment$renderAccounts$lambda$73$$inlined$sortedByDescending$1;-><init>()V

    check-cast v2, Ljava/util/Comparator;

    invoke-static {v0, v2}, Lkotlin/collections/CollectionsKt;->sortedWith(Ljava/lang/Iterable;Ljava/util/Comparator;)Ljava/util/List;

    move-result-object v0

    .end local v0    # "$this$sortedByDescending$iv":Ljava/lang/Iterable;
    .end local v1    # "$i$f$sortedByDescending":I
    check-cast v0, Ljava/lang/Iterable;

    .line 733
    move-object/from16 v23, v0

    .local v23, "$this$forEach$iv":Ljava/lang/Iterable;
    const/16 v27, 0x0

    .line 1315
    .local v27, "$i$f$forEach":I
    invoke-interface/range {v23 .. v23}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v28

    :goto_5
    invoke-interface/range {v28 .. v28}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_19

    invoke-interface/range {v28 .. v28}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v29

    .local v29, "element$iv":Ljava/lang/Object;
    move-object/from16 v30, v29

    check-cast v30, Lcom/goudong/jd/data/model/KugouLevel;

    .local v30, "lv":Lcom/goudong/jd/data/model/KugouLevel;
    const/16 v31, 0x0

    .line 734
    .local v31, "$i$a$-forEach-KugouRushFragment$renderAccounts$1$7":I
    invoke-virtual/range {v30 .. v30}, Lcom/goudong/jd/data/model/KugouLevel;->getYuan()Ljava/lang/Double;

    move-result-object v0

    const-string v1, "format(...)"

    const-string v2, "%.2f"

    if-eqz v0, :cond_f

    check-cast v0, Ljava/lang/Number;

    invoke-virtual {v0}, Ljava/lang/Number;->doubleValue()D

    move-result-wide v32

    .line 1303
    .local v32, "it":D
    const/4 v0, 0x0

    .line 734
    .local v0, "$i$a$-let-KugouRushFragment$renderAccounts$1$7$yuan$1":I
    invoke-static/range {v32 .. v33}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v3

    move/from16 v34, v0

    const/4 v5, 0x1

    .end local v0    # "$i$a$-let-KugouRushFragment$renderAccounts$1$7$yuan$1":I
    .local v34, "$i$a$-let-KugouRushFragment$renderAccounts$1$7$yuan$1":I
    new-array v0, v5, [Ljava/lang/Object;

    const/16 v22, 0x0

    aput-object v3, v0, v22

    invoke-static {v0, v5}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object v0

    invoke-static {v2, v0}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .end local v32    # "it":D
    .end local v34    # "$i$a$-let-KugouRushFragment$renderAccounts$1$7$yuan$1":I
    if-nez v0, :cond_e

    goto :goto_6

    :cond_e
    move v5, v4

    goto :goto_7

    :cond_f
    :goto_6
    invoke-virtual/range {v30 .. v30}, Lcom/goudong/jd/data/model/KugouLevel;->getCoins()I

    move-result v0

    move v5, v4

    .end local v4    # "participating":Z
    .local v5, "participating":Z
    int-to-double v3, v0

    const-wide v32, 0x40c3880000000000L    # 10000.0

    div-double v3, v3, v32

    invoke-static {v3, v4}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v0

    const/4 v3, 0x1

    new-array v4, v3, [Ljava/lang/Object;

    const/16 v22, 0x0

    aput-object v0, v4, v22

    invoke-static {v4, v3}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object v0

    invoke-static {v2, v0}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    :goto_7
    move-object v4, v0

    .line 735
    .local v4, "yuan":Ljava/lang/String;
    invoke-virtual/range {v30 .. v30}, Lcom/goudong/jd/data/model/KugouLevel;->getTag()Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x0

    if-eqz v0, :cond_11

    move-object v2, v0

    .line 1303
    .local v2, "it":Ljava/lang/String;
    const/4 v3, 0x0

    .line 735
    .local v3, "$i$a$-takeIf-KugouRushFragment$renderAccounts$1$7$tag$1":I
    move-object/from16 v32, v2

    check-cast v32, Ljava/lang/CharSequence;

    invoke-static/range {v32 .. v32}, Lkotlin/text/StringsKt;->isBlank(Ljava/lang/CharSequence;)Z

    move-result v32

    const/16 v22, 0x1

    xor-int/lit8 v32, v32, 0x1

    .end local v2    # "it":Ljava/lang/String;
    .end local v3    # "$i$a$-takeIf-KugouRushFragment$renderAccounts$1$7$tag$1":I
    if-eqz v32, :cond_10

    goto :goto_8

    :cond_10
    move-object v0, v1

    :goto_8
    if-eqz v0, :cond_12

    .line 1303
    .local v0, "it":Ljava/lang/String;
    const/4 v1, 0x0

    .line 735
    .local v1, "$i$a$-let-KugouRushFragment$renderAccounts$1$7$tag$2":I
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, " \u00b7 "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    .end local v0    # "it":Ljava/lang/String;
    .end local v1    # "$i$a$-let-KugouRushFragment$renderAccounts$1$7$tag$2":I
    goto :goto_9

    :cond_11
    const/16 v22, 0x1

    :cond_12
    :goto_9
    if-nez v1, :cond_13

    move-object/from16 v1, v21

    :cond_13
    move-object v3, v1

    .line 736
    .local v3, "tag":Ljava/lang/String;
    invoke-virtual/range {v30 .. v30}, Lcom/goudong/jd/data/model/KugouLevel;->getAffordable()Z

    move-result v0

    if-eqz v0, :cond_14

    if-nez v13, :cond_14

    move/from16 v0, v22

    goto :goto_a

    :cond_14
    const/4 v0, 0x0

    :goto_a
    move v2, v0

    .line 737
    .local v2, "affordable":Z
    new-instance v1, Landroid/widget/CheckBox;

    invoke-direct {v1, v14}, Landroid/widget/CheckBox;-><init>(Landroid/content/Context;)V

    move-object v0, v1

    .local v0, "$this$renderAccounts_u24lambda_u2473_u24lambda_u2472_u24lambda_u2471":Landroid/widget/CheckBox;
    const/16 v32, 0x0

    .line 738
    .local v32, "$i$a$-apply-KugouRushFragment$renderAccounts$1$7$1":I
    nop

    .line 739
    move-object/from16 v33, v1

    const-string v1, "\u5143\uff08"

    if-eqz v13, :cond_15

    move/from16 v34, v5

    .end local v5    # "participating":Z
    .local v34, "participating":Z
    invoke-virtual/range {v30 .. v30}, Lcom/goudong/jd/data/model/KugouLevel;->getCoins()I

    move-result v5

    move-object/from16 v35, v9

    .end local v9    # "balanceLine":Ljava/lang/String;
    .local v35, "balanceLine":Ljava/lang/String;
    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v9, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v5, "\uff09\u4eca\u65e5\u5df2\u63d0\u73b0"

    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    check-cast v1, Ljava/lang/CharSequence;

    goto :goto_b

    .line 740
    .end local v34    # "participating":Z
    .end local v35    # "balanceLine":Ljava/lang/String;
    .restart local v5    # "participating":Z
    .restart local v9    # "balanceLine":Ljava/lang/String;
    :cond_15
    move/from16 v34, v5

    move-object/from16 v35, v9

    .end local v5    # "participating":Z
    .end local v9    # "balanceLine":Ljava/lang/String;
    .restart local v34    # "participating":Z
    .restart local v35    # "balanceLine":Ljava/lang/String;
    invoke-virtual/range {v30 .. v30}, Lcom/goudong/jd/data/model/KugouLevel;->getAffordable()Z

    move-result v5

    if-eqz v5, :cond_16

    invoke-virtual/range {v30 .. v30}, Lcom/goudong/jd/data/model/KugouLevel;->getCoins()I

    move-result v5

    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v9, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v5, "\uff09"

    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    check-cast v1, Ljava/lang/CharSequence;

    goto :goto_b

    .line 741
    :cond_16
    invoke-virtual/range {v30 .. v30}, Lcom/goudong/jd/data/model/KugouLevel;->getCoins()I

    move-result v5

    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v9, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v5, "\uff09\u4f59\u989d\u4e0d\u8db3"

    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    check-cast v1, Ljava/lang/CharSequence;

    .line 738
    :goto_b
    invoke-virtual {v0, v1}, Landroid/widget/CheckBox;->setText(Ljava/lang/CharSequence;)V

    .line 743
    invoke-virtual {v0, v2}, Landroid/widget/CheckBox;->setEnabled(Z)V

    .line 744
    if-eqz v2, :cond_17

    invoke-virtual {v11}, Lcom/goudong/jd/ui/projects/KugouRushFragment$AccountTierState;->getSelectedCoins()Ljava/util/Set;

    move-result-object v1

    invoke-virtual/range {v30 .. v30}, Lcom/goudong/jd/data/model/KugouLevel;->getCoins()I

    move-result v5

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-interface {v1, v5}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_17

    move/from16 v1, v22

    goto :goto_c

    :cond_17
    const/4 v1, 0x0

    :goto_c
    invoke-virtual {v0, v1}, Landroid/widget/CheckBox;->setChecked(Z)V

    .line 745
    nop

    .line 746
    if-eqz v2, :cond_18

    sget v1, Lcom/goudong/jd/R$color;->text_primary:I

    invoke-static {v14, v1}, Lcom/goudong/jd/ui/common/AppThemeKt;->themeColor(Landroid/content/Context;I)I

    move-result v1

    goto :goto_d

    .line 747
    :cond_18
    sget v1, Lcom/goudong/jd/R$color;->text_muted:I

    invoke-static {v14, v1}, Lcom/goudong/jd/ui/common/AppThemeKt;->themeColor(Landroid/content/Context;I)I

    move-result v1

    .line 745
    :goto_d
    invoke-virtual {v0, v1}, Landroid/widget/CheckBox;->setTextColor(I)V

    .line 749
    const/16 v1, 0x8

    invoke-static {v14, v1}, Lcom/goudong/jd/ui/common/UiKitKt;->dp(Landroid/content/Context;I)I

    move-result v5

    const/4 v9, 0x2

    invoke-static {v14, v9}, Lcom/goudong/jd/ui/common/UiKitKt;->dp(Landroid/content/Context;I)I

    move-result v1

    move/from16 v26, v2

    .end local v2    # "affordable":Z
    .local v26, "affordable":Z
    invoke-static {v14, v9}, Lcom/goudong/jd/ui/common/UiKitKt;->dp(Landroid/content/Context;I)I

    move-result v2

    const/4 v9, 0x0

    invoke-virtual {v0, v5, v1, v9, v2}, Landroid/widget/CheckBox;->setPadding(IIII)V

    .line 750
    new-instance v9, Lcom/goudong/jd/ui/projects/KugouRushFragment$$ExternalSyntheticLambda2;

    move-object v5, v0

    .end local v0    # "$this$renderAccounts_u24lambda_u2473_u24lambda_u2472_u24lambda_u2471":Landroid/widget/CheckBox;
    .local v5, "$this$renderAccounts_u24lambda_u2473_u24lambda_u2472_u24lambda_u2471":Landroid/widget/CheckBox;
    move-object v0, v9

    move v1, v13

    move-object v2, v11

    move/from16 v37, v22

    move-object/from16 v22, v3

    .end local v3    # "tag":Ljava/lang/String;
    .local v22, "tag":Ljava/lang/String;
    move-object/from16 v3, v30

    move-object/from16 v38, v4

    .end local v4    # "yuan":Ljava/lang/String;
    .local v38, "yuan":Ljava/lang/String;
    move-object/from16 v4, p0

    move-object/from16 v36, v10

    move-object/from16 v39, v11

    const/4 v11, 0x2

    move-object v10, v5

    .end local v5    # "$this$renderAccounts_u24lambda_u2473_u24lambda_u2472_u24lambda_u2471":Landroid/widget/CheckBox;
    .end local v11    # "tier":Lcom/goudong/jd/ui/projects/KugouRushFragment$AccountTierState;
    .local v10, "$this$renderAccounts_u24lambda_u2473_u24lambda_u2472_u24lambda_u2471":Landroid/widget/CheckBox;
    .local v39, "tier":Lcom/goudong/jd/ui/projects/KugouRushFragment$AccountTierState;
    move-object/from16 v5, v24

    invoke-direct/range {v0 .. v5}, Lcom/goudong/jd/ui/projects/KugouRushFragment$$ExternalSyntheticLambda2;-><init>(ZLcom/goudong/jd/ui/projects/KugouRushFragment$AccountTierState;Lcom/goudong/jd/data/model/KugouLevel;Lcom/goudong/jd/ui/projects/KugouRushFragment;Ljava/lang/String;)V

    invoke-virtual {v10, v9}, Landroid/widget/CheckBox;->setOnCheckedChangeListener(Landroid/widget/CompoundButton$OnCheckedChangeListener;)V

    .line 759
    nop

    .line 737
    .end local v10    # "$this$renderAccounts_u24lambda_u2473_u24lambda_u2472_u24lambda_u2471":Landroid/widget/CheckBox;
    .end local v32    # "$i$a$-apply-KugouRushFragment$renderAccounts$1$7$1":I
    move-object/from16 v1, v33

    check-cast v1, Landroid/view/View;

    invoke-virtual {v8, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 760
    nop

    .line 1315
    .end local v22    # "tag":Ljava/lang/String;
    .end local v26    # "affordable":Z
    .end local v30    # "lv":Lcom/goudong/jd/data/model/KugouLevel;
    .end local v31    # "$i$a$-forEach-KugouRushFragment$renderAccounts$1$7":I
    .end local v38    # "yuan":Ljava/lang/String;
    move/from16 v4, v34

    move-object/from16 v9, v35

    move-object/from16 v10, v36

    move-object/from16 v11, v39

    .end local v29    # "element$iv":Ljava/lang/Object;
    goto/16 :goto_5

    .line 1316
    .end local v34    # "participating":Z
    .end local v35    # "balanceLine":Ljava/lang/String;
    .end local v39    # "tier":Lcom/goudong/jd/ui/projects/KugouRushFragment$AccountTierState;
    .local v4, "participating":Z
    .restart local v9    # "balanceLine":Ljava/lang/String;
    .restart local v11    # "tier":Lcom/goudong/jd/ui/projects/KugouRushFragment$AccountTierState;
    :cond_19
    move/from16 v34, v4

    move-object/from16 v35, v9

    move-object/from16 v39, v11

    .end local v4    # "participating":Z
    .end local v9    # "balanceLine":Ljava/lang/String;
    .end local v11    # "tier":Lcom/goudong/jd/ui/projects/KugouRushFragment$AccountTierState;
    .restart local v34    # "participating":Z
    .restart local v35    # "balanceLine":Ljava/lang/String;
    .restart local v39    # "tier":Lcom/goudong/jd/ui/projects/KugouRushFragment$AccountTierState;
    goto :goto_f

    .line 721
    .end local v23    # "$this$forEach$iv":Ljava/lang/Iterable;
    .end local v27    # "$i$f$forEach":I
    .end local v34    # "participating":Z
    .end local v35    # "balanceLine":Ljava/lang/String;
    .end local v39    # "tier":Lcom/goudong/jd/ui/projects/KugouRushFragment$AccountTierState;
    .restart local v4    # "participating":Z
    .restart local v9    # "balanceLine":Ljava/lang/String;
    .restart local v11    # "tier":Lcom/goudong/jd/ui/projects/KugouRushFragment$AccountTierState;
    :cond_1a
    move/from16 v34, v4

    move-object/from16 v35, v9

    move-object/from16 v39, v11

    move v11, v5

    .line 722
    .end local v4    # "participating":Z
    .end local v9    # "balanceLine":Ljava/lang/String;
    .end local v11    # "tier":Lcom/goudong/jd/ui/projects/KugouRushFragment$AccountTierState;
    .restart local v34    # "participating":Z
    .restart local v35    # "balanceLine":Ljava/lang/String;
    .restart local v39    # "tier":Lcom/goudong/jd/ui/projects/KugouRushFragment$AccountTierState;
    :goto_e
    const-string v0, "\u8bfb\u53d6\u6863\u4f4d\u540e\u53ef\u52fe\u9009"

    invoke-direct {v6, v0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->captionText(Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v0

    move-object v1, v0

    .local v1, "$this$renderAccounts_u24lambda_u2473_u24lambda_u2464":Landroid/widget/TextView;
    const/4 v2, 0x0

    .line 723
    .local v2, "$i$a$-apply-KugouRushFragment$renderAccounts$1$4":I
    const/16 v3, 0x8

    invoke-static {v14, v3}, Lcom/goudong/jd/ui/common/UiKitKt;->dp(Landroid/content/Context;I)I

    move-result v3

    invoke-static {v14, v11}, Lcom/goudong/jd/ui/common/UiKitKt;->dp(Landroid/content/Context;I)I

    move-result v4

    const/4 v5, 0x0

    invoke-virtual {v1, v3, v5, v5, v4}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 724
    nop

    .line 722
    .end local v1    # "$this$renderAccounts_u24lambda_u2473_u24lambda_u2464":Landroid/widget/TextView;
    .end local v2    # "$i$a$-apply-KugouRushFragment$renderAccounts$1$4":I
    check-cast v0, Landroid/view/View;

    invoke-virtual {v8, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 762
    :goto_f
    move-object v0, v8

    check-cast v0, Landroid/view/View;

    invoke-virtual {v7, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 763
    nop

    .line 1313
    .end local v8    # "card":Landroid/widget/LinearLayout;
    .end local v12    # "rush":Lcom/goudong/jd/ui/projects/KugouTimeHelper$NextWithdrawInfo;
    .end local v13    # "withdrawn":Z
    .end local v19    # "acc":Lcom/goudong/jd/data/model/KugouAccount;
    .end local v20    # "$i$a$-forEach-KugouRushFragment$renderAccounts$1":I
    .end local v24    # "uid":Ljava/lang/String;
    .end local v25    # "name":Ljava/lang/String;
    .end local v34    # "participating":Z
    .end local v35    # "balanceLine":Ljava/lang/String;
    .end local v39    # "tier":Lcom/goudong/jd/ui/projects/KugouRushFragment$AccountTierState;
    nop

    .end local v18    # "element$iv":Ljava/lang/Object;
    goto/16 :goto_1

    .line 1317
    :cond_1b
    nop

    .line 764
    .end local v15    # "$this$forEach$iv":Ljava/lang/Iterable;
    .end local v16    # "$i$f$forEach":I
    return-void
.end method

.method private static final renderAccounts$lambda$73$lambda$60$lambda$59(Lcom/goudong/jd/ui/projects/KugouRushFragment;Ljava/lang/String;Landroid/widget/LinearLayout;Landroid/widget/CompoundButton;Z)V
    .locals 1
    .param p0, "this$0"    # Lcom/goudong/jd/ui/projects/KugouRushFragment;
    .param p1, "$uid"    # Ljava/lang/String;
    .param p2, "$wrap"    # Landroid/widget/LinearLayout;
    .param p4, "checked"    # Z

    const-string v0, "this$0"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "$uid"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "$wrap"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "<anonymous parameter 0>"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 699
    iget-object p3, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->selectedUserIds:Ljava/util/LinkedHashSet;

    if-eqz p4, :cond_0

    invoke-virtual {p3, p1}, Ljava/util/LinkedHashSet;->add(Ljava/lang/Object;)Z

    goto :goto_0

    :cond_0
    invoke-virtual {p3, p1}, Ljava/util/LinkedHashSet;->remove(Ljava/lang/Object;)Z

    .line 700
    :goto_0
    new-instance p3, Lcom/goudong/jd/ui/projects/KugouRushFragment$$ExternalSyntheticLambda4;

    invoke-direct {p3, p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment$$ExternalSyntheticLambda4;-><init>(Lcom/goudong/jd/ui/projects/KugouRushFragment;)V

    invoke-virtual {p2, p3}, Landroid/widget/LinearLayout;->post(Ljava/lang/Runnable;)Z

    .line 701
    return-void
.end method

.method private static final renderAccounts$lambda$73$lambda$60$lambda$59$lambda$58(Lcom/goudong/jd/ui/projects/KugouRushFragment;)V
    .locals 1
    .param p0, "this$0"    # Lcom/goudong/jd/ui/projects/KugouRushFragment;

    const-string v0, "this$0"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 700
    invoke-virtual {p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->isAdded()Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-direct {p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->renderAccounts()V

    :cond_0
    return-void
.end method

.method private static final renderAccounts$lambda$73$lambda$72$lambda$71$lambda$70(ZLcom/goudong/jd/ui/projects/KugouRushFragment$AccountTierState;Lcom/goudong/jd/data/model/KugouLevel;Lcom/goudong/jd/ui/projects/KugouRushFragment;Ljava/lang/String;Landroid/widget/CompoundButton;Z)V
    .locals 1
    .param p0, "$withdrawn"    # Z
    .param p1, "$tier"    # Lcom/goudong/jd/ui/projects/KugouRushFragment$AccountTierState;
    .param p2, "$lv"    # Lcom/goudong/jd/data/model/KugouLevel;
    .param p3, "this$0"    # Lcom/goudong/jd/ui/projects/KugouRushFragment;
    .param p4, "$uid"    # Ljava/lang/String;
    .param p6, "checked"    # Z

    const-string v0, "$lv"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "this$0"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "$uid"

    invoke-static {p4, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "<anonymous parameter 0>"

    invoke-static {p5, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 751
    if-eqz p0, :cond_0

    return-void

    .line 752
    :cond_0
    if-eqz p6, :cond_1

    .line 753
    invoke-virtual {p1}, Lcom/goudong/jd/ui/projects/KugouRushFragment$AccountTierState;->getSelectedCoins()Ljava/util/Set;

    move-result-object p5

    invoke-virtual {p2}, Lcom/goudong/jd/data/model/KugouLevel;->getCoins()I

    move-result v0

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-interface {p5, v0}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 754
    invoke-virtual {p2}, Lcom/goudong/jd/data/model/KugouLevel;->getCoins()I

    move-result p5

    invoke-direct {p3, p4, p5}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->trimAccountCoins(Ljava/lang/String;I)V

    goto :goto_0

    .line 756
    :cond_1
    invoke-virtual {p1}, Lcom/goudong/jd/ui/projects/KugouRushFragment$AccountTierState;->getSelectedCoins()Ljava/util/Set;

    move-result-object p5

    invoke-virtual {p2}, Lcom/goudong/jd/data/model/KugouLevel;->getCoins()I

    move-result v0

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-interface {p5, v0}, Ljava/util/Set;->remove(Ljava/lang/Object;)Z

    .line 758
    :goto_0
    return-void
.end method

.method private final renderServerLogs(Ljava/util/List;Z)V
    .locals 12
    .param p1, "logs"    # Ljava/util/List;
    .param p2, "scrollToEnd"    # Z
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/goudong/jd/data/model/KuwoTaskLog;",
            ">;Z)V"
        }
    .end annotation

    .line 1170
    move-object v0, p1

    check-cast v0, Ljava/util/Collection;

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-eqz v0, :cond_1

    invoke-interface {v0}, Ljava/util/Collection;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_0

    goto :goto_0

    :cond_0
    move v0, v1

    goto :goto_1

    :cond_1
    :goto_0
    move v0, v2

    :goto_1
    if-eqz v0, :cond_2

    return-void

    .line 1171
    :cond_2
    if-eqz p2, :cond_4

    iget-object v0, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->logScroll:Lcom/goudong/jd/ui/common/TaskLogScrollView;

    if-eqz v0, :cond_3

    invoke-virtual {v0}, Lcom/goudong/jd/ui/common/TaskLogScrollView;->getFollowTail()Z

    move-result v0

    if-nez v0, :cond_3

    move v0, v2

    goto :goto_2

    :cond_3
    move v0, v1

    :goto_2
    if-nez v0, :cond_4

    move v1, v2

    :cond_4
    move v0, v1

    .line 1172
    .local v0, "follow":Z
    move-object v3, p1

    check-cast v3, Ljava/lang/Iterable;

    const-string v1, "\n"

    move-object v4, v1

    check-cast v4, Ljava/lang/CharSequence;

    new-instance v1, Lcom/goudong/jd/ui/projects/KugouRushFragment$renderServerLogs$text$1;

    invoke-direct {v1, p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment$renderServerLogs$text$1;-><init>(Lcom/goudong/jd/ui/projects/KugouRushFragment;)V

    move-object v9, v1

    check-cast v9, Lkotlin/jvm/functions/Function1;

    const/16 v10, 0x1e

    const/4 v11, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-static/range {v3 .. v11}, Lkotlin/collections/CollectionsKt;->joinToString$default(Ljava/lang/Iterable;Ljava/lang/CharSequence;Ljava/lang/CharSequence;Ljava/lang/CharSequence;ILjava/lang/CharSequence;Lkotlin/jvm/functions/Function1;ILjava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    .line 1173
    .local v1, "text":Ljava/lang/String;
    iget-object v3, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->logText:Landroid/widget/TextView;

    if-nez v3, :cond_5

    goto :goto_3

    :cond_5
    move-object v4, v1

    check-cast v4, Ljava/lang/CharSequence;

    invoke-virtual {v3, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1174
    :goto_3
    invoke-direct {p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->prefs()Landroid/content/SharedPreferences;

    move-result-object v3

    invoke-interface {v3}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v3

    const-string v4, "log"

    invoke-interface {v3, v4, v1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v3

    invoke-interface {v3}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 1175
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v3

    iput v3, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->taskLogIndex:I

    .line 1176
    if-eqz v0, :cond_6

    iget-object v3, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->logScroll:Lcom/goudong/jd/ui/common/TaskLogScrollView;

    if-eqz v3, :cond_6

    invoke-static {v3, v2}, Lcom/goudong/jd/ui/common/UiKitKt;->scrollTaskLogToBottom(Lcom/goudong/jd/ui/common/TaskLogScrollView;Z)V

    .line 1177
    :cond_6
    return-void
.end method

.method static synthetic renderServerLogs$default(Lcom/goudong/jd/ui/projects/KugouRushFragment;Ljava/util/List;ZILjava/lang/Object;)V
    .locals 0

    .line 1169
    and-int/lit8 p3, p3, 0x2

    if-eqz p3, :cond_0

    const/4 p2, 0x1

    :cond_0
    invoke-direct {p0, p1, p2}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->renderServerLogs(Ljava/util/List;Z)V

    return-void
.end method

.method private final renderTaskLog(Lcom/goudong/jd/data/model/KuwoTaskLog;)V
    .locals 1
    .param p1, "entry"    # Lcom/goudong/jd/data/model/KuwoTaskLog;

    .line 1180
    invoke-direct {p0, p1}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->formatTaskLogLine(Lcom/goudong/jd/data/model/KuwoTaskLog;)Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->appendLog(Ljava/lang/String;)V

    .line 1181
    return-void
.end method

.method private final restoreLogs()V
    .locals 4

    .line 1153
    iget-object v0, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->logText:Landroid/widget/TextView;

    if-nez v0, :cond_0

    goto :goto_1

    :cond_0
    invoke-direct {p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->prefs()Landroid/content/SharedPreferences;

    move-result-object v1

    const-string v2, "log"

    const-string v3, ""

    invoke-interface {v1, v2, v3}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    if-eqz v1, :cond_1

    check-cast v1, Ljava/lang/CharSequence;

    goto :goto_0

    :cond_1
    move-object v1, v3

    check-cast v1, Ljava/lang/CharSequence;

    :goto_0
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1154
    :goto_1
    iget-object v0, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->logScroll:Lcom/goudong/jd/ui/common/TaskLogScrollView;

    if-eqz v0, :cond_2

    const/4 v1, 0x1

    invoke-static {v0, v1}, Lcom/goudong/jd/ui/common/UiKitKt;->scrollTaskLogToBottom(Lcom/goudong/jd/ui/common/TaskLogScrollView;Z)V

    .line 1155
    :cond_2
    return-void
.end method

.method private final restoreState()V
    .locals 7

    .line 1238
    iget-boolean v0, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->followLiveLogs:Z

    if-nez v0, :cond_0

    return-void

    .line 1239
    :cond_0
    invoke-virtual {p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->getViewLifecycleOwner()Landroidx/lifecycle/LifecycleOwner;

    move-result-object v0

    const-string v1, "getViewLifecycleOwner(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v0}, Landroidx/lifecycle/LifecycleOwnerKt;->getLifecycleScope(Landroidx/lifecycle/LifecycleOwner;)Landroidx/lifecycle/LifecycleCoroutineScope;

    move-result-object v0

    move-object v1, v0

    check-cast v1, Lkotlinx/coroutines/CoroutineScope;

    new-instance v0, Lcom/goudong/jd/ui/projects/KugouRushFragment$restoreState$1;

    const/4 v2, 0x0

    invoke-direct {v0, p0, v2}, Lcom/goudong/jd/ui/projects/KugouRushFragment$restoreState$1;-><init>(Lcom/goudong/jd/ui/projects/KugouRushFragment;Lkotlin/coroutines/Continuation;)V

    move-object v4, v0

    check-cast v4, Lkotlin/jvm/functions/Function2;

    const/4 v5, 0x3

    const/4 v6, 0x0

    const/4 v3, 0x0

    invoke-static/range {v1 .. v6}, Lkotlinx/coroutines/BuildersKt;->launch$default(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/CoroutineContext;Lkotlinx/coroutines/CoroutineStart;Lkotlin/jvm/functions/Function2;ILjava/lang/Object;)Lkotlinx/coroutines/Job;

    .line 1250
    return-void
.end method

.method private final restoreWithdrawUi()V
    .locals 3

    .line 1142
    const/4 v0, 0x0

    iput-object v0, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->activeTaskId:Ljava/lang/String;

    .line 1143
    iget-object v1, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->monitorJob:Lkotlinx/coroutines/Job;

    const/4 v2, 0x1

    if-eqz v1, :cond_0

    invoke-static {v1, v0, v2, v0}, Lkotlinx/coroutines/Job$DefaultImpls;->cancel$default(Lkotlinx/coroutines/Job;Ljava/util/concurrent/CancellationException;ILjava/lang/Object;)V

    .line 1144
    :cond_0
    iget-object v1, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->countdownJob:Lkotlinx/coroutines/Job;

    if-eqz v1, :cond_1

    invoke-static {v1, v0, v2, v0}, Lkotlinx/coroutines/Job$DefaultImpls;->cancel$default(Lkotlinx/coroutines/Job;Ljava/util/concurrent/CancellationException;ILjava/lang/Object;)V

    .line 1145
    :cond_1
    iget-object v0, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->countdownText:Landroid/widget/TextView;

    if-nez v0, :cond_2

    goto :goto_0

    :cond_2
    const/16 v1, 0x8

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setVisibility(I)V

    .line 1146
    :goto_0
    iget-object v0, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->withdrawBtn:Landroid/widget/TextView;

    const/4 v1, 0x0

    if-nez v0, :cond_3

    goto :goto_1

    :cond_3
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setVisibility(I)V

    .line 1147
    :goto_1
    invoke-direct {p0, v1}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->setWithdrawUiLocked(Z)V

    .line 1148
    invoke-direct {p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->syncStartButton()V

    .line 1149
    invoke-direct {p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->clearState()V

    .line 1150
    return-void
.end method

.method private final runCountdown(Lcom/goudong/jd/ui/projects/KugouTimeHelper$NextWithdrawInfo;Ljava/lang/String;)V
    .locals 11
    .param p1, "info"    # Lcom/goudong/jd/ui/projects/KugouTimeHelper$NextWithdrawInfo;
    .param p2, "taskId"    # Ljava/lang/String;

    .line 1103
    iget-object v0, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->countdownJob:Lkotlinx/coroutines/Job;

    if-eqz v0, :cond_0

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-static {v0, v2, v1, v2}, Lkotlinx/coroutines/Job$DefaultImpls;->cancel$default(Lkotlinx/coroutines/Job;Ljava/util/concurrent/CancellationException;ILjava/lang/Object;)V

    .line 1104
    :cond_0
    sget-object v0, Lcom/goudong/jd/ui/projects/KugouTimeHelper;->INSTANCE:Lcom/goudong/jd/ui/projects/KugouTimeHelper;

    invoke-virtual {p1}, Lcom/goudong/jd/ui/projects/KugouTimeHelper$NextWithdrawInfo;->getHour()I

    move-result v1

    invoke-virtual {v0, v1}, Lcom/goudong/jd/ui/projects/KugouTimeHelper;->formatHour(I)Ljava/lang/String;

    move-result-object v0

    .line 1105
    .local v0, "targetLabel":Ljava/lang/String;
    iget-object v1, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->countdownText:Landroid/widget/TextView;

    if-nez v1, :cond_1

    goto :goto_0

    :cond_1
    const/4 v2, 0x0

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setVisibility(I)V

    .line 1106
    :goto_0
    iget-object v1, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->withdrawBtn:Landroid/widget/TextView;

    if-nez v1, :cond_2

    goto :goto_1

    :cond_2
    const/16 v2, 0x8

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setVisibility(I)V

    .line 1107
    :goto_1
    new-instance v4, Lkotlin/jvm/internal/Ref$BooleanRef;

    invoke-direct {v4}, Lkotlin/jvm/internal/Ref$BooleanRef;-><init>()V

    .line 1108
    .local v4, "fired":Lkotlin/jvm/internal/Ref$BooleanRef;
    invoke-virtual {p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->getViewLifecycleOwner()Landroidx/lifecycle/LifecycleOwner;

    move-result-object v1

    const-string v2, "getViewLifecycleOwner(...)"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v1}, Landroidx/lifecycle/LifecycleOwnerKt;->getLifecycleScope(Landroidx/lifecycle/LifecycleOwner;)Landroidx/lifecycle/LifecycleCoroutineScope;

    move-result-object v1

    check-cast v1, Lkotlinx/coroutines/CoroutineScope;

    new-instance v9, Lcom/goudong/jd/ui/projects/KugouRushFragment$runCountdown$1;

    const/4 v8, 0x0

    move-object v2, v9

    move-object v3, p1

    move-object v5, p0

    move-object v6, v0

    move-object v7, p2

    invoke-direct/range {v2 .. v8}, Lcom/goudong/jd/ui/projects/KugouRushFragment$runCountdown$1;-><init>(Lcom/goudong/jd/ui/projects/KugouTimeHelper$NextWithdrawInfo;Lkotlin/jvm/internal/Ref$BooleanRef;Lcom/goudong/jd/ui/projects/KugouRushFragment;Ljava/lang/String;Ljava/lang/String;Lkotlin/coroutines/Continuation;)V

    move-object v8, v9

    check-cast v8, Lkotlin/jvm/functions/Function2;

    const/4 v9, 0x3

    const/4 v10, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    move-object v5, v1

    invoke-static/range {v5 .. v10}, Lkotlinx/coroutines/BuildersKt;->launch$default(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/CoroutineContext;Lkotlinx/coroutines/CoroutineStart;Lkotlin/jvm/functions/Function2;ILjava/lang/Object;)Lkotlinx/coroutines/Job;

    move-result-object v1

    iput-object v1, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->countdownJob:Lkotlinx/coroutines/Job;

    .line 1134
    return-void
.end method

.method private static final rushModeSwitchListener$lambda$53(Lcom/goudong/jd/ui/projects/KugouRushFragment;Landroid/widget/CompoundButton;Z)V
    .locals 7
    .param p0, "this$0"    # Lcom/goudong/jd/ui/projects/KugouRushFragment;
    .param p2, "checked"    # Z

    const-string v0, "this$0"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "<anonymous parameter 0>"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 548
    iget-boolean p1, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->rushModeSwitchUpdating:Z

    if-nez p1, :cond_2

    invoke-direct {p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->canChooseRushMode()Z

    move-result p1

    if-nez p1, :cond_0

    goto :goto_1

    .line 549
    :cond_0
    if-eqz p2, :cond_1

    const-string p1, "auto"

    goto :goto_0

    :cond_1
    const-string p1, "manual"

    .line 550
    .local p1, "mode":Ljava/lang/String;
    :goto_0
    invoke-virtual {p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->getViewLifecycleOwner()Landroidx/lifecycle/LifecycleOwner;

    move-result-object v0

    const-string v1, "getViewLifecycleOwner(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v0}, Landroidx/lifecycle/LifecycleOwnerKt;->getLifecycleScope(Landroidx/lifecycle/LifecycleOwner;)Landroidx/lifecycle/LifecycleCoroutineScope;

    move-result-object v0

    move-object v1, v0

    check-cast v1, Lkotlinx/coroutines/CoroutineScope;

    new-instance v0, Lcom/goudong/jd/ui/projects/KugouRushFragment$rushModeSwitchListener$1$1;

    const/4 v2, 0x0

    invoke-direct {v0, p1, p0, p2, v2}, Lcom/goudong/jd/ui/projects/KugouRushFragment$rushModeSwitchListener$1$1;-><init>(Ljava/lang/String;Lcom/goudong/jd/ui/projects/KugouRushFragment;ZLkotlin/coroutines/Continuation;)V

    move-object v4, v0

    check-cast v4, Lkotlin/jvm/functions/Function2;

    const/4 v5, 0x3

    const/4 v6, 0x0

    const/4 v3, 0x0

    invoke-static/range {v1 .. v6}, Lkotlinx/coroutines/BuildersKt;->launch$default(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/CoroutineContext;Lkotlinx/coroutines/CoroutineStart;Lkotlin/jvm/functions/Function2;ILjava/lang/Object;)Lkotlinx/coroutines/Job;

    .line 563
    return-void

    .line 548
    .end local p1    # "mode":Ljava/lang/String;
    :cond_2
    :goto_1
    return-void
.end method

.method private final saveLastTaskId(Ljava/lang/String;)V
    .locals 2
    .param p1, "id"    # Ljava/lang/String;

    .line 1221
    invoke-direct {p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->prefs()Landroid/content/SharedPreferences;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const-string v1, "last_task_id"

    invoke-interface {v0, v1, p1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    return-void
.end method

.method private final saveState(Ljava/lang/String;IZZ)V
    .locals 3
    .param p1, "taskId"    # Ljava/lang/String;
    .param p2, "targetHour"    # I
    .param p3, "immediate"    # Z
    .param p4, "useProxy"    # Z

    .line 1224
    invoke-direct {p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->prefs()Landroid/content/SharedPreferences;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    .line 1225
    nop

    .line 1226
    new-instance v1, Lorg/json/JSONObject;

    invoke-direct {v1}, Lorg/json/JSONObject;-><init>()V

    .line 1227
    const-string v2, "taskId"

    invoke-virtual {v1, v2, p1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v1

    .line 1228
    const-string v2, "targetHour"

    invoke-virtual {v1, v2, p2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    move-result-object v1

    .line 1229
    const-string v2, "immediate"

    invoke-virtual {v1, v2, p3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Z)Lorg/json/JSONObject;

    move-result-object v1

    .line 1230
    const-string v2, "useProxy"

    invoke-virtual {v1, v2, p4}, Lorg/json/JSONObject;->put(Ljava/lang/String;Z)Lorg/json/JSONObject;

    move-result-object v1

    .line 1231
    invoke-virtual {v1}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v1

    .line 1224
    const-string v2, "state"

    invoke-interface {v0, v2, v1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    .line 1232
    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 1233
    return-void
.end method

.method private final selectedAccounts()Ljava/util/List;
    .locals 11
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/goudong/jd/data/model/KugouAccount;",
            ">;"
        }
    .end annotation

    .line 848
    iget-object v0, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->accounts:Ljava/util/List;

    check-cast v0, Ljava/lang/Iterable;

    .local v0, "$this$filter$iv":Ljava/lang/Iterable;
    const/4 v1, 0x0

    .line 1352
    .local v1, "$i$f$filter":I
    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    check-cast v2, Ljava/util/Collection;

    .local v2, "destination$iv$iv":Ljava/util/Collection;
    move-object v3, v0

    .local v3, "$this$filterTo$iv$iv":Ljava/lang/Iterable;
    const/4 v4, 0x0

    .line 1353
    .local v4, "$i$f$filterTo":I
    invoke-interface {v3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :cond_0
    :goto_0
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_1

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    .local v6, "element$iv$iv":Ljava/lang/Object;
    move-object v7, v6

    check-cast v7, Lcom/goudong/jd/data/model/KugouAccount;

    .local v7, "it":Lcom/goudong/jd/data/model/KugouAccount;
    const/4 v8, 0x0

    .line 848
    .local v8, "$i$a$-filter-KugouRushFragment$selectedAccounts$1":I
    iget-object v9, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->selectedUserIds:Ljava/util/LinkedHashSet;

    check-cast v9, Ljava/lang/Iterable;

    invoke-virtual {v7}, Lcom/goudong/jd/data/model/KugouAccount;->getUserid()Ljava/lang/String;

    move-result-object v10

    invoke-static {v9, v10}, Lkotlin/collections/CollectionsKt;->contains(Ljava/lang/Iterable;Ljava/lang/Object;)Z

    move-result v7

    .line 1353
    .end local v7    # "it":Lcom/goudong/jd/data/model/KugouAccount;
    .end local v8    # "$i$a$-filter-KugouRushFragment$selectedAccounts$1":I
    if-eqz v7, :cond_0

    invoke-interface {v2, v6}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_0

    .line 1354
    .end local v6    # "element$iv$iv":Ljava/lang/Object;
    :cond_1
    nop

    .end local v2    # "destination$iv$iv":Ljava/util/Collection;
    .end local v3    # "$this$filterTo$iv$iv":Ljava/lang/Iterable;
    .end local v4    # "$i$f$filterTo":I
    check-cast v2, Ljava/util/List;

    .line 1352
    nop

    .line 848
    .end local v0    # "$this$filter$iv":Ljava/lang/Iterable;
    .end local v1    # "$i$f$filter":I
    return-object v2
.end method

.method private final setWithdrawUiLocked(Z)V
    .locals 3
    .param p1, "locked"    # Z

    .line 1137
    iget-object v0, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->withdrawBtn:Landroid/widget/TextView;

    if-nez v0, :cond_0

    goto :goto_1

    :cond_0
    const/4 v1, 0x0

    if-eqz p1, :cond_2

    iget-object v2, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->countdownText:Landroid/widget/TextView;

    if-eqz v2, :cond_1

    invoke-virtual {v2}, Landroid/widget/TextView;->getVisibility()I

    move-result v2

    if-nez v2, :cond_1

    const/4 v2, 0x1

    goto :goto_0

    :cond_1
    move v2, v1

    :goto_0
    if-eqz v2, :cond_2

    const/16 v1, 0x8

    :cond_2
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setVisibility(I)V

    .line 1138
    :goto_1
    iget-object v0, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->loadLevelsBtn:Landroid/widget/TextView;

    if-nez v0, :cond_3

    goto :goto_2

    :cond_3
    xor-int/lit8 v1, p1, 0x1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setEnabled(Z)V

    .line 1139
    :goto_2
    return-void
.end method

.method private final startWithdraw()V
    .locals 25

    .line 924
    move-object/from16 v7, p0

    iget-object v0, v7, Lcom/goudong/jd/ui/projects/KugouRushFragment;->portalConfig:Lcom/goudong/jd/data/model/KugouPortalConfig;

    if-nez v0, :cond_0

    .line 925
    move-object v0, v7

    check-cast v0, Landroidx/fragment/app/Fragment;

    const-string v1, "\u62a2\u5151\u914d\u7f6e\u672a\u5c31\u7eea\uff0c\u8bf7\u4e0b\u62c9\u5237\u65b0\u6216\u68c0\u67e5\u7f51\u7edc"

    invoke-static {v0, v1}, Lcom/goudong/jd/ui/common/UiKitKt;->toast(Landroidx/fragment/app/Fragment;Ljava/lang/String;)V

    .line 926
    return-void

    .line 928
    :cond_0
    invoke-direct/range {p0 .. p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->isAutoRushMode()Z

    move-result v0

    if-eqz v0, :cond_1

    .line 929
    move-object v0, v7

    check-cast v0, Landroidx/fragment/app/Fragment;

    const-string v1, "\u5f53\u524d\u4e3a\u81ea\u52a8\u62a2\u5151\u6a21\u5f0f\uff0c\u6574\u70b9\u7531\u7cfb\u7edf\u81ea\u52a8\u6267\u884c"

    invoke-static {v0, v1}, Lcom/goudong/jd/ui/common/UiKitKt;->toast(Landroidx/fragment/app/Fragment;Ljava/lang/String;)V

    .line 930
    return-void

    .line 932
    :cond_1
    iget-boolean v0, v7, Lcom/goudong/jd/ui/projects/KugouRushFragment;->authorized:Z

    if-nez v0, :cond_3

    .line 933
    move-object v0, v7

    check-cast v0, Landroidx/fragment/app/Fragment;

    invoke-direct/range {p0 .. p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->getRushProduct()Ljava/lang/String;

    move-result-object v1

    const-string v2, "std"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_2

    const-string v1, "\u8bf7\u5148\u4e0a\u8f66\u9177\u72d7\u666e\u901a\u7248\uff08KG_RW\uff09"

    goto :goto_0

    :cond_2
    const-string v1, "\u8bf7\u5148\u4e0a\u8f66\u9177\u72d7\u6982\u5ff5\u7248\uff08KGGNB\uff09"

    :goto_0
    invoke-static {v0, v1}, Lcom/goudong/jd/ui/common/UiKitKt;->toast(Landroidx/fragment/app/Fragment;Ljava/lang/String;)V

    .line 934
    return-void

    .line 936
    :cond_3
    iget-boolean v0, v7, Lcom/goudong/jd/ui/projects/KugouRushFragment;->withdrawSubmitting:Z

    if-eqz v0, :cond_4

    return-void

    .line 937
    :cond_4
    invoke-direct/range {p0 .. p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->selectedAccounts()Ljava/util/List;

    move-result-object v8

    .line 938
    .local v8, "picked":Ljava/util/List;
    invoke-interface {v8}, Ljava/util/List;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_5

    .line 939
    move-object v0, v7

    check-cast v0, Landroidx/fragment/app/Fragment;

    const-string v1, "\u8bf7\u81f3\u5c11\u9009\u62e9\u4e00\u4e2a\u8d26\u53f7"

    invoke-static {v0, v1}, Lcom/goudong/jd/ui/common/UiKitKt;->toast(Landroidx/fragment/app/Fragment;Ljava/lang/String;)V

    .line 940
    return-void

    .line 942
    :cond_5
    move-object v0, v8

    check-cast v0, Ljava/lang/Iterable;

    .local v0, "$this$filter$iv":Ljava/lang/Iterable;
    const/4 v1, 0x0

    .line 1378
    .local v1, "$i$f$filter":I
    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    check-cast v2, Ljava/util/Collection;

    .local v2, "destination$iv$iv":Ljava/util/Collection;
    move-object v3, v0

    .local v3, "$this$filterTo$iv$iv":Ljava/lang/Iterable;
    const/4 v4, 0x0

    .line 1379
    .local v4, "$i$f$filterTo":I
    invoke-interface {v3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :cond_6
    :goto_1
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_8

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    .local v6, "element$iv$iv":Ljava/lang/Object;
    move-object v9, v6

    check-cast v9, Lcom/goudong/jd/data/model/KugouAccount;

    .local v9, "it":Lcom/goudong/jd/data/model/KugouAccount;
    const/4 v10, 0x0

    .line 942
    .local v10, "$i$a$-filter-KugouRushFragment$startWithdraw$missing$1":I
    invoke-virtual {v9}, Lcom/goudong/jd/data/model/KugouAccount;->getUserid()Ljava/lang/String;

    move-result-object v11

    if-nez v11, :cond_7

    const-string v11, ""

    :cond_7
    invoke-direct {v7, v11}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->coinsFor(Ljava/lang/String;)Ljava/util/List;

    move-result-object v11

    invoke-interface {v11}, Ljava/util/List;->isEmpty()Z

    move-result v9

    .line 1379
    .end local v9    # "it":Lcom/goudong/jd/data/model/KugouAccount;
    .end local v10    # "$i$a$-filter-KugouRushFragment$startWithdraw$missing$1":I
    if-eqz v9, :cond_6

    invoke-interface {v2, v6}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_1

    .line 1380
    .end local v6    # "element$iv$iv":Ljava/lang/Object;
    :cond_8
    nop

    .end local v2    # "destination$iv$iv":Ljava/util/Collection;
    .end local v3    # "$this$filterTo$iv$iv":Ljava/lang/Iterable;
    .end local v4    # "$i$f$filterTo":I
    check-cast v2, Ljava/util/List;

    .line 1378
    nop

    .line 942
    .end local v0    # "$this$filter$iv":Ljava/lang/Iterable;
    .end local v1    # "$i$f$filter":I
    move-object v9, v2

    .line 943
    .local v9, "missing":Ljava/util/List;
    move-object v0, v9

    check-cast v0, Ljava/util/Collection;

    invoke-interface {v0}, Ljava/util/Collection;->isEmpty()Z

    move-result v0

    const/4 v1, 0x1

    xor-int/2addr v0, v1

    if-eqz v0, :cond_a

    .line 944
    move-object v10, v9

    check-cast v10, Ljava/lang/Iterable;

    const-string v0, "\u3001"

    move-object v11, v0

    check-cast v11, Ljava/lang/CharSequence;

    new-instance v0, Lcom/goudong/jd/ui/projects/KugouRushFragment$startWithdraw$names$1;

    invoke-direct {v0, v7}, Lcom/goudong/jd/ui/projects/KugouRushFragment$startWithdraw$names$1;-><init>(Lcom/goudong/jd/ui/projects/KugouRushFragment;)V

    move-object/from16 v16, v0

    check-cast v16, Lkotlin/jvm/functions/Function1;

    const/16 v17, 0x1e

    const/16 v18, 0x0

    const/4 v12, 0x0

    const/4 v13, 0x0

    const/4 v14, 0x0

    const/4 v15, 0x0

    invoke-static/range {v10 .. v18}, Lkotlin/collections/CollectionsKt;->joinToString$default(Ljava/lang/Iterable;Ljava/lang/CharSequence;Ljava/lang/CharSequence;Ljava/lang/CharSequence;ILjava/lang/CharSequence;Lkotlin/jvm/functions/Function1;ILjava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    .line 945
    .local v0, "names":Ljava/lang/String;
    move-object v1, v7

    check-cast v1, Landroidx/fragment/app/Fragment;

    iget-object v2, v7, Lcom/goudong/jd/ui/projects/KugouRushFragment;->tierByUser:Ljava/util/LinkedHashMap;

    invoke-virtual {v2}, Ljava/util/LinkedHashMap;->isEmpty()Z

    move-result v2

    if-eqz v2, :cond_9

    const-string v2, "\u8bf7\u5148\u8bfb\u53d6\u6863\u4f4d"

    goto :goto_2

    :cond_9
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "\u8bf7\u4e3a "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " \u9009\u62e9\u6863\u4f4d"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    :goto_2
    invoke-static {v1, v2}, Lcom/goudong/jd/ui/common/UiKitKt;->toast(Landroidx/fragment/app/Fragment;Ljava/lang/String;)V

    .line 946
    return-void

    .line 948
    .end local v0    # "names":Ljava/lang/String;
    :cond_a
    invoke-direct/range {p0 .. p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->withdrawPicks()Ljava/util/List;

    move-result-object v10

    .line 949
    .local v10, "picks":Ljava/util/List;
    invoke-interface {v10}, Ljava/util/List;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_b

    .line 950
    move-object v0, v7

    check-cast v0, Landroidx/fragment/app/Fragment;

    const-string v1, "\u8bf7\u81f3\u5c11\u4e3a\u4e00\u4e2a\u8d26\u53f7\u9009\u62e9\u6863\u4f4d"

    invoke-static {v0, v1}, Lcom/goudong/jd/ui/common/UiKitKt;->toast(Landroidx/fragment/app/Fragment;Ljava/lang/String;)V

    .line 951
    return-void

    .line 953
    :cond_b
    invoke-direct/range {p0 .. p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->maxLevelSelect()I

    move-result v11

    .line 954
    .local v11, "maxLv":I
    const/4 v0, 0x0

    if-lez v11, :cond_12

    move-object v2, v10

    check-cast v2, Ljava/lang/Iterable;

    .local v2, "$this$any$iv":Ljava/lang/Iterable;
    const/4 v3, 0x0

    .line 1381
    .local v3, "$i$f$any":I
    instance-of v4, v2, Ljava/util/Collection;

    if-eqz v4, :cond_c

    move-object v4, v2

    check-cast v4, Ljava/util/Collection;

    invoke-interface {v4}, Ljava/util/Collection;->isEmpty()Z

    move-result v4

    if-eqz v4, :cond_c

    move v2, v0

    goto :goto_6

    .line 1382
    :cond_c
    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :cond_d
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_11

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    .local v5, "element$iv":Ljava/lang/Object;
    move-object v6, v5

    check-cast v6, Ljava/util/Map;

    .local v6, "it":Ljava/util/Map;
    const/4 v12, 0x0

    .line 954
    .local v12, "$i$a$-any-KugouRushFragment$startWithdraw$1":I
    const-string v13, "coins"

    invoke-interface {v6, v13}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v13

    instance-of v14, v13, Ljava/util/List;

    if-eqz v14, :cond_e

    check-cast v13, Ljava/util/List;

    goto :goto_3

    :cond_e
    const/4 v13, 0x0

    :goto_3
    if-eqz v13, :cond_f

    invoke-interface {v13}, Ljava/util/List;->size()I

    move-result v13

    goto :goto_4

    :cond_f
    move v13, v0

    :goto_4
    if-le v13, v11, :cond_10

    move v6, v1

    goto :goto_5

    :cond_10
    move v6, v0

    .line 1382
    .end local v6    # "it":Ljava/util/Map;
    .end local v12    # "$i$a$-any-KugouRushFragment$startWithdraw$1":I
    :goto_5
    if-eqz v6, :cond_d

    move v2, v1

    goto :goto_6

    .line 1383
    .end local v5    # "element$iv":Ljava/lang/Object;
    :cond_11
    move v2, v0

    .line 954
    .end local v2    # "$this$any$iv":Ljava/lang/Iterable;
    .end local v3    # "$i$f$any":I
    :goto_6
    if-eqz v2, :cond_12

    .line 955
    move-object v0, v7

    check-cast v0, Landroidx/fragment/app/Fragment;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "\u6bcf\u4e2a\u8d26\u53f7\u6700\u591a\u9009\u62e9 "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v11}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " \u4e2a\u6863\u4f4d"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/goudong/jd/ui/common/UiKitKt;->toast(Landroidx/fragment/app/Fragment;Ljava/lang/String;)V

    .line 956
    return-void

    .line 958
    :cond_12
    invoke-direct/range {p0 .. p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->preOpenMin()I

    move-result v12

    .line 959
    .local v12, "openMin":I
    invoke-direct/range {p0 .. p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->isDebugRush()Z

    move-result v2

    if-nez v2, :cond_13

    sget-object v2, Lcom/goudong/jd/ui/projects/KugouTimeHelper;->INSTANCE:Lcom/goudong/jd/ui/projects/KugouTimeHelper;

    invoke-virtual {v2, v12}, Lcom/goudong/jd/ui/projects/KugouTimeHelper;->canStartNow(I)Z

    move-result v2

    if-nez v2, :cond_13

    .line 960
    move-object v0, v7

    check-cast v0, Landroidx/fragment/app/Fragment;

    sget-object v1, Lcom/goudong/jd/ui/projects/KugouTimeHelper;->INSTANCE:Lcom/goudong/jd/ui/projects/KugouTimeHelper;

    invoke-virtual {v1, v12}, Lcom/goudong/jd/ui/projects/KugouTimeHelper;->preOpenHint(I)Ljava/lang/String;

    move-result-object v1

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "\u672a\u5230\u62a2\u5151\u65f6\u95f4\uff0c\u8bf7\u5728\u6574\u70b9\u524d "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "\u5185\u518d\u6765"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/goudong/jd/ui/common/UiKitKt;->toast(Landroidx/fragment/app/Fragment;Ljava/lang/String;)V

    .line 961
    return-void

    .line 963
    :cond_13
    sget-object v2, Lcom/goudong/jd/ui/projects/KugouTimeHelper;->INSTANCE:Lcom/goudong/jd/ui/projects/KugouTimeHelper;

    invoke-virtual {v2, v12}, Lcom/goudong/jd/ui/projects/KugouTimeHelper;->getNextWithdrawInfo(I)Lcom/goudong/jd/ui/projects/KugouTimeHelper$NextWithdrawInfo;

    move-result-object v13

    .line 964
    .local v13, "info":Lcom/goudong/jd/ui/projects/KugouTimeHelper$NextWithdrawInfo;
    invoke-direct/range {p0 .. p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->isDebugRush()Z

    move-result v2

    if-nez v2, :cond_15

    invoke-virtual {v13}, Lcom/goudong/jd/ui/projects/KugouTimeHelper$NextWithdrawInfo;->getDiffMin()I

    move-result v2

    if-nez v2, :cond_14

    goto :goto_7

    :cond_14
    move v2, v0

    goto :goto_8

    :cond_15
    :goto_7
    move v2, v1

    :goto_8
    move v14, v2

    .line 965
    .local v14, "immediate":Z
    iget-object v2, v7, Lcom/goudong/jd/ui/projects/KugouRushFragment;->useProxyCheck:Landroid/widget/CheckBox;

    if-eqz v2, :cond_16

    invoke-virtual {v2}, Landroid/widget/CheckBox;->isChecked()Z

    move-result v2

    if-ne v2, v1, :cond_16

    move v2, v1

    goto :goto_9

    :cond_16
    move v2, v0

    :goto_9
    move v15, v2

    .line 966
    .local v15, "useProxy":Z
    invoke-direct/range {p0 .. p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->prefs()Landroid/content/SharedPreferences;

    move-result-object v2

    invoke-interface {v2}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    const-string v3, "use_proxy"

    invoke-interface {v2, v3, v15}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    invoke-interface {v2}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 967
    iput-boolean v1, v7, Lcom/goudong/jd/ui/projects/KugouRushFragment;->followLiveLogs:Z

    .line 968
    iput v0, v7, Lcom/goudong/jd/ui/projects/KugouRushFragment;->taskLogIndex:I

    .line 969
    iget-object v2, v7, Lcom/goudong/jd/ui/projects/KugouRushFragment;->sessionSpinner:Landroid/widget/Spinner;

    if-eqz v2, :cond_17

    .local v2, "sp":Landroid/widget/Spinner;
    const/4 v3, 0x0

    .line 970
    .local v3, "$i$a$-let-KugouRushFragment$startWithdraw$2":I
    iput-boolean v1, v7, Lcom/goudong/jd/ui/projects/KugouRushFragment;->sessionSpinnerProgrammatic:Z

    .line 971
    invoke-virtual {v2, v0, v0}, Landroid/widget/Spinner;->setSelection(IZ)V

    .line 972
    iput-boolean v0, v7, Lcom/goudong/jd/ui/projects/KugouRushFragment;->sessionSpinnerProgrammatic:Z

    .line 973
    nop

    .line 969
    .end local v2    # "sp":Landroid/widget/Spinner;
    .end local v3    # "$i$a$-let-KugouRushFragment$startWithdraw$2":I
    nop

    .line 974
    :cond_17
    iput-boolean v1, v7, Lcom/goudong/jd/ui/projects/KugouRushFragment;->withdrawSubmitting:Z

    .line 975
    invoke-direct {v7, v1}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->setWithdrawUiLocked(Z)V

    .line 976
    move-object/from16 v16, v10

    check-cast v16, Ljava/lang/Iterable;

    const-string v0, "\uff1b"

    move-object/from16 v17, v0

    check-cast v17, Ljava/lang/CharSequence;

    new-instance v0, Lcom/goudong/jd/ui/projects/KugouRushFragment$startWithdraw$summary$1;

    invoke-direct {v0, v7}, Lcom/goudong/jd/ui/projects/KugouRushFragment$startWithdraw$summary$1;-><init>(Lcom/goudong/jd/ui/projects/KugouRushFragment;)V

    move-object/from16 v22, v0

    check-cast v22, Lkotlin/jvm/functions/Function1;

    const/16 v23, 0x1e

    const/16 v24, 0x0

    const/16 v18, 0x0

    const/16 v19, 0x0

    const/16 v20, 0x0

    const/16 v21, 0x0

    invoke-static/range {v16 .. v24}, Lkotlin/collections/CollectionsKt;->joinToString$default(Ljava/lang/Iterable;Ljava/lang/CharSequence;Ljava/lang/CharSequence;Ljava/lang/CharSequence;ILjava/lang/CharSequence;Lkotlin/jvm/functions/Function1;ILjava/lang/Object;)Ljava/lang/String;

    move-result-object v6

    .line 982
    .local v6, "summary":Ljava/lang/String;
    nop

    .line 983
    if-eqz v14, :cond_18

    const-string v0, "\u26a1 \u7acb\u5373\u5f00\u62a2"

    goto :goto_a

    :cond_18
    sget-object v0, Lcom/goudong/jd/ui/projects/KugouTimeHelper;->INSTANCE:Lcom/goudong/jd/ui/projects/KugouTimeHelper;

    invoke-virtual {v13}, Lcom/goudong/jd/ui/projects/KugouTimeHelper$NextWithdrawInfo;->getHour()I

    move-result v1

    invoke-virtual {v0, v1}, Lcom/goudong/jd/ui/projects/KugouTimeHelper;->formatHour(I)Ljava/lang/String;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "\ud83c\udfaf \u5012\u8ba1\u65f6\u5230 "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, " \u5f00\u62a2"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 984
    :goto_a
    nop

    .line 985
    if-eqz v15, :cond_19

    const-string v1, "\uff0c\u8d70\u4ee3\u7406"

    goto :goto_b

    :cond_19
    const-string v1, "\uff0c\u76f4\u8fde"

    :goto_b
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v2, "\uff0c"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 982
    invoke-direct {v7, v0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->appendLog(Ljava/lang/String;)V

    .line 987
    iget-object v0, v7, Lcom/goudong/jd/ui/projects/KugouRushFragment;->withdrawBtn:Landroid/widget/TextView;

    if-eqz v0, :cond_1a

    check-cast v0, Landroid/view/View;

    const-string v1, "\u5f00\u59cb\u62a2\u5151"

    const-string v2, "\u63d0\u4ea4\u4e2d..."

    invoke-static {v0, v1, v2}, Lcom/goudong/jd/ui/common/UiKitKt;->showBtnLoading(Landroid/view/View;Ljava/lang/String;Ljava/lang/String;)V

    .line 988
    :cond_1a
    invoke-virtual/range {p0 .. p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->getViewLifecycleOwner()Landroidx/lifecycle/LifecycleOwner;

    move-result-object v0

    const-string v1, "getViewLifecycleOwner(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v0}, Landroidx/lifecycle/LifecycleOwnerKt;->getLifecycleScope(Landroidx/lifecycle/LifecycleOwner;)Landroidx/lifecycle/LifecycleCoroutineScope;

    move-result-object v0

    move-object/from16 v16, v0

    check-cast v16, Lkotlinx/coroutines/CoroutineScope;

    new-instance v17, Lcom/goudong/jd/ui/projects/KugouRushFragment$startWithdraw$3;

    const/16 v18, 0x0

    move-object/from16 v0, v17

    move-object v1, v10

    move v2, v15

    move-object/from16 v3, p0

    move-object v4, v13

    move v5, v14

    move-object/from16 v22, v6

    .end local v6    # "summary":Ljava/lang/String;
    .local v22, "summary":Ljava/lang/String;
    move-object/from16 v6, v18

    invoke-direct/range {v0 .. v6}, Lcom/goudong/jd/ui/projects/KugouRushFragment$startWithdraw$3;-><init>(Ljava/util/List;ZLcom/goudong/jd/ui/projects/KugouRushFragment;Lcom/goudong/jd/ui/projects/KugouTimeHelper$NextWithdrawInfo;ZLkotlin/coroutines/Continuation;)V

    move-object/from16 v19, v17

    check-cast v19, Lkotlin/jvm/functions/Function2;

    const/16 v20, 0x3

    const/16 v21, 0x0

    const/16 v17, 0x0

    invoke-static/range {v16 .. v21}, Lkotlinx/coroutines/BuildersKt;->launch$default(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/CoroutineContext;Lkotlinx/coroutines/CoroutineStart;Lkotlin/jvm/functions/Function2;ILjava/lang/Object;)Lkotlinx/coroutines/Job;

    .line 1024
    return-void
.end method

.method private final syncKugouPortalLogs()V
    .locals 7

    .line 1200
    iget-boolean v0, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->followLiveLogs:Z

    if-nez v0, :cond_0

    return-void

    .line 1201
    :cond_0
    invoke-virtual {p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->getViewLifecycleOwner()Landroidx/lifecycle/LifecycleOwner;

    move-result-object v0

    const-string v1, "getViewLifecycleOwner(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v0}, Landroidx/lifecycle/LifecycleOwnerKt;->getLifecycleScope(Landroidx/lifecycle/LifecycleOwner;)Landroidx/lifecycle/LifecycleCoroutineScope;

    move-result-object v0

    move-object v1, v0

    check-cast v1, Lkotlinx/coroutines/CoroutineScope;

    new-instance v0, Lcom/goudong/jd/ui/projects/KugouRushFragment$syncKugouPortalLogs$1;

    const/4 v2, 0x0

    invoke-direct {v0, p0, v2}, Lcom/goudong/jd/ui/projects/KugouRushFragment$syncKugouPortalLogs$1;-><init>(Lcom/goudong/jd/ui/projects/KugouRushFragment;Lkotlin/coroutines/Continuation;)V

    move-object v4, v0

    check-cast v4, Lkotlin/jvm/functions/Function2;

    const/4 v5, 0x3

    const/4 v6, 0x0

    const/4 v3, 0x0

    invoke-static/range {v1 .. v6}, Lkotlinx/coroutines/BuildersKt;->launch$default(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/CoroutineContext;Lkotlinx/coroutines/CoroutineStart;Lkotlin/jvm/functions/Function2;ILjava/lang/Object;)Lkotlinx/coroutines/Job;

    .line 1211
    return-void
.end method

.method private final syncStartButton()V
    .locals 4

    .line 906
    iget-object v0, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->withdrawBtn:Landroid/widget/TextView;

    if-nez v0, :cond_0

    return-void

    .line 907
    .local v0, "btn":Landroid/widget/TextView;
    :cond_0
    iget-object v1, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->activeTaskId:Ljava/lang/String;

    if-eqz v1, :cond_1

    return-void

    .line 908
    :cond_1
    iget-object v1, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->portalConfig:Lcom/goudong/jd/data/model/KugouPortalConfig;

    const v2, 0x3ee66666    # 0.45f

    const/4 v3, 0x0

    if-nez v1, :cond_2

    .line 909
    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setAlpha(F)V

    .line 910
    invoke-virtual {v0, v3}, Landroid/widget/TextView;->setEnabled(Z)V

    .line 911
    return-void

    .line 913
    :cond_2
    invoke-direct {p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->isAutoRushMode()Z

    move-result v1

    if-eqz v1, :cond_3

    .line 914
    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setAlpha(F)V

    .line 915
    invoke-virtual {v0, v3}, Landroid/widget/TextView;->setEnabled(Z)V

    .line 916
    return-void

    .line 918
    :cond_3
    iget-boolean v1, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->authorized:Z

    if-eqz v1, :cond_5

    invoke-direct {p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->isDebugRushMode()Z

    move-result v1

    if-nez v1, :cond_4

    sget-object v1, Lcom/goudong/jd/ui/projects/KugouTimeHelper;->INSTANCE:Lcom/goudong/jd/ui/projects/KugouTimeHelper;

    invoke-direct {p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->preOpenMin()I

    move-result v2

    invoke-virtual {v1, v2}, Lcom/goudong/jd/ui/projects/KugouTimeHelper;->canStartNow(I)Z

    move-result v1

    if-eqz v1, :cond_5

    :cond_4
    const/4 v3, 0x1

    :cond_5
    move v1, v3

    .line 919
    .local v1, "on":Z
    if-eqz v1, :cond_6

    const/high16 v2, 0x3f800000    # 1.0f

    goto :goto_0

    :cond_6
    const v2, 0x3ecccccd    # 0.4f

    :goto_0
    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setAlpha(F)V

    .line 920
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setEnabled(Z)V

    .line 921
    return-void
.end method

.method private final trimAccountCoins(Ljava/lang/String;I)V
    .locals 12
    .param p1, "uid"    # Ljava/lang/String;
    .param p2, "keep"    # I

    .line 836
    iget-object v0, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->tierByUser:Ljava/util/LinkedHashMap;

    invoke-virtual {v0, p1}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/goudong/jd/ui/projects/KugouRushFragment$AccountTierState;

    if-nez v0, :cond_0

    return-void

    .line 837
    .local v0, "state":Lcom/goudong/jd/ui/projects/KugouRushFragment$AccountTierState;
    :cond_0
    invoke-direct {p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->maxLevelSelect()I

    move-result v1

    .line 838
    .local v1, "maxLv":I
    if-lez v1, :cond_7

    invoke-virtual {v0}, Lcom/goudong/jd/ui/projects/KugouRushFragment$AccountTierState;->getSelectedCoins()Ljava/util/Set;

    move-result-object v2

    invoke-interface {v2}, Ljava/util/Set;->size()I

    move-result v2

    if-gt v2, v1, :cond_1

    goto/16 :goto_3

    .line 839
    :cond_1
    invoke-virtual {v0}, Lcom/goudong/jd/ui/projects/KugouRushFragment$AccountTierState;->getSelectedCoins()Ljava/util/Set;

    move-result-object v2

    check-cast v2, Ljava/lang/Iterable;

    .local v2, "$this$filter$iv":Ljava/lang/Iterable;
    const/4 v3, 0x0

    .line 1349
    .local v3, "$i$f$filter":I
    new-instance v4, Ljava/util/ArrayList;

    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    check-cast v4, Ljava/util/Collection;

    .local v4, "destination$iv$iv":Ljava/util/Collection;
    move-object v5, v2

    .local v5, "$this$filterTo$iv$iv":Ljava/lang/Iterable;
    const/4 v6, 0x0

    .line 1350
    .local v6, "$i$f$filterTo":I
    invoke-interface {v5}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v7

    :cond_2
    :goto_0
    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    move-result v8

    if-eqz v8, :cond_4

    invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v8

    .local v8, "element$iv$iv":Ljava/lang/Object;
    move-object v9, v8

    check-cast v9, Ljava/lang/Number;

    invoke-virtual {v9}, Ljava/lang/Number;->intValue()I

    move-result v9

    .local v9, "it":I
    const/4 v10, 0x0

    .line 839
    .local v10, "$i$a$-filter-KugouRushFragment$trimAccountCoins$drop$1":I
    if-eq v9, p2, :cond_3

    const/4 v11, 0x1

    goto :goto_1

    :cond_3
    const/4 v11, 0x0

    .line 1350
    .end local v9    # "it":I
    .end local v10    # "$i$a$-filter-KugouRushFragment$trimAccountCoins$drop$1":I
    :goto_1
    if-eqz v11, :cond_2

    invoke-interface {v4, v8}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_0

    .line 1351
    .end local v8    # "element$iv$iv":Ljava/lang/Object;
    :cond_4
    nop

    .end local v4    # "destination$iv$iv":Ljava/util/Collection;
    .end local v5    # "$this$filterTo$iv$iv":Ljava/lang/Iterable;
    .end local v6    # "$i$f$filterTo":I
    check-cast v4, Ljava/util/List;

    .line 1349
    nop

    .end local v2    # "$this$filter$iv":Ljava/lang/Iterable;
    .end local v3    # "$i$f$filter":I
    check-cast v4, Ljava/lang/Iterable;

    .line 839
    invoke-static {v4}, Lkotlin/collections/CollectionsKt;->sorted(Ljava/lang/Iterable;)Ljava/util/List;

    move-result-object v2

    .line 840
    .local v2, "drop":Ljava/util/List;
    invoke-interface {v2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :goto_2
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_5

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/Number;

    invoke-virtual {v4}, Ljava/lang/Number;->intValue()I

    move-result v4

    .line 841
    .local v4, "coins":I
    invoke-virtual {v0}, Lcom/goudong/jd/ui/projects/KugouRushFragment$AccountTierState;->getSelectedCoins()Ljava/util/Set;

    move-result-object v5

    invoke-interface {v5}, Ljava/util/Set;->size()I

    move-result v5

    if-le v5, v1, :cond_5

    .line 842
    invoke-virtual {v0}, Lcom/goudong/jd/ui/projects/KugouRushFragment$AccountTierState;->getSelectedCoins()Ljava/util/Set;

    move-result-object v5

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-interface {v5, v6}, Ljava/util/Set;->remove(Ljava/lang/Object;)Z

    goto :goto_2

    .line 844
    .end local v4    # "coins":I
    :cond_5
    iget-object v3, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->accountListWrap:Landroid/widget/LinearLayout;

    if-eqz v3, :cond_6

    new-instance v4, Lcom/goudong/jd/ui/projects/KugouRushFragment$$ExternalSyntheticLambda0;

    invoke-direct {v4, p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment$$ExternalSyntheticLambda0;-><init>(Lcom/goudong/jd/ui/projects/KugouRushFragment;)V

    invoke-virtual {v3, v4}, Landroid/widget/LinearLayout;->post(Ljava/lang/Runnable;)Z

    .line 845
    :cond_6
    return-void

    .line 838
    .end local v2    # "drop":Ljava/util/List;
    :cond_7
    :goto_3
    return-void
.end method

.method private static final trimAccountCoins$lambda$83(Lcom/goudong/jd/ui/projects/KugouRushFragment;)V
    .locals 1
    .param p0, "this$0"    # Lcom/goudong/jd/ui/projects/KugouRushFragment;

    const-string v0, "this$0"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 844
    invoke-virtual {p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->isAdded()Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-direct {p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->renderAccounts()V

    :cond_0
    return-void
.end method

.method private final updateTimeDisplay()V
    .locals 9

    .line 867
    sget-object v0, Lcom/goudong/jd/ui/projects/KugouTimeHelper;->INSTANCE:Lcom/goudong/jd/ui/projects/KugouTimeHelper;

    invoke-virtual {v0}, Lcom/goudong/jd/ui/projects/KugouTimeHelper;->getBeijingTime()Lcom/goudong/jd/ui/projects/KugouTimeHelper$BeijingTime;

    move-result-object v0

    .line 868
    .local v0, "bj":Lcom/goudong/jd/ui/projects/KugouTimeHelper$BeijingTime;
    invoke-direct {p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->preOpenMin()I

    move-result v1

    .line 869
    .local v1, "openMin":I
    sget-object v2, Lcom/goudong/jd/ui/projects/KugouTimeHelper;->INSTANCE:Lcom/goudong/jd/ui/projects/KugouTimeHelper;

    invoke-virtual {v2, v1}, Lcom/goudong/jd/ui/projects/KugouTimeHelper;->getNextWithdrawInfo(I)Lcom/goudong/jd/ui/projects/KugouTimeHelper$NextWithdrawInfo;

    move-result-object v2

    .line 870
    .local v2, "info":Lcom/goudong/jd/ui/projects/KugouTimeHelper$NextWithdrawInfo;
    sget-object v3, Lcom/goudong/jd/ui/projects/KugouTimeHelper;->INSTANCE:Lcom/goudong/jd/ui/projects/KugouTimeHelper;

    invoke-virtual {v2}, Lcom/goudong/jd/ui/projects/KugouTimeHelper$NextWithdrawInfo;->getHour()I

    move-result v4

    invoke-virtual {v3, v4}, Lcom/goudong/jd/ui/projects/KugouTimeHelper;->formatHour(I)Ljava/lang/String;

    move-result-object v3

    .line 871
    .local v3, "label":Ljava/lang/String;
    iget-object v4, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->nowTimeText:Landroid/widget/TextView;

    if-nez v4, :cond_0

    goto :goto_0

    :cond_0
    sget-object v5, Lcom/goudong/jd/ui/projects/KugouTimeHelper;->INSTANCE:Lcom/goudong/jd/ui/projects/KugouTimeHelper;

    invoke-virtual {v0}, Lcom/goudong/jd/ui/projects/KugouTimeHelper$BeijingTime;->getHour()I

    move-result v6

    invoke-virtual {v0}, Lcom/goudong/jd/ui/projects/KugouTimeHelper$BeijingTime;->getMin()I

    move-result v7

    invoke-virtual {v0}, Lcom/goudong/jd/ui/projects/KugouTimeHelper$BeijingTime;->getSec()I

    move-result v8

    invoke-virtual {v5, v6, v7, v8}, Lcom/goudong/jd/ui/projects/KugouTimeHelper;->formatClock(III)Ljava/lang/String;

    move-result-object v5

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const-string v7, "\ud83d\udd50 \u5f53\u524d\u5317\u4eac\u65f6\u95f4\uff1a"

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    check-cast v5, Ljava/lang/CharSequence;

    invoke-virtual {v4, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 872
    :goto_0
    invoke-direct {p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->isDebugRushMode()Z

    move-result v4

    if-eqz v4, :cond_3

    .line 873
    iget-object v4, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->nextTimeText:Landroid/widget/TextView;

    if-nez v4, :cond_1

    goto :goto_1

    :cond_1
    const-string v5, "\ud83d\udc1b \u8c03\u8bd5\u6a21\u5f0f"

    check-cast v5, Ljava/lang/CharSequence;

    invoke-virtual {v4, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 874
    :goto_1
    iget-object v4, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->timeHintText:Landroid/widget/TextView;

    if-nez v4, :cond_2

    goto :goto_2

    :cond_2
    const-string v5, "\u53ef\u968f\u65f6\u5f00\u59cb\u62a2\u5151\u5e76\u7acb\u5373\u6267\u884c\uff08\u540e\u53f0\u8c03\u8bd5\u5f00\u5173\uff09"

    check-cast v5, Ljava/lang/CharSequence;

    invoke-virtual {v4, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 875
    :goto_2
    invoke-direct {p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->syncStartButton()V

    .line 876
    return-void

    .line 878
    :cond_3
    invoke-direct {p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->isAutoRushMode()Z

    move-result v4

    if-eqz v4, :cond_6

    .line 879
    sget-object v4, Lcom/goudong/jd/ui/projects/KugouTimeHelper;->INSTANCE:Lcom/goudong/jd/ui/projects/KugouTimeHelper;

    invoke-virtual {v2}, Lcom/goudong/jd/ui/projects/KugouTimeHelper$NextWithdrawInfo;->getHour()I

    move-result v5

    invoke-direct {p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->autoPrepMin()I

    move-result v6

    invoke-virtual {v4, v5, v6}, Lcom/goudong/jd/ui/projects/KugouTimeHelper;->autoPrepClock(II)Lkotlin/Pair;

    move-result-object v4

    .line 880
    .local v4, "prep":Lkotlin/Pair;
    sget-object v5, Lcom/goudong/jd/ui/projects/KugouTimeHelper;->INSTANCE:Lcom/goudong/jd/ui/projects/KugouTimeHelper;

    invoke-virtual {v4}, Lkotlin/Pair;->getFirst()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/Number;

    invoke-virtual {v6}, Ljava/lang/Number;->intValue()I

    move-result v6

    invoke-virtual {v4}, Lkotlin/Pair;->getSecond()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/lang/Number;

    invoke-virtual {v7}, Ljava/lang/Number;->intValue()I

    move-result v7

    const/4 v8, 0x0

    invoke-virtual {v5, v6, v7, v8}, Lcom/goudong/jd/ui/projects/KugouTimeHelper;->formatClock(III)Ljava/lang/String;

    move-result-object v5

    .line 881
    .local v5, "prepLabel":Ljava/lang/String;
    iget-object v6, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->nextTimeText:Landroid/widget/TextView;

    if-nez v6, :cond_4

    goto :goto_3

    :cond_4
    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    const-string v8, "\u23f0 \u4e0b\u4e00\u573a\uff1a"

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    check-cast v7, Ljava/lang/CharSequence;

    invoke-virtual {v6, v7}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 882
    :goto_3
    iget-object v6, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->timeHintText:Landroid/widget/TextView;

    if-nez v6, :cond_5

    goto :goto_4

    :cond_5
    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    const-string v8, "\ud83e\udd16 \u81ea\u52a8\u62a2\u5151\uff1a\u7ea6 "

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    const-string v8, " \u67e5\u6863\uff0c"

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    const-string v8, " \u51c6\u65f6\u6267\u884c\uff08\u5168\u9009\u53ef\u8d1f\u62c5\u6863\u4f4d\uff0c\u76f4\u8fde\uff09"

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    check-cast v7, Ljava/lang/CharSequence;

    invoke-virtual {v6, v7}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 883
    :goto_4
    invoke-direct {p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->refreshConfigStaleHint()V

    .line 884
    invoke-direct {p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->syncStartButton()V

    .line 885
    return-void

    .line 887
    .end local v4    # "prep":Lkotlin/Pair;
    .end local v5    # "prepLabel":Ljava/lang/String;
    :cond_6
    nop

    .line 888
    invoke-virtual {v2}, Lcom/goudong/jd/ui/projects/KugouTimeHelper$NextWithdrawInfo;->getInWindow()Z

    move-result v4

    const-string v5, "\u23f0 \u4e0b\u6b21\u62a2\u5151\uff1a"

    if-eqz v4, :cond_9

    invoke-virtual {v2}, Lcom/goudong/jd/ui/projects/KugouTimeHelper$NextWithdrawInfo;->getDiffMin()I

    move-result v4

    if-lez v4, :cond_9

    .line 889
    iget-object v4, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->nextTimeText:Landroid/widget/TextView;

    if-nez v4, :cond_7

    goto :goto_5

    :cond_7
    invoke-virtual {v2}, Lcom/goudong/jd/ui/projects/KugouTimeHelper$NextWithdrawInfo;->getDiffMin()I

    move-result v6

    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v7, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v7, "\uff08"

    invoke-virtual {v5, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v6, "\u5206\u949f\u540e\uff09"

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    check-cast v5, Ljava/lang/CharSequence;

    invoke-virtual {v4, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 890
    :goto_5
    iget-object v4, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->timeHintText:Landroid/widget/TextView;

    if-nez v4, :cond_8

    goto/16 :goto_8

    :cond_8
    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "\u2705 \u53ef\u70b9\u51fb\u3010\u5f00\u59cb\u62a2\u5151\u3011\uff0c\u5012\u8ba1\u65f6\u5230 "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v6, " \u5f00\u62a2"

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    check-cast v5, Ljava/lang/CharSequence;

    invoke-virtual {v4, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    goto/16 :goto_8

    .line 892
    :cond_9
    invoke-virtual {v2}, Lcom/goudong/jd/ui/projects/KugouTimeHelper$NextWithdrawInfo;->getInWindow()Z

    move-result v4

    if-eqz v4, :cond_c

    invoke-virtual {v2}, Lcom/goudong/jd/ui/projects/KugouTimeHelper$NextWithdrawInfo;->getDiffMin()I

    move-result v4

    if-nez v4, :cond_c

    .line 893
    iget-object v4, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->nextTimeText:Landroid/widget/TextView;

    if-nez v4, :cond_a

    goto :goto_6

    :cond_a
    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v6, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v6, "\uff08\u5f53\u524d\u65f6\u6bb5\uff09"

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    check-cast v5, Ljava/lang/CharSequence;

    invoke-virtual {v4, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 894
    :goto_6
    iget-object v4, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->timeHintText:Landroid/widget/TextView;

    if-nez v4, :cond_b

    goto/16 :goto_8

    :cond_b
    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "\ud83d\ude80 \u5df2\u5230 "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v6, "\uff0c\u70b9\u51fb\u7acb\u5373\u5f00\u62a2"

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    check-cast v5, Ljava/lang/CharSequence;

    invoke-virtual {v4, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    goto :goto_8

    .line 897
    :cond_c
    iget-object v4, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->nextTimeText:Landroid/widget/TextView;

    if-nez v4, :cond_d

    goto :goto_7

    :cond_d
    invoke-virtual {v2}, Lcom/goudong/jd/ui/projects/KugouTimeHelper$NextWithdrawInfo;->getDiffMin()I

    move-result v6

    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v7, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v7, "\uff08\u8fd8\u6709"

    invoke-virtual {v5, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v6, "\u5206\u949f\uff09"

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    check-cast v5, Ljava/lang/CharSequence;

    invoke-virtual {v4, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 898
    :goto_7
    iget-object v4, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->timeHintText:Landroid/widget/TextView;

    if-nez v4, :cond_e

    goto :goto_8

    :cond_e
    sget-object v5, Lcom/goudong/jd/ui/projects/KugouTimeHelper;->INSTANCE:Lcom/goudong/jd/ui/projects/KugouTimeHelper;

    invoke-virtual {v5, v1}, Lcom/goudong/jd/ui/projects/KugouTimeHelper;->preOpenHint(I)Ljava/lang/String;

    move-result-object v5

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const-string v7, "\u23f3 \u8bf7\u5728 "

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v7, " \u524d "

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v6, "\u5185\u518d\u70b9\u51fb"

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    check-cast v5, Ljava/lang/CharSequence;

    invoke-virtual {v4, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 901
    :goto_8
    invoke-direct {p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->refreshConfigStaleHint()V

    .line 902
    invoke-direct {p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->syncStartButton()V

    .line 903
    return-void
.end method

.method private final withdrawPicks()Ljava/util/List;
    .locals 20
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation

    .line 859
    invoke-direct/range {p0 .. p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->selectedAccounts()Ljava/util/List;

    move-result-object v0

    check-cast v0, Ljava/lang/Iterable;

    .local v0, "$this$mapNotNull$iv":Ljava/lang/Iterable;
    const/4 v1, 0x0

    .line 1365
    .local v1, "$i$f$mapNotNull":I
    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    check-cast v2, Ljava/util/Collection;

    .local v2, "destination$iv$iv":Ljava/util/Collection;
    move-object v3, v0

    .local v3, "$this$mapNotNullTo$iv$iv":Ljava/lang/Iterable;
    const/4 v4, 0x0

    .line 1373
    .local v4, "$i$f$mapNotNullTo":I
    move-object v5, v3

    .local v5, "$this$forEach$iv$iv$iv":Ljava/lang/Iterable;
    const/4 v6, 0x0

    .line 1374
    .local v6, "$i$f$forEach":I
    invoke-interface {v5}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v7

    :goto_0
    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    move-result v8

    if-eqz v8, :cond_5

    invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v8

    .local v8, "element$iv$iv$iv":Ljava/lang/Object;
    move-object v9, v8

    .local v9, "element$iv$iv":Ljava/lang/Object;
    const/4 v10, 0x0

    .line 1373
    .local v10, "$i$a$-forEach-CollectionsKt___CollectionsKt$mapNotNullTo$1$iv$iv":I
    move-object v11, v9

    check-cast v11, Lcom/goudong/jd/data/model/KugouAccount;

    .local v11, "acc":Lcom/goudong/jd/data/model/KugouAccount;
    const/4 v12, 0x0

    .line 860
    .local v12, "$i$a$-mapNotNull-KugouRushFragment$withdrawPicks$1":I
    invoke-virtual {v11}, Lcom/goudong/jd/data/model/KugouAccount;->getUserid()Ljava/lang/String;

    move-result-object v13

    if-eqz v13, :cond_3

    move-object v15, v13

    .line 1303
    .local v15, "it":Ljava/lang/String;
    const/16 v16, 0x0

    .line 860
    .local v16, "$i$a$-takeIf-KugouRushFragment$withdrawPicks$1$uid$1":I
    move-object/from16 v17, v15

    check-cast v17, Ljava/lang/CharSequence;

    invoke-static/range {v17 .. v17}, Lkotlin/text/StringsKt;->isBlank(Ljava/lang/CharSequence;)Z

    move-result v17

    const/16 v18, 0x1

    xor-int/lit8 v17, v17, 0x1

    .end local v15    # "it":Ljava/lang/String;
    .end local v16    # "$i$a$-takeIf-KugouRushFragment$withdrawPicks$1$uid$1":I
    if-eqz v17, :cond_0

    goto :goto_1

    :cond_0
    const/4 v13, 0x0

    :goto_1
    if-nez v13, :cond_1

    move-object/from16 v15, p0

    move-object/from16 v17, v0

    move/from16 v19, v1

    goto :goto_2

    .line 861
    .local v13, "uid":Ljava/lang/String;
    :cond_1
    move-object/from16 v15, p0

    invoke-direct {v15, v13}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->coinsFor(Ljava/lang/String;)Ljava/util/List;

    move-result-object v14

    .line 862
    .local v14, "coins":Ljava/util/List;
    invoke-interface {v14}, Ljava/util/List;->isEmpty()Z

    move-result v17

    if-eqz v17, :cond_2

    move-object/from16 v17, v0

    move/from16 v19, v1

    const/4 v14, 0x0

    goto :goto_3

    :cond_2
    move-object/from16 v17, v0

    .end local v0    # "$this$mapNotNull$iv":Ljava/lang/Iterable;
    .local v17, "$this$mapNotNull$iv":Ljava/lang/Iterable;
    const/4 v0, 0x2

    new-array v0, v0, [Lkotlin/Pair;

    move/from16 v19, v1

    .end local v1    # "$i$f$mapNotNull":I
    .local v19, "$i$f$mapNotNull":I
    const-string v1, "userid"

    invoke-static {v1, v13}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v1

    const/16 v16, 0x0

    aput-object v1, v0, v16

    const-string v1, "coins"

    invoke-static {v1, v14}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v1

    aput-object v1, v0, v18

    invoke-static {v0}, Lkotlin/collections/MapsKt;->mapOf([Lkotlin/Pair;)Ljava/util/Map;

    move-result-object v0

    move-object v14, v0

    goto :goto_3

    .line 860
    .end local v13    # "uid":Ljava/lang/String;
    .end local v14    # "coins":Ljava/util/List;
    .end local v17    # "$this$mapNotNull$iv":Ljava/lang/Iterable;
    .end local v19    # "$i$f$mapNotNull":I
    .restart local v0    # "$this$mapNotNull$iv":Ljava/lang/Iterable;
    .restart local v1    # "$i$f$mapNotNull":I
    :cond_3
    move-object/from16 v15, p0

    move-object/from16 v17, v0

    move/from16 v19, v1

    .end local v0    # "$this$mapNotNull$iv":Ljava/lang/Iterable;
    .end local v1    # "$i$f$mapNotNull":I
    .restart local v17    # "$this$mapNotNull$iv":Ljava/lang/Iterable;
    .restart local v19    # "$i$f$mapNotNull":I
    :goto_2
    const/4 v14, 0x0

    .line 1373
    .end local v11    # "acc":Lcom/goudong/jd/data/model/KugouAccount;
    .end local v12    # "$i$a$-mapNotNull-KugouRushFragment$withdrawPicks$1":I
    :goto_3
    if-eqz v14, :cond_4

    move-object v0, v14

    .line 1375
    .local v0, "it$iv$iv":Ljava/lang/Object;
    const/4 v1, 0x0

    .line 1373
    .local v1, "$i$a$-let-CollectionsKt___CollectionsKt$mapNotNullTo$1$1$iv$iv":I
    invoke-interface {v2, v0}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    .line 1374
    .end local v0    # "it$iv$iv":Ljava/lang/Object;
    .end local v1    # "$i$a$-let-CollectionsKt___CollectionsKt$mapNotNullTo$1$1$iv$iv":I
    .end local v9    # "element$iv$iv":Ljava/lang/Object;
    .end local v10    # "$i$a$-forEach-CollectionsKt___CollectionsKt$mapNotNullTo$1$iv$iv":I
    :cond_4
    move-object/from16 v0, v17

    move/from16 v1, v19

    .end local v8    # "element$iv$iv$iv":Ljava/lang/Object;
    goto :goto_0

    .line 1376
    .end local v17    # "$this$mapNotNull$iv":Ljava/lang/Iterable;
    .end local v19    # "$i$f$mapNotNull":I
    .local v0, "$this$mapNotNull$iv":Ljava/lang/Iterable;
    .local v1, "$i$f$mapNotNull":I
    :cond_5
    move-object/from16 v17, v0

    .line 1377
    .end local v0    # "$this$mapNotNull$iv":Ljava/lang/Iterable;
    .end local v5    # "$this$forEach$iv$iv$iv":Ljava/lang/Iterable;
    .end local v6    # "$i$f$forEach":I
    .restart local v17    # "$this$mapNotNull$iv":Ljava/lang/Iterable;
    nop

    .end local v2    # "destination$iv$iv":Ljava/util/Collection;
    .end local v3    # "$this$mapNotNullTo$iv$iv":Ljava/lang/Iterable;
    .end local v4    # "$i$f$mapNotNullTo":I
    move-object v0, v2

    check-cast v0, Ljava/util/List;

    .line 1365
    nop

    .line 859
    .end local v1    # "$i$f$mapNotNull":I
    .end local v17    # "$this$mapNotNull$iv":Ljava/lang/Iterable;
    return-object v0
.end method


# virtual methods
.method public onCreateView(Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Landroid/os/Bundle;)Landroid/view/View;
    .locals 4
    .param p1, "inflater"    # Landroid/view/LayoutInflater;
    .param p2, "container"    # Landroid/view/ViewGroup;
    .param p3, "savedInstanceState"    # Landroid/os/Bundle;

    const-string v0, "inflater"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 139
    new-instance v0, Landroid/widget/LinearLayout;

    invoke-virtual {p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->requireContext()Landroid/content/Context;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object v1, v0

    .line 1303
    .local v1, "$this$onCreateView_u24lambda_u241":Landroid/widget/LinearLayout;
    const/4 v2, 0x0

    .line 139
    .local v2, "$i$a$-apply-KugouRushFragment$onCreateView$wrapper$1":I
    const/4 v3, 0x1

    invoke-virtual {v1, v3}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 140
    .end local v1    # "$this$onCreateView_u24lambda_u241":Landroid/widget/LinearLayout;
    .end local v2    # "$i$a$-apply-KugouRushFragment$onCreateView$wrapper$1":I
    .local v0, "wrapper":Landroid/widget/LinearLayout;
    invoke-virtual {p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->requireContext()Landroid/content/Context;

    move-result-object v1

    const-string v2, "requireContext(...)"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v1}, Lcom/goudong/jd/ui/common/UiKitKt;->makeScrollContainer(Landroid/content/Context;)Lkotlin/Pair;

    move-result-object v1

    invoke-virtual {v1}, Lkotlin/Pair;->component1()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/widget/ScrollView;

    .local v2, "scroll":Landroid/widget/ScrollView;
    invoke-virtual {v1}, Lkotlin/Pair;->component2()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/widget/LinearLayout;

    .line 141
    .local v1, "root":Landroid/widget/LinearLayout;
    iput-object v1, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->contentRoot:Landroid/widget/LinearLayout;

    .line 142
    move-object v3, v2

    check-cast v3, Landroid/view/View;

    invoke-virtual {v0, v3}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 143
    invoke-direct {p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->buildPage()V

    .line 144
    move-object v3, v0

    check-cast v3, Landroid/view/View;

    return-object v3
.end method

.method public onDestroyView()V
    .locals 3

    .line 196
    iget-object v0, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->monitorJob:Lkotlinx/coroutines/Job;

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    invoke-static {v0, v2, v1, v2}, Lkotlinx/coroutines/Job$DefaultImpls;->cancel$default(Lkotlinx/coroutines/Job;Ljava/util/concurrent/CancellationException;ILjava/lang/Object;)V

    .line 197
    :cond_0
    iget-object v0, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->countdownJob:Lkotlinx/coroutines/Job;

    if-eqz v0, :cond_1

    invoke-static {v0, v2, v1, v2}, Lkotlinx/coroutines/Job$DefaultImpls;->cancel$default(Lkotlinx/coroutines/Job;Ljava/util/concurrent/CancellationException;ILjava/lang/Object;)V

    .line 198
    :cond_1
    iget-object v0, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->crossDeviceSyncJob:Lkotlinx/coroutines/Job;

    if-eqz v0, :cond_2

    invoke-static {v0, v2, v1, v2}, Lkotlinx/coroutines/Job$DefaultImpls;->cancel$default(Lkotlinx/coroutines/Job;Ljava/util/concurrent/CancellationException;ILjava/lang/Object;)V

    .line 199
    :cond_2
    iget-object v0, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->clockHandler:Landroid/os/Handler;

    iget-object v1, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->clockRunnable:Lcom/goudong/jd/ui/projects/KugouRushFragment$clockRunnable$1;

    check-cast v1, Ljava/lang/Runnable;

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    .line 200
    invoke-super {p0}, Landroidx/fragment/app/Fragment;->onDestroyView()V

    .line 201
    return-void
.end method

.method public onPause()V
    .locals 4

    .line 188
    invoke-super {p0}, Landroidx/fragment/app/Fragment;->onPause()V

    .line 189
    iget-object v0, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->crossDeviceSyncJob:Lkotlinx/coroutines/Job;

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    invoke-static {v0, v2, v1, v2}, Lkotlinx/coroutines/Job$DefaultImpls;->cancel$default(Lkotlinx/coroutines/Job;Ljava/util/concurrent/CancellationException;ILjava/lang/Object;)V

    .line 190
    :cond_0
    iget-object v0, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->clockHandler:Landroid/os/Handler;

    iget-object v3, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->clockRunnable:Lcom/goudong/jd/ui/projects/KugouRushFragment$clockRunnable$1;

    check-cast v3, Ljava/lang/Runnable;

    invoke-virtual {v0, v3}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    .line 191
    iget-object v0, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->countdownJob:Lkotlinx/coroutines/Job;

    if-eqz v0, :cond_1

    invoke-static {v0, v2, v1, v2}, Lkotlinx/coroutines/Job$DefaultImpls;->cancel$default(Lkotlinx/coroutines/Job;Ljava/util/concurrent/CancellationException;ILjava/lang/Object;)V

    .line 192
    :cond_1
    iget-object v0, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->monitorJob:Lkotlinx/coroutines/Job;

    if-eqz v0, :cond_2

    invoke-static {v0, v2, v1, v2}, Lkotlinx/coroutines/Job$DefaultImpls;->cancel$default(Lkotlinx/coroutines/Job;Ljava/util/concurrent/CancellationException;ILjava/lang/Object;)V

    .line 193
    :cond_2
    return-void
.end method

.method public onResume()V
    .locals 12

    .line 155
    invoke-super {p0}, Landroidx/fragment/app/Fragment;->onResume()V

    .line 156
    iget-object v0, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->clockHandler:Landroid/os/Handler;

    iget-object v1, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->clockRunnable:Lcom/goudong/jd/ui/projects/KugouRushFragment$clockRunnable$1;

    check-cast v1, Ljava/lang/Runnable;

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 157
    invoke-direct {p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->loadPage()V

    .line 158
    iget-object v0, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->activeTaskId:Ljava/lang/String;

    .line 159
    .local v0, "taskId":Ljava/lang/String;
    move-object v1, v0

    check-cast v1, Ljava/lang/CharSequence;

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-eqz v1, :cond_1

    invoke-static {v1}, Lkotlin/text/StringsKt;->isBlank(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_0

    goto :goto_0

    :cond_0
    move v1, v2

    goto :goto_1

    :cond_1
    :goto_0
    move v1, v3

    :goto_1
    const-string v4, "getViewLifecycleOwner(...)"

    const/4 v5, 0x0

    if-nez v1, :cond_3

    iget-object v1, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->monitorJob:Lkotlinx/coroutines/Job;

    if-eqz v1, :cond_2

    invoke-interface {v1}, Lkotlinx/coroutines/Job;->isActive()Z

    move-result v1

    if-ne v1, v3, :cond_2

    move v2, v3

    :cond_2
    if-nez v2, :cond_3

    .line 160
    invoke-virtual {p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->getViewLifecycleOwner()Landroidx/lifecycle/LifecycleOwner;

    move-result-object v1

    invoke-static {v1, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v1}, Landroidx/lifecycle/LifecycleOwnerKt;->getLifecycleScope(Landroidx/lifecycle/LifecycleOwner;)Landroidx/lifecycle/LifecycleCoroutineScope;

    move-result-object v1

    move-object v6, v1

    check-cast v6, Lkotlinx/coroutines/CoroutineScope;

    new-instance v1, Lcom/goudong/jd/ui/projects/KugouRushFragment$onResume$1;

    invoke-direct {v1, p0, v0, v5}, Lcom/goudong/jd/ui/projects/KugouRushFragment$onResume$1;-><init>(Lcom/goudong/jd/ui/projects/KugouRushFragment;Ljava/lang/String;Lkotlin/coroutines/Continuation;)V

    move-object v9, v1

    check-cast v9, Lkotlin/jvm/functions/Function2;

    const/4 v10, 0x3

    const/4 v11, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-static/range {v6 .. v11}, Lkotlinx/coroutines/BuildersKt;->launch$default(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/CoroutineContext;Lkotlinx/coroutines/CoroutineStart;Lkotlin/jvm/functions/Function2;ILjava/lang/Object;)Lkotlinx/coroutines/Job;

    .line 166
    :cond_3
    iget-object v1, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->crossDeviceSyncJob:Lkotlinx/coroutines/Job;

    if-eqz v1, :cond_4

    invoke-static {v1, v5, v3, v5}, Lkotlinx/coroutines/Job$DefaultImpls;->cancel$default(Lkotlinx/coroutines/Job;Ljava/util/concurrent/CancellationException;ILjava/lang/Object;)V

    .line 167
    :cond_4
    invoke-virtual {p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->getViewLifecycleOwner()Landroidx/lifecycle/LifecycleOwner;

    move-result-object v1

    invoke-static {v1, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v1}, Landroidx/lifecycle/LifecycleOwnerKt;->getLifecycleScope(Landroidx/lifecycle/LifecycleOwner;)Landroidx/lifecycle/LifecycleCoroutineScope;

    move-result-object v1

    move-object v6, v1

    check-cast v6, Lkotlinx/coroutines/CoroutineScope;

    new-instance v1, Lcom/goudong/jd/ui/projects/KugouRushFragment$onResume$2;

    invoke-direct {v1, p0, v5}, Lcom/goudong/jd/ui/projects/KugouRushFragment$onResume$2;-><init>(Lcom/goudong/jd/ui/projects/KugouRushFragment;Lkotlin/coroutines/Continuation;)V

    move-object v9, v1

    check-cast v9, Lkotlin/jvm/functions/Function2;

    const/4 v10, 0x3

    const/4 v11, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-static/range {v6 .. v11}, Lkotlinx/coroutines/BuildersKt;->launch$default(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/CoroutineContext;Lkotlinx/coroutines/CoroutineStart;Lkotlin/jvm/functions/Function2;ILjava/lang/Object;)Lkotlinx/coroutines/Job;

    move-result-object v1

    iput-object v1, p0, Lcom/goudong/jd/ui/projects/KugouRushFragment;->crossDeviceSyncJob:Lkotlinx/coroutines/Job;

    .line 185
    return-void
.end method

.method public onViewCreated(Landroid/view/View;Landroid/os/Bundle;)V
    .locals 7
    .param p1, "view"    # Landroid/view/View;
    .param p2, "savedInstanceState"    # Landroid/os/Bundle;

    const-string v0, "view"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 148
    invoke-super {p0, p1, p2}, Landroidx/fragment/app/Fragment;->onViewCreated(Landroid/view/View;Landroid/os/Bundle;)V

    .line 149
    invoke-virtual {p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->requireActivity()Landroidx/fragment/app/FragmentActivity;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/fragment/app/FragmentActivity;->getOnBackPressedDispatcher()Landroidx/activity/OnBackPressedDispatcher;

    move-result-object v1

    invoke-virtual {p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment;->getViewLifecycleOwner()Landroidx/lifecycle/LifecycleOwner;

    move-result-object v2

    new-instance v0, Lcom/goudong/jd/ui/projects/KugouRushFragment$onViewCreated$1;

    invoke-direct {v0, p0}, Lcom/goudong/jd/ui/projects/KugouRushFragment$onViewCreated$1;-><init>(Lcom/goudong/jd/ui/projects/KugouRushFragment;)V

    move-object v4, v0

    check-cast v4, Lkotlin/jvm/functions/Function1;

    const/4 v5, 0x2

    const/4 v6, 0x0

    const/4 v3, 0x0

    invoke-static/range {v1 .. v6}, Landroidx/activity/OnBackPressedDispatcherKt;->addCallback$default(Landroidx/activity/OnBackPressedDispatcher;Landroidx/lifecycle/LifecycleOwner;ZLkotlin/jvm/functions/Function1;ILjava/lang/Object;)Landroidx/activity/OnBackPressedCallback;

    .line 152
    return-void
.end method
