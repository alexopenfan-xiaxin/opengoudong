.class public final synthetic Lcom/goudong/jd/ui/common/UiKitKt$$ExternalSyntheticLambda2;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Lcom/google/android/material/tabs/TabLayout;


# direct methods
.method public synthetic constructor <init>(Lcom/google/android/material/tabs/TabLayout;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/goudong/jd/ui/common/UiKitKt$$ExternalSyntheticLambda2;->f$0:Lcom/google/android/material/tabs/TabLayout;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 1

    .line 0
    iget-object v0, p0, Lcom/goudong/jd/ui/common/UiKitKt$$ExternalSyntheticLambda2;->f$0:Lcom/google/android/material/tabs/TabLayout;

    invoke-static {v0}, Lcom/goudong/jd/ui/common/UiKitKt;->$r8$lambda$acb7edRrCiqAhPqi0LHq6z0nF4Q(Lcom/google/android/material/tabs/TabLayout;)V

    return-void
.end method
